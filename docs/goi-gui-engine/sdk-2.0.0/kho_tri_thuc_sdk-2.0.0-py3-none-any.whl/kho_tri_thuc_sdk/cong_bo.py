"""Façade V4 trên tx module; bootstrap ghim schema/hash, không nhận tên SQL.

cong_bo_doc: các binding {module, ten, ma_contract, phien_ban_contract,
ma_bam_contract, luoc_do}. schemas chứa tài nguyên $ref offline đã kiểm.
can_cu tùy chọn là ba đường dẫn khóa (tuple) tới doi_tuong_id, phien_ban,
ma_bam trong contract; mặc định id/revision/ma_bam. Hash do nguồn công bố,
không tính lại bằng thuật toán băm nghiệp vụ do SDK tự chọn.
"""

from copy import deepcopy
from decimal import Decimal
import json
import re
import time
from uuid import UUID

from .dich_vu import LoiDichVu, _DichVu, _ctx
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


_SQL = 'SELECT loi.doc_cong_bo_sdk(%s,%s,%s,%s::jsonb,%s,%s)'
_LOI = {'CONG_BO_QUYEN': 403, 'CONG_BO_CONTRACT': 422,
        'CONG_BO_BINDING': 409, 'CONG_BO_DAU_VAO': 422,
        'CONG_BO_KET_QUA': 502, 'CONG_BO_THAT_BAI': 500,
        'CONG_BO_CAN_READ_COMMITTED': 409, 'CONG_BO_NGUON_DA_DOI': 409}
_ID = r'(?:urn:ktt:contract:)?([a-z][a-z0-9_]*\.v[1-9][0-9]*)(?::([0-9]+\.[0-9]+\.[0-9]+))?'
_HASH = r'[0-9a-f]{64}'


def _loi(ma):
    return LoiDichVu(ma, _LOI[ma])


def _dinh_danh(value):
    match = re.fullmatch(_ID, value) if type(value) is str else None
    if match is None:
        raise _loi('CONG_BO_CONTRACT')
    return match[1], match[2] or '1.0.0'


def _json_loc(value):
    # Cùng biểu diễn với jsonb::text của C1, cả số mũ và Unicode.
    def kiem(node):
        if type(node) is dict:
            if any(type(k) is not str for k in node):
                raise ValueError()
            for child in node.values():
                kiem(child)
        elif type(node) is list:
            for child in node:
                kiem(child)
        elif type(node) not in (str, int, float, bool, type(None)):
            raise ValueError()
        elif type(node) is str and ('\x00' in node or any(0xD800 <= ord(c) <= 0xDFFF for c in node)):
            raise ValueError()
    kiem(value)
    raw = json.dumps(value, ensure_ascii=False, allow_nan=False)
    def token(match):
        value = match[0]
        if value.startswith('"'):
            return value
        number = Decimal(value)
        return format(number.copy_abs() if number.is_zero() else number, 'f')
    raw = re.sub(r'"(?:[^"\\]|\\.)*"|-?\d+(?:\.\d+)?(?:[eE][+-]?\d+)?', token, raw)
    if len(raw.encode('utf-8')) > 16384:
        raise ValueError()
    return raw


def _validator(schema, schemas):
    # Nạp lười, không kéo server/registry Core vào SDK wheel.
    from jsonschema import Draft202012Validator, FormatChecker
    from referencing import Registry, Resource
    from referencing.jsonschema import DRAFT202012

    resources = {}
    for uri, item in schemas.items():
        Draft202012Validator.check_schema(item)
        resources[uri] = Resource.from_contents(item, default_specification=DRAFT202012)
    registry = Registry().with_resources(resources.items())  # Không retrieve/network.
    Draft202012Validator.check_schema(schema)
    return Draft202012Validator(schema, registry=registry, format_checker=FormatChecker())


class CongBo(_DichVu):
    __slots__ = ('__module', '__pins')

    def __init__(self, khai_bao=None, *, cong_bo_doc=None, schemas=None):
        module = khai_bao.get('ma') if isinstance(khai_bao, dict) else getattr(khai_bao, 'ma', None)
        self.__module, self.__pins = module, {}
        if cong_bo_doc is None:
            return
        code = 'CONG_BO_CONTRACT'
        try:
            if (type(module) is not str or not re.fullmatch('[a-z][a-z0-9_]{0,30}', module)
                    or type(cong_bo_doc) not in (list, tuple)):
                raise ValueError()
            entries = deepcopy(cong_bo_doc)
            local = deepcopy(schemas or {})
            for entry in entries:
                schema = entry['luoc_do']
                uri = schema['$id']
                ma, ban = _dinh_danh(uri)
                if (entry['ma_contract'] != ma or entry['phien_ban_contract'] != ban
                        or type(entry['ma_bam_contract']) is not str
                        or not re.fullmatch(_HASH, entry['ma_bam_contract'])
                        or not re.fullmatch('[a-z][a-z0-9_]{0,30}', entry['module'])
                        or not re.fullmatch('[a-z][a-z0-9_]{0,31}', entry['ten'])
                        or (ma, ban) in self.__pins or local.get(uri, schema) != schema):
                    raise ValueError()
                local[uri] = schema
            for entry in entries:
                schema = entry['luoc_do']
                ma, ban = _dinh_danh(schema['$id'])
                paths = entry.get('can_cu', dict(doi_tuong_id=('id',),
                    phien_ban=('revision',), ma_bam=('ma_bam',)))
                if (type(paths) is not dict or set(paths) != {'doi_tuong_id', 'phien_ban', 'ma_bam'}
                        or any(type(path) not in (list, tuple) or not path
                               or any(type(k) is not str or not k for k in path)
                               for path in paths.values())):
                    raise ValueError()
                self.__pins[(ma, ban)] = (entry, _validator(schema, local), paths)
            return
        except ImportError:
            code = 'CONG_BO_THAT_BAI'
        except Exception:
            pass
        self.__pins = {}
        raise _loi(code) from None

    def _ngu_canh(self, ctx):
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den or ctx.module != self.__module
                or ctx.hanh_dong != ctx.module.upper() + ':CONG_BO:XEM'):
            raise _loi('CONG_BO_QUYEN')

    def liet_ke(self, ctx):
        """Khai báo bootstrap của module; danh sách không tự cấp quyền đọc."""
        self._ngu_canh(ctx)
        return [dict(contract=e['luoc_do']['$id'], module=e['module'], ten=e['ten'],
                     phien_ban=e['phien_ban_contract'], ma_bam=e['ma_bam_contract'])
                for e, _, _ in self.__pins.values()]

    def _pin(self, tx, contract):
        self._ngu_canh(_ctx(tx))
        key = _dinh_danh(contract)
        if key not in self.__pins:
            raise _loi('CONG_BO_CONTRACT')
        return key, self.__pins[key]

    def doc(self, tx, contract, tham_so, *, con_tro=None, gioi_han=100):
        """Bộ lọc nguồn là tham_so; phân trang theo ABI V4, không nhận SQL."""
        (ma, ban), (entry, validator, _) = self._pin(tx, contract)
        code = 'CONG_BO_DAU_VAO'
        try:
            loc, cursor, limit = tham_so, con_tro, gioi_han
            if (type(loc) is not dict or type(limit) is not int or not 1 <= limit <= 100
                    or (cursor is not None and (type(cursor) is not str
                        or len(cursor.encode('utf-8')) > 2048))):
                raise ValueError()
            raw = _json_loc(loc)
        except Exception:
            pass
        else:
            code = 'CONG_BO_THAT_BAI'
            try:
                # GiaoDich._kiem đã kiểm tx gốc. Nested transaction của psycopg
                # là SAVEPOINT; rollback trước khi lọc lỗi, không commit module.
                with tx._conn.transaction():
                    result = tx._conn.execute(_SQL, (ma, ban,
                        entry['ma_bam_contract'], raw, cursor, limit)).fetchone()[0]
                    code = 'CONG_BO_KET_QUA'
                    self._kiem_ket_qua(result, validator, limit)
                return result
            except Exception as exc:
                primary = getattr(getattr(exc, 'diag', None), 'message_primary', None)
                if type(primary) is str and primary in _LOI:
                    code = primary
                elif getattr(exc, 'sqlstate', None) == '42501':
                    code = 'CONG_BO_QUYEN'
                # Không đụng exception validator frozen; không lưu chúng qua chain.
                if type(exc).__module__.split('.')[0] not in {'jsonschema', 'referencing'}:
                    _xoa_loi(exc)
        tx = tham_so = loc = raw = result = validator = cursor = primary = None
        raise _loi(code) from None

    @staticmethod
    def _kiem_ket_qua(result, validator, limit):
        if (type(result) is not dict or set(result) != {'trang_thai', 'danh_sach', 'con_tro_tiep'}
                or result['trang_thai'] not in ('SAN_SANG', 'CHO')
                or type(result['danh_sach']) is not list or len(result['danh_sach']) > limit
                or (result['con_tro_tiep'] is not None and (type(result['con_tro_tiep']) is not str
                    or len(result['con_tro_tiep'].encode('utf-8')) > 2048))
                or (result['trang_thai'] == 'CHO' and (result['danh_sach']
                    or result['con_tro_tiep'] is not None))):
            raise ValueError()
        for row in result['danh_sach']:
            if type(row) is not dict:
                raise ValueError()
            validator.validate(row)

    def kiem_phien_ban(self, tx, contract, doi_tuong_id, phien_ban, ma_bam):
        """Đọc lại nguồn qua V4; không dùng hash schema thay hash đối tượng.

        Luôn gửi bộ lọc có khóa doi_tuong_id; hàm nguồn phải hỗ trợ khóa này.
        can_cu chỉ đổi đường dẫn đọc căn cứ trong kết quả, không đổi khóa lọc.
        """
        _, (_, _, paths) = self._pin(tx, contract)
        try:
            identity = str(UUID(str(doi_tuong_id)))
            if (type(phien_ban) is not str or not phien_ban or len(phien_ban) > 64
                    or type(ma_bam) is not str or not re.fullmatch(_HASH, ma_bam)):
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise _loi('CONG_BO_DAU_VAO') from None
        def lay(row, path):
            for key in path:
                if type(row) is not dict or key not in row:
                    raise _loi('CONG_BO_KET_QUA')
                row = row[key]
            return row
        result = self.doc(tx, contract, {'doi_tuong_id': identity})
        matches = [r for r in result['danh_sach'] if lay(r, paths['doi_tuong_id']) == identity]
        # Không tìm bản mới nhất, không âm thầm lấy phần tử đầu/tiếp tục cursor.
        if len(matches) != 1 or result['con_tro_tiep'] is not None:
            raise _loi('CONG_BO_NGUON_DA_DOI')
        row = matches[0]
        if (str(lay(row, paths['phien_ban'])) != phien_ban
                or lay(row, paths['ma_bam']) != ma_bam):
            raise _loi('CONG_BO_NGUON_DA_DOI')
        return deepcopy(row)


_mac_dinh = CongBo()
liet_ke = _mac_dinh.liet_ke
doc = _mac_dinh.doc
kiem_phien_ban = _mac_dinh.kiem_phien_ban
