"""Thư viện DEMO: gọn khoảng trắng của văn bản, không có phụ thuộc."""

__version__ = '1.0.0'


def gon_khoang_trang(van_ban):
    """Gộp khoảng trắng và xuống dòng thành một dấu cách; giữ nguyên chữ."""
    return ' '.join(van_ban.split())
