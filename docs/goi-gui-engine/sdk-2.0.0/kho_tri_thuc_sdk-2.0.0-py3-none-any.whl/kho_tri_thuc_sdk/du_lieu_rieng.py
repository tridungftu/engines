"""Repository V1 của module; kiểm bổ trợ, không phải ranh giới an ninh.

Bootstrap truyền khai báo có thuộc tính ma, ham_core_goi (hoặc binding resolver_mtq
đã kiểm) và CuaGiaoDich của module. Thiếu/không rõ phiên bản resolver thì từ chối ghi.
SQL dùng named placeholder psycopg, luôn có ``%(phap_nhan_id)s``. SELECT trả ``id``
UUID duy nhất và ``phap_nhan_id``; SDK phân trang keyset theo id (25, tối đa
100). ``kich_thuoc_trang``/``con_tro`` là tham số phân trang dành riêng.
Lệnh INSERT/UPDATE/DELETE có RETURNING; CAS khai rõ trong WHERE bằng
``row_version = %(row_version)s``. ID đích là ``tham_so['id']`` (UUID).
Callback doi_tuong/quyen_doc do bootstrap tin cậy cấp cho biên nhận V2;
mặc định dùng bảng đích và hành động XEM tương ứng. Không tự commit.
"""

from __future__ import annotations

import base64
from copy import deepcopy
from dataclasses import dataclass
import hashlib
import hmac
import json
import re
import secrets
from typing import Generic, TypeVar, TypedDict
from uuid import UUID

from .dich_vu import LoiDichVu, _DichVu, _ctx, _phien_ban_contract, _sql, bien_nhan
from .giao_dich import CuaGiaoDich, GiaoDich
from .ngu_canh import NguCanh, _DA_KIEM


T = TypeVar('T')


@dataclass(frozen=True)
class Trang(Generic[T]):
    danh_sach: list[T]
    con_tiep: bool
    con_tro_tiep: str | None


class BienNhan(TypedDict):
    id: str | None  # None trong handler: runtime ghi biên nhận HTTP sau kiểm đầu ra.
    ket_qua: dict
    lap_lai: bool


_PHAN_TRANG = {'kich_thuoc_trang', 'con_tro'}
_CAM = {'phap_nhan_id', 'row_version', 'module', 'nguoi_dung_id', 'actor',
        'request_id', 'viec_id', 'the_he', '_sdk_sau', '_sdk_gioi_han'}
_TEN = r'[a-z_][a-z0-9_]*'
# Schema Core, chuyển tiếp/cũ và PostgreSQL; không được dùng alias để che tên.
_SCHEMA = {'loi', 'loi_tai_lieu', 'danh_muc', 'ke_toan_cu', 'master', 'kho',
           'nhat_ky', 'bao_mat', 'giao_tiep', 'm4', 'public', 'information_schema'}
# Nhận diện trước literal/comment để không coi schema trong văn bản là SQL.
_TOKEN = re.compile(r"--[^\n]*|/\*[\s\S]*?\*/|'(?:''|[^'])*'|"
                    r'"(?:""|[^"])*"|%\([a-z_][a-z0-9_]*\)s|'
                    r'[a-z_][a-z0-9_]*|\s+|.', re.I)


def _loi(ma='SDK_DAU_VAO', status=422):
    return LoiDichVu(ma, status)


def _kiem_sql(cau, schema, ghi, cas):
    if not isinstance(cau, str) or not cau.strip():
        raise _loi('SDK_DANG_KY')
    tokens = []
    for t in _TOKEN.findall(cau):
        if t.isspace() or t.startswith(('--', '/*')):
            continue
        if t.startswith("'"):
            tokens.append('LITERAL')
        elif t.startswith('"'):
            ten = t[1:-1].replace('""', '"')
            if not re.fullmatch(_TEN, ten):
                raise _loi('SDK_SCHEMA', 403)
            tokens.append(ten)
        else:
            tokens.append(t.lower())
    if tokens and tokens[-1] == ';':
        tokens.pop()
    text = ' '.join(tokens)
    if (not tokens or ';' in tokens or '$' in tokens
            or tokens[0] not in ({'insert', 'update', 'delete'} if ghi else {'select'})
            or any(t in tokens for t in ('with', 'set_config', 'dblink', 'copy'))
            or 'into' in tokens and tokens[0] != 'insert'):
        raise _loi('SDK_DANG_KY')
    # Kiểm mọi tiền tố, kể cả bảng sau dấu phẩy; alias không miễn kiểm schema.
    for i, (ten, dau, dich) in enumerate(zip(tokens, tokens[1:], tokens[2:])):
        if (dau == '.' and (re.fullmatch(_TEN, dich) or dich == '*')
                and ten != schema and (ten in _SCHEMA
                    or ten.startswith(('mod_', 'cong_bo_', 'pg_')))):
            raise _loi('SDK_SCHEMA', 403)
        if (dau == '.' and re.fullmatch(_TEN, dich) and i + 3 < len(tokens)
                and tokens[i + 3].startswith('mod_')):
            raise _loi('SDK_SCHEMA', 403)
    for ten, alias in zip(tokens, tokens[1:]):
        if ten == 'as' and alias.startswith('mod_'):
            raise _loi('SDK_SCHEMA', 403)
    # Các tên có dấu chấm còn lại phải là schema sở hữu hoặc alias đã biết.
    relations = list(re.finditer(r'\b(?:from|join|update|into|using)\s+('
                                + _TEN + r')\s*\.\s*(' + _TEN + r')', text))
    aliases = set()
    for m in relations:
        if m[1] != schema:
            raise _loi('SDK_SCHEMA', 403)
        aliases.add(m[2])
        a = re.match(r'\s+(?:as\s+)?(' + _TEN + r')', text[m.end():])
        if a and a[1] not in {'where', 'set', 'returning', 'join', 'on', 'order', 'limit'}:
            if a[1].startswith('mod_'):
                raise _loi('SDK_SCHEMA', 403)
            aliases.add(a[1])
    for m in re.finditer(r'\b(' + _TEN + r')\s*\.', text):
        if m[1] != schema and m[1] not in aliases:
            raise _loi('SDK_SCHEMA', 403)
    # Không nhận quan hệ FROM/JOIN/UPDATE/INTO/USING thiếu schema.
    for m in re.finditer(r'\b(?:from|join|update|into|using)\s+(' + _TEN + r')', text):
        if not re.match(r'\s*\.', text[m.end():]):
            raise _loi('SDK_SCHEMA', 403)
    if not relations or '%(phap_nhan_id)s' not in tokens:
        raise _loi('SDK_DANG_KY')
    if ghi and ('returning' not in tokens or (cas and (
            tokens[0] not in {'update', 'delete'} or not re.search(
                r'\bwhere\b[\s\S]*\brow_version\s*=\s*%\(row_version\)s', text)))):
        raise _loi('SDK_DANG_KY')
    # Loại dấu ; cuối và comment khi nhúng SQL; giữ nguyên literal/identifier.
    sql = ''.join(' ' if t.startswith(('--', '/*')) else t
                  for t in _TOKEN.findall(cau)).strip().removesuffix(';').strip()
    return sql, relations[0][2]


def _cac_dong(rows):
    # row_version trên giao diện JSON là chuỗi số nguyên theo chuẩn SDK.
    return [row | {'row_version': str(row['row_version'])}
            if row.get('row_version') is not None else row for row in rows]


class DuLieuRieng(_DichVu):
    __slots__ = ('khai_bao', '__cua', '__doc', '__ghi', '__doi_tuong',
                 '__quyen_doc', '__khoa_con_tro', '__tx_runtime')

    def __init__(self, khai_bao, cua_giao_dich: CuaGiaoDich,
                 *, truy_van, lenh, doi_tuong=None, quyen_doc=None):
        ma_module = getattr(khai_bao, 'ma', None)
        if (not isinstance(ma_module, str)
                or not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', ma_module)
                or not isinstance(cua_giao_dich, CuaGiaoDich)
                or ma_module != cua_giao_dich.module
                or any(c is not None and not callable(c) for c in (doi_tuong, quyen_doc))):
            raise _loi('SDK_MODULE', 403)
        self.khai_bao, self.__cua = khai_bao, cua_giao_dich
        self.__tx_runtime = None
        self.__doi_tuong, self.__quyen_doc = doi_tuong, quyen_doc
        self.__khoa_con_tro = secrets.token_bytes(32)
        # Nạp khi dùng repository để import SDK thuần không cần site-packages.
        from jsonschema import Draft202012Validator, FormatChecker
        from referencing import Registry

        validator, checker = Draft202012Validator, FormatChecker()
        registry = Registry()  # Không có retrieve: từ chối $ref ngoài, không tải mạng.

        def dang_ky(ds, ghi):
            if not isinstance(ds, dict):
                raise _loi('SDK_DANG_KY')
            kq = {}
            for ma, cfg in ds.items():
                if (not isinstance(ma, str) or not re.fullmatch(_TEN, ma)
                        or not isinstance(cfg, tuple) or len(cfg) != (3 if ghi else 2)
                        or (ghi and type(cfg[2]) is not bool)):
                    raise _loi('SDK_DANG_KY')
                cas = cfg[2] if ghi else False
                sql, bang = _kiem_sql(cfg[0], 'mod_' + ma_module, ghi, cas)
                schema = deepcopy(cfg[1])
                if not isinstance(schema, dict) or schema.get('type') != 'object':
                    raise _loi('SDK_DANG_KY')
                try:
                    validator.check_schema(schema)
                except Exception:
                    # Không sửa exception jsonschema/referencing (có thể frozen).
                    schema = None
                if schema is None:
                    raise _loi('SDK_DANG_KY') from None
                kq[ma] = (sql, validator(schema, format_checker=checker, registry=registry), cas, bang)
            return kq

        self.__doc, self.__ghi = dang_ky(truy_van, False), dang_ky(lenh, True)

    def _ngu_canh(self, tx):
        if not isinstance(tx, GiaoDich):
            raise _loi('SDK_MODULE', 403)
        if self.__tx_runtime is not None and tx is not self.__tx_runtime:
            raise _loi('SDK_MODULE', 403)
        ctx = _ctx(tx)
        if ctx.module != self.khai_bao.ma:
            raise _loi('SDK_MODULE', 403)
        return ctx

    def _cho_runtime(self, tx):
        """Façade riêng cho đúng tx; runtime sở hữu replay/biên nhận của route.

        Không đổi repository dùng chung giữa các request hoặc chế độ độc lập.
        """
        self._ngu_canh(tx)
        repo = object.__new__(DuLieuRieng)
        repo.khai_bao, repo.__cua = self.khai_bao, self.__cua
        repo.__doc, repo.__ghi = self.__doc, self.__ghi
        repo.__doi_tuong, repo.__quyen_doc = self.__doi_tuong, self.__quyen_doc
        repo.__khoa_con_tro = self.__khoa_con_tro
        repo.__tx_runtime = tx
        return repo

    def giao_dich(self, ctx):
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or ctx.module != self.khai_bao.ma):
            raise _loi('SDK_MODULE', 403)
        return self.__cua.giao_dich(ctx)

    def _tham_so(self, ds, ma, tham_so):
        if not isinstance(ma, str) or ma not in ds:
            raise _loi('SDK_CHUA_DANG_KY', 403)
        if not isinstance(tham_so, dict) or set(tham_so) & _CAM:
            raise _loi()
        cfg = ds[ma]
        data = deepcopy(tham_so)
        hop_le = False
        try:
            cfg[1].validate(data)
            # Không mang dữ liệu không JSON vào fingerprint hoặc cursor.
            json.dumps(data, allow_nan=False)
            hop_le = True
        except Exception:
            # Bỏ lỗi gốc, không gọi bộ dọn sửa thuộc tính exception frozen.
            pass
        if not hop_le:
            # Raise ngoài except để lỗi mới chỉ mang mã SDK, không giữ chain gốc.
            raise _loi() from None
        return cfg, data

    def _con_tro(self, ctx, ma, data, sau=None, token=None):
        pham_vi = [ctx.module, str(ctx.phap_nhan_id), ma, data]
        bam = hashlib.sha256(json.dumps(pham_vi, sort_keys=True).encode()).hexdigest()
        if token is None:
            raw = json.dumps([bam, str(sau)]).encode()
            ky = hmac.digest(self.__khoa_con_tro, raw, 'sha256')
            return base64.urlsafe_b64encode(ky + raw).decode()
        hop_le = False
        try:
            if not isinstance(token, str) or len(token) > 1024:
                raise ValueError()
            decoded = base64.b64decode(token, altchars=b'-_', validate=True)
            ky, raw = decoded[:32], decoded[32:]
            if not hmac.compare_digest(ky, hmac.digest(self.__khoa_con_tro, raw, 'sha256')):
                raise ValueError()
            scope, id_cu = json.loads(raw)
            if scope != bam:
                raise ValueError()
            sau = UUID(id_cu)
            hop_le = True
        except (ValueError, TypeError, UnicodeError):
            pass
        if not hop_le:
            raise _loi()
        return sau

    def doc(self, tx, ma_truy_van, tham_so) -> Trang[dict]:
        ctx = self._ngu_canh(tx)
        if not isinstance(tham_so, dict):
            raise _loi()
        data = {k: v for k, v in tham_so.items() if k not in _PHAN_TRANG}
        cfg, data = self._tham_so(self.__doc, ma_truy_van, data)
        n = tham_so.get('kich_thuoc_trang', 25)
        if type(n) is not int or not 1 <= n <= 100:
            raise _loi()
        token = tham_so.get('con_tro')
        sau = self._con_tro(ctx, ma_truy_van, data, token=token) if token is not None else None
        rows = _cac_dong(_sql(tx, 'SELECT coalesce(jsonb_agg(to_jsonb(_trang)), \'[]\'::jsonb) FROM ('
            'SELECT * FROM (' + cfg[0] + ') AS _doc WHERE phap_nhan_id = %(phap_nhan_id)s '
            'AND (%(_sdk_sau)s::uuid IS NULL OR id > %(_sdk_sau)s::uuid) '
            'ORDER BY id LIMIT %(_sdk_gioi_han)s) AS _trang',
            data | dict(phap_nhan_id=ctx.phap_nhan_id, _sdk_sau=sau, _sdk_gioi_han=n+1)))
        con_tiep = len(rows) > n
        rows = rows[:n]
        tiep = self._con_tro(ctx, ma_truy_van, data, sau=rows[-1]['id']) if con_tiep else None
        return Trang(rows, con_tiep, tiep)

    def ghi(self, tx, ma_lenh, tham_so, row_version, khoa) -> BienNhan:
        ctx = self._ngu_canh(tx)
        cfg, data = self._tham_so(self.__ghi, ma_lenh, tham_so)
        if (not isinstance(khoa, str) or khoa != ctx.khoa
                or not re.fullmatch(r'[A-Za-z0-9._:-]{16,128}', khoa)):
            raise _loi()
        if (cfg[2] and (not isinstance(row_version, str)
                       or not re.fullmatch(r'[0-9]{1,19}', row_version)
                       or int(row_version) > 9223372036854775807)
                or not cfg[2] and row_version is not None):
            raise _loi()
        id_dich = None
        try:
            id_dich = str(UUID(data['id']))
        except (ValueError, TypeError, KeyError, AttributeError):
            pass
        if id_dich is None:
            raise _loi()
        phien_ban = _phien_ban_contract(self.khai_bao, ctx.module)
        runtime = self.__tx_runtime is tx
        if not runtime:
            doi = (self.__doi_tuong(ma_lenh, data) if self.__doi_tuong else
                   dict(bang=cfg[3], id=id_dich))
            ts = dict(noi_dung=dict(ma_lenh=ma_lenh, tham_so=data, row_version=row_version),
                      doi_tuong=doi, phien_ban_contract=phien_ban)
            cu = bien_nhan.tra(tx, **ts)
            if cu is not None:
                return cu
        rows = _cac_dong(_sql(tx, 'WITH _ghi AS (' + cfg[0] + ') '
            'SELECT coalesce(jsonb_agg(to_jsonb(_ghi)), \'[]\'::jsonb) FROM _ghi',
            data | dict(phap_nhan_id=ctx.phap_nhan_id, row_version=row_version)))
        if cfg[2] and len(rows) != 1:
            raise _loi('SDK_ROW_VERSION', 409)
        kq = dict(danh_sach=rows)
        if runtime:
            return dict(id=None, ket_qua=kq, lap_lai=False)
        quyen = (self.__quyen_doc(ctx, ma_lenh, data, kq) if self.__quyen_doc else
                 dict(hanh_dong=ctx.hanh_dong.rsplit(':', 1)[0] + ':XEM',
                      doi_tuong=doi))
        if not isinstance(quyen, dict):
            raise _loi()
        if quyen.get('phien_ban_contract', phien_ban) != phien_ban:
            raise _loi('SDK_CONTRACT_BINDING')
        quyen = quyen | dict(phien_ban_contract=phien_ban)
        return bien_nhan.ghi(tx, **ts, ket_qua=kq, quyen_doc=quyen)
