"""SDK module 2.1: chạy backend theo bảng xử lý ``{hanh_dong.ma: hàm}`` (HOP-DONG-CONG a.10.6).

Module chỉ viết hàm nghiệp vụ; SDK dựng route từ ``hanh_dong`` của phiếu đã băm
(Core truyền vào ``cau_hinh_runtime['phieu']``), kiểm schema vào/ra, chạy hàm
trong giao dịch của chính module và trả lỗi nghiệp vụ theo ``ma_loi`` đã khai.

    def danh_sach(sdk, yeu_cau):        # yeu_cau: duong_dan, truy_van, than, ngu_canh
        return sdk.ngan('ho_so').doc({}, gioi_han=50)

    def chay(**tham_so_core):
        from kho_tri_thuc_sdk import module_runtime
        return module_runtime.chay_theo_khai_bao({'danh_sach_ho_so': danh_sach},
            su_kien={'quy_trinh.xong': nhan}, loi_nghiep_vu=LoiNghiepVu, **tham_so_core)

Hàm nhận sự kiện ``quy_trinh.xong`` nhận ``(sdk, su_kien)`` với ``tep_nut`` và
``ghep`` do SDK đọc từ Core theo ``viec_id`` (``xu_ly_su_kien_quy_trinh``).
Không có tên module nào trong SDK; không mở server riêng, không tự bind.
"""

from __future__ import annotations

from copy import deepcopy
import hashlib
import re
import socket
import threading
from types import SimpleNamespace
from uuid import UUID

from .bootstrap import Bootstrap, LoiBootstrap
from .giao_dich import CuaGiaoDich
from . import kenh_khung as k
from .kenh_core import GHI
from .ngan import BoNgan, doc_khai_bao
from .ngu_canh import _xoa_loi

DONG_TU = ('xem', 'xem_du', 'lap', 'sua', 'kiem', 'duyet', 'huy')
LOI_HTTP = (400, 403, 404, 409, 410, 413, 415, 422, 429, 500, 502, 503, 504)
_LOI_CHUAN = {'$ref': 'urn:ktt:contract:loi_chuan.v1'}
_CHONG_TRUNG = frozenset({'POST', 'PUT', 'PATCH'})
_NGAN_CORE_GHI = frozenset({'ngan_core.them', 'ngan_core.sua', 'ngan_core.ghi_lo'})
# SDK 2.1.1: route nội bộ nhận ``quy_trinh.xong`` của từng nút (Core gọi qua kênh có ký,
# không có trong registry HTTP của Core). Mã operation ``nut-xong.<nut>`` (``_`` đổi thành ``-``,
# biên nhận chống trùng chỉ nhận [A-Za-z0-9._:-]) không trùng mã ``hanh_dong`` của gói; binding do Core bổ sung ở hồ sơ runtime theo ``nut[]``.
TIEN_TO_NUT_XONG = 'nut-xong.'
_DUONG_NUT_XONG = '/_core/nut/{ma_nut}/quy-trinh-xong'
_VAO_NUT_XONG = {'type': 'object', 'additionalProperties': False, 'required': ['su_kien', 'viec_id'],
                 'properties': {'su_kien': {'enum': ['quy_trinh.xong', 'quy_trinh.loi']},
                                'ma_loi': {'type': 'string', 'pattern': '^[A-Z][A-Z0-9_]{0,79}$'},
                                'thong_diep': {'type': 'string', 'minLength': 1, 'maxLength': 500},
                                'viec_id': {'type': 'string', 'format': 'uuid'},
                                'id': {'type': 'string', 'maxLength': 200}},
                 'allOf': [{'if': {'properties': {'su_kien': {'const': 'quy_trinh.loi'}}},
                            'then': {'required': ['ma_loi', 'thong_diep']}}]}
_RA_NUT_XONG = {'type': 'object', 'additionalProperties': False, 'required': ['da_nhan', 'viec_id'],
                'properties': {'da_nhan': {'type': 'boolean'},
                               'viec_id': {'type': 'string', 'format': 'uuid'}}}


class LoiChayModule(RuntimeError):
    """Mã hữu hạn, không mang dữ liệu nghiệp vụ hay đường dẫn."""

    def __init__(self, ma):
        self.ma = ma
        super().__init__(ma)


def hanh_dong_mtq(ma_module, ma_quyen):
    """Cùng quy tắc Core: ``tai_nguyen.dong_tu`` -> ``MA:TAI_NGUYEN:DONG_TU``."""
    if (not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', ma_module or '')
            or not isinstance(ma_quyen, str)
            or not re.fullmatch(r'[a-z][a-z0-9_]{0,40}\.[a-z][a-z0-9_]{0,20}', ma_quyen)
            or ma_quyen.partition('.')[2] not in DONG_TU):
        raise LoiChayModule('SDK_PHIEU_KHONG_HOP_LE')
    tai_nguyen, _, dong_tu = ma_quyen.partition('.')
    return ':'.join((ma_module.upper(), tai_nguyen.upper(), dong_tu.upper()))


def _schema_goi(ma, bam, ref):
    if ref.startswith(('schema/', 'contract/')):
        return {'$ref': 'https://goi.invalid/' + ma + '/' + bam + '/' + ref}
    return {'$ref': ref if ref.startswith('urn:') else 'urn:ktt:contract:' + ref}


class KiemSchema:
    """Validator offline: bundle kỹ thuật Core + schema của gói (cùng URI như Core)."""

    def __init__(self, schemas, schemas_goi, *, ma, bam):
        from jsonschema import Draft202012Validator, FormatChecker
        from referencing import Registry, Resource
        from referencing.exceptions import NoSuchResource

        def offline(uri):
            raise NoSuchResource(ref=uri)

        registry = Registry(retrieve=offline)
        for uri, schema in (schemas or {}).items():
            registry = registry.with_resource(uri, Resource.from_contents(schema))
        for name, schema in (schemas_goi or {}).items():
            registry = registry.with_resource(_schema_goi(ma, bam, name)['$ref'],
                                              Resource.from_contents(schema))
        self._v, self._checker, self.registry = Draft202012Validator, FormatChecker(), registry

    def kiem(self, schema, value):
        try:
            return self._v(schema, registry=self.registry,
                           format_checker=self._checker).is_valid(value)
        except Exception:
            return False


class BangRoute:
    """``tra(method, path)`` như Registry phía Core; chỉ route bản 2 đã dựng."""

    def __init__(self, routes):
        self._routes = []
        for route in routes:
            params, pattern = [], []
            for seg in route.duong_dan.split('/'):
                if seg.startswith('{') and seg.endswith('}'):
                    params.append(seg[1:-1])
                    pattern.append('([^/]+)')
                else:
                    pattern.append(re.escape(seg))
            self._routes.append((route, re.compile('/'.join(pattern)), params))
        self._routes.sort(key=lambda r: len(r[2]))

    def tra(self, method, path):
        allowed = False
        for route, pattern, params in self._routes:
            matched = pattern.fullmatch(path)
            if matched:
                allowed = True
                if route.method == method:
                    return route, dict(zip(params, matched.groups()))
        raise LoiChayModule('SDK_ROUTE_KHONG_CO' if not allowed else 'SDK_PHUONG_THUC')


def _doi_tuong(op, tai_nguyen):
    target = op.get('doi_tuong')

    def doi_tuong(params, body):
        if target is None:
            return {'bang': tai_nguyen}
        nguon, _, ten = target['id_tu'].partition('.')
        value = params.get(ten) if nguon == 'duong_dan' else (
            body.get(ten) if isinstance(body, dict) else None)
        return {'bang': target['ngan'], 'id': str(UUID(value))}
    return doi_tuong


def _phan_hoi(status, body):
    from .module_runtime import PhanHoi
    return PhanHoi(status, body)


class _KetQua:
    """Đọc tệp kết quả qua kênh của request; không nhận danh tính từ module."""

    def __init__(self, context, *, thu_tu=0):
        self._context, self._thu_tu = context, thu_tu

    def _goi(self, operation, data):
        kenh = getattr(self._context, 'kenh_core', None)
        k._can(kenh is not None, 'CHUA_SAN_SANG')
        self._thu_tu += 1
        return kenh.goi(operation, data, ngu_canh=self._context.ctx,
                        thu_tu_con=self._thu_tu)

    def ds_tep(self, viec_id):
        """Trả danh sách {tep_id, ten, mime, kich_thuoc, sha256}."""
        got = self._goi('quy_trinh.ds_tep_ket_qua', {'viec_id': str(viec_id)})
        k._can(got.header['stream'] is None, 'PHAN_HOI_SAI_CONTRACT')
        result = got.json()
        k._can(type(result) is dict and type(result.get('danh_sach')) is list,
               'PHAN_HOI_SAI_CONTRACT')
        return result['danh_sach']

    def doc_tep(self, viec_id, tep_id):
        """Trả bytes đã kiểm kích thước và SHA-256, tối đa GIOI_HAN_TEP."""
        got = self._goi('quy_trinh.doc_tep_ket_qua',
                        {'viec_id': str(viec_id), 'tep_id': str(tep_id)})
        desc, content = got.header['stream'], got.than
        k._can(type(desc) is dict and type(content) is bytes
               and type(desc.get('kich_thuoc_byte')) is int
               and 0 <= desc['kich_thuoc_byte'] <= k.GIOI_HAN_TEP
               and len(content) <= k.GIOI_HAN_TEP, 'PHAN_HOI_SAI_CONTRACT')
        k._can(len(content) == desc['kich_thuoc_byte']
               and hashlib.sha256(content).hexdigest() == desc.get('sha256'),
               'PHAN_HOI_SAI_CONTRACT')
        return content


class _NganCore:
    """Nháp 28.5: ngăn qua kênh Core của request, chưa phát hành SDK.

    Danh tính/binding và khóa con do kênh lấy từ cha đã xác minh. Số thứ tự
    tăng trong một lượt handler; không tự thử lại hoặc mở giao dịch SQL.
    """

    def __init__(self, context):
        self._context, self._thu_tu = context, 0

    def __repr__(self):
        return 'NganCore(<an>)'

    def _goi(self, operation, data):
        kenh = getattr(self._context, 'kenh_core', None)
        k._can(kenh is not None, 'CHUA_SAN_SANG')
        self._thu_tu += 1
        got = kenh.goi(operation, data, ngu_canh=self._context.ctx,
                       thu_tu_con=self._thu_tu)
        k._can(got.header['stream'] is None, 'PHAN_HOI_SAI_CONTRACT')
        if operation in GHI:
            k._can(got.header['da_commit'] is True, 'PHAN_HOI_SAI_CONTRACT')
        try:
            result = got.json()
        except (k.LoiKenh, ValueError, UnicodeError) as exc:
            _xoa_loi(exc)
            raise k.LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
        k._can(type(result) is dict, 'PHAN_HOI_SAI_CONTRACT')
        return result

    def doc(self, ma_ngan, loc=None, gioi_han=50, con_tro=None):
        return self._goi('ngan_core.doc', dict(ma_ngan=ma_ngan,
            loc={} if loc is None else loc, gioi_han=gioi_han, con_tro=con_tro))

    def them(self, ma_ngan, dong):
        return self._goi('ngan_core.them', dict(ma_ngan=ma_ngan, dong=dong))

    def sua(self, ma_ngan, khoa, dong):
        return self._goi('ngan_core.sua', dict(ma_ngan=ma_ngan, khoa=khoa, dong=dong))

    def ghi_lo(self, lenh):
        return self._goi('ngan_core.ghi_lo', dict(lenh=lenh))


def _xu_ly(fn, op, *, ma, khai_bao_ngan, ma_loi, loi_nghiep_vu):
    """Bọc hàm nghiệp vụ thành handler (tx, context) của ModuleRuntime."""
    status_ok = 201 if op['phuong_thuc'] == 'POST' else 200

    def handler(tx, context):
        sdk = SimpleNamespace(ngan=BoNgan(tx, ma, khai_bao_ngan),
                              ket_qua=_KetQua(context),
                              ngan_core=_NganCore(context),
                              kenh_core=getattr(context, 'kenh_core', None),
                              dich_vu=getattr(context, 'dich_vu', None))
        yeu_cau = dict(duong_dan=dict(context.path or {}), truy_van=dict(context.query or {}),
                       than=deepcopy(context.body),
                       ngu_canh=dict(nguoi_dung_id=str(context.nguoi_dung_id),
                                     phap_nhan_id=str(context.phap_nhan_id)))
        try:
            ket_qua = fn(sdk, yeu_cau)
        except Exception as exc:
            code = getattr(exc, 'ma', None)
            if (loi_nghiep_vu is not None and isinstance(exc, loi_nghiep_vu)
                    and isinstance(code, str) and code in ma_loi):
                http, thong_diep = ma_loi[code]
                _xoa_loi(exc)
                return _phan_hoi(http, dict(ma=code, thong_diep=thong_diep,
                    request_id=context.request_id, thu_lai_duoc=False))
            raise
        return _phan_hoi(status_ok, ket_qua)
    # Điền mốc biên nhận trước khi runtime tra khóa, kể cả ghi ngăn module.
    # Chỉ nghiệp vụ ghi qua Core chạy trước transaction; ghi ngăn module
    # vẫn chạy trong transaction và sau bước tra biên nhận như trước.
    ghi_core = bool(_NGAN_CORE_GHI & set(op.get('sdk_dung', ())))
    if ghi_core or (op['phuong_thuc'] in _CHONG_TRUNG and op.get('doi_tuong') is None):
        from .module_runtime import HandlerCoChuanBi
        if op['phuong_thuc'] not in _CHONG_TRUNG:
            raise LoiChayModule('SDK_PHIEU_KHONG_HOP_LE')

        def chuan_bi(context):
            if set(context.doi_tuong) == {'bang'}:
                # Lệnh tạo chưa có ID dòng. Biên nhận dùng mốc pháp nhân đã
                # xác minh, giống cửa ngăn Core; không nhận ID từ thân gửi lên.
                context.doi_tuong = dict(context.doi_tuong, id=str(context.phap_nhan_id))
            return handler(None, context) if ghi_core else None

        return HandlerCoChuanBi(chuan_bi,
            lambda tx, context, result: result if ghi_core else handler(tx, context))
    return handler


def dung_bang_route(phieu, xu_ly, *, binding, ma_bam_goi, loi_nghiep_vu=None, su_kien=None):
    """Route module từ ``hanh_dong`` của phiếu bản 2; mỗi hành động phải có hàm."""
    if not isinstance(phieu, dict) or phieu.get('phien_ban_manifest') != 2:
        raise LoiChayModule('SDK_CAN_PHIEU_BAN_2')
    ma = phieu['ma']
    ops = phieu['hanh_dong']
    if not isinstance(xu_ly, dict) or set(xu_ly) != {op['ma'] for op in ops}:
        raise LoiChayModule('SDK_BANG_XU_LY_KHONG_KHOP')
    if any(not callable(f) for f in xu_ly.values()):
        raise LoiChayModule('SDK_BANG_XU_LY_KHONG_KHOP')
    khai_bao_ngan = doc_khai_bao(phieu)
    ma_loi = {e['ma']: (e['http'], e['thong_diep']) for e in phieu['ma_loi']}
    routes = []
    for op in ops:
        if op['kieu'] != 'dong_bo':
            # Chạy nền qua hàng việc chung: chưa mở ở SDK 2.1.
            raise LoiChayModule('SDK_CHUA_HO_TRO_CHAY_NEN')
        pin = binding[op['ma']]
        action = hanh_dong_mtq(ma, op['quyen'])
        tai_nguyen = op['quyen'].partition('.')[0]
        method, path = op['phuong_thuc'], op['duong_dan']
        params = re.findall(r'\{([a-z][a-z0-9_]*)\}', path)
        target = op.get('doi_tuong')
        ident = (target['id_tu'].partition('.')[2]
                 if target is not None and target['id_tu'].startswith('duong_dan.') else None)
        output = _schema_goi(ma, ma_bam_goi, op['dau_ra']) if 'dau_ra' in op else {}
        dau_vao = _schema_goi(ma, ma_bam_goi, op['dau_vao']) if 'dau_vao' in op else {}
        if method == 'GET':
            dau_vao = {'anyOf': [dau_vao, {'type': 'null'}]}
        status_ok = (201, 200) if method == 'POST' else (200,)
        contract = pin['phien_ban_contract']
        doc = action.rsplit(':', 1)[0] + ':XEM'
        routes.append(SimpleNamespace(
            method=method, duong_dan='/api/v1/module/' + ma + path, module=ma,
            operation=op['ma'], hanh_dong=action, chu_so_huu='module',
            dau_vao=dau_vao, dau_ra={**{s: output for s in status_ok},
                                     **{s: _LOI_CHUAN for s in LOI_HTTP}},
            ma_loi={(http, code): msg for code, (http, msg) in ma_loi.items()},
            doi_tuong=_doi_tuong(op, tai_nguyen), loai='doi_tuong', thu_tu=None,
            query_schema={'type': 'object', 'maxProperties': 20,
                          'propertyNames': {'pattern': '^[a-z][a-z0-9_]{0,62}$'},
                          'additionalProperties': {'type': 'string', 'maxLength': 200}},
            path_schema={'type': 'object', 'additionalProperties': False, 'required': params,
                         'properties': {n: {'type': 'string', 'format': 'uuid'} if n == ident
                                        else {'type': 'string', 'minLength': 1, 'maxLength': 200}
                                        for n in params}},
            truong_cas=(), ghi=method != 'GET', chong_trung=method in _CHONG_TRUNG,
            viec_lau=False, pham_vi='phap_nhan', phien='bat_buoc',
            phien_ban_goi=phieu['phien_ban'], ma_bam_goi=ma_bam_goi,
            phien_ban_contract=contract,
            quyen_doc=lambda ctx, body, doc=doc, contract=contract: dict(
                hanh_dong=doc, doi_tuong=ctx.doi_tuong, phien_ban_contract=contract),
            handler=_xu_ly(xu_ly[op['ma']], op, ma=ma, khai_bao_ngan=khai_bao_ngan,
                           ma_loi=ma_loi, loi_nghiep_vu=loi_nghiep_vu)))
    routes.extend(_route_nut_xong(phieu, binding, su_kien, ma_bam_goi=ma_bam_goi,
                                  khai_bao_ngan=khai_bao_ngan))
    return BangRoute(routes)


def _route_nut_xong(phieu, binding, su_kien, *, ma_bam_goi, khai_bao_ngan):
    """SDK 2.1.1: mỗi nút có binding nội bộ thì có một route POST nhận ``quy_trinh.xong``.

    Dùng ủy nhiệm Core cấp cho người bấm nút (quyền của nút); ghi Core chạy trước
    giao dịch module nếu nút khai thao tác ghi Core.
    Chống trùng theo khóa Core gửi (``tiep_nhan`` của module), nên Core gửi lại không ghi đôi.
    SDK 2.5.0: cùng route nhận cả hai sự kiện; thiếu hàm nhận thì trả nhận (no-op)."""
    ma = phieu['ma']
    routes = []
    for nut in phieu.get('nut') or []:
        ma_nut = nut.get('ma') if isinstance(nut, dict) else None
        op = TIEN_TO_NUT_XONG + str(ma_nut).replace('_', '-')
        if (not isinstance(ma_nut, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,31}', ma_nut)
                or op not in binding or not isinstance(nut.get('quyen'), str)):
            continue
        pin = binding[op]
        action = hanh_dong_mtq(ma, nut['quyen'])
        contract = pin['phien_ban_contract']
        doc = action.rsplit(':', 1)[0] + ':XEM'
        tai_nguyen = nut['quyen'].partition('.')[0]
        routes.append(SimpleNamespace(
            method='POST', duong_dan='/api/v1/module/' + ma + _DUONG_NUT_XONG.replace('{ma_nut}', ma_nut),
            module=ma, operation=op, hanh_dong=action, chu_so_huu='module',
            dau_vao=_VAO_NUT_XONG, dau_ra={200: _RA_NUT_XONG, **{s: _LOI_CHUAN for s in LOI_HTTP}},
            # Biên nhận V2 cần UUID đích ổn định trước khi chạy hàm nhận;
            # dùng việc quy trình để lần giao lại tra đúng biên nhận đã ghi.
            ma_loi={}, doi_tuong=lambda params, body, tai_nguyen=tai_nguyen: {
                'bang': tai_nguyen, 'id': str(UUID(body['viec_id']))},
            loai='doi_tuong', thu_tu=None,
            query_schema={'type': 'object', 'additionalProperties': False},
            path_schema=None, truong_cas=(), ghi=True, chong_trung=True, viec_lau=False,
            pham_vi='phap_nhan', phien='bat_buoc', phien_ban_goi=phieu['phien_ban'],
            ma_bam_goi=ma_bam_goi, phien_ban_contract=contract,
            quyen_doc=lambda ctx, body, doc=doc, contract=contract: dict(
                hanh_dong=doc, doi_tuong=ctx.doi_tuong, phien_ban_contract=contract),
            handler=_xu_ly_nut_xong(su_kien or {}, nut=nut, ma=ma, khai_bao_ngan=khai_bao_ngan)))
    return routes


def _xu_ly_nut_xong(fn, *, ma, khai_bao_ngan, nut=None):
    def handler(tx, context):
        kenh = getattr(context, 'kenh_core', None)
        if kenh is None:
            raise LoiChayModule('SDK_CAU_HINH_KHONG_HOP_LE')
        sdk = SimpleNamespace(ngan=BoNgan(tx, ma, khai_bao_ngan),
                              ket_qua=_KetQua(context, thu_tu=1),
                              ngan_core=_NganCore(context), kenh_core=kenh,
                              dich_vu=getattr(context, 'dich_vu', None))
        than = context.body

        def doc_ket_qua(viec_id):
            got = kenh.goi('quy_trinh.ket_qua', {'viec_id': viec_id},
                           ngu_canh=context.ctx, thu_tu_con=1)
            return got.json() if hasattr(got, 'json') else got

        handlers = fn if isinstance(fn, dict) else {'quy_trinh.xong': fn}
        xu_ly_su_kien_quy_trinh(than, handlers, sdk, doc_ket_qua=doc_ket_qua)
        return _phan_hoi(200, dict(da_nhan=True, viec_id=str(UUID(than['viec_id']))))
    if GHI & set((nut or {}).get('sdk_dung', ())):
        from .module_runtime import HandlerCoChuanBi
        return HandlerCoChuanBi(lambda context: handler(None, context),
                                lambda tx, context, result: result)
    return handler


def xu_ly_su_kien_quy_trinh(su_kien, handlers, sdk, *, doc_ket_qua):
    """Sự kiện ``quy_trinh.xong``/``quy_trinh.loi``: thông báo chỉ mang tham chiếu
    (``viec_id``); SDK đọc ``tep_nut`` + ``ghep`` từ Core qua ``doc_ket_qua(viec_id)``
    rồi gọi hàm nhận của module khi XONG. Khi LOI, chuyển ma_loi/thong_diep an toàn
    trực tiếp, không đọc kết quả. Giữ cách đọc cũ cho sự kiện chỉ có tham chiếu.
    Thiếu hàm nhận thì bỏ qua (module không cần khai)."""
    if not isinstance(su_kien, dict) or su_kien.get('su_kien') not in (
            'quy_trinh.xong', 'quy_trinh.loi'):
        raise LoiChayModule('SDK_SU_KIEN_KHONG_HOP_LE')
    fn = (handlers or {}).get(su_kien['su_kien'])
    if fn is None:
        return None
    try:
        viec_id = str(UUID(su_kien.get('viec_id')))
    except (TypeError, ValueError):
        raise LoiChayModule('SDK_SU_KIEN_KHONG_HOP_LE') from None
    if su_kien['su_kien'] == 'quy_trinh.loi' and (
            'ma_loi' in su_kien or 'thong_diep' in su_kien):
        ma, thong_diep = su_kien.get('ma_loi'), su_kien.get('thong_diep')
        if (not isinstance(ma, str) or not re.fullmatch(r'[A-Z][A-Z0-9_]{0,79}', ma)
                or not isinstance(thong_diep, str) or not 1 <= len(thong_diep) <= 500):
            raise LoiChayModule('SDK_SU_KIEN_KHONG_HOP_LE')
        # Không đọc kết quả của việc lỗi; chỉ dùng phong bì an toàn Core đã ký.
        return fn(sdk, dict(su_kien='quy_trinh.loi', id=su_kien.get('id'), viec_id=viec_id,
                            ma_loi=ma, thong_diep=thong_diep,
                            loi={'ma': ma, 'thong_diep': thong_diep, 'thu_lai_duoc': False}))
    data = doc_ket_qua(viec_id)
    if not isinstance(data, dict) or str(data.get('viec_id')) != viec_id:
        raise LoiChayModule('SDK_SU_KIEN_KHONG_HOP_LE')
    than = dict(su_kien=su_kien['su_kien'], id=su_kien.get('id'), viec_id=viec_id,
                tep_nut=deepcopy(data.get('tep_nut')), ghep=deepcopy(data.get('ghep') or []),
                loi=deepcopy(data.get('loi')))
    return fn(sdk, than)


class _VongNhan:
    def __init__(self, runtime):
        self.runtime = runtime
        self.worker = threading.Thread(target=self._chay, name='module-runtime', daemon=True)

    def _chay(self):
        try:
            self.runtime.chay()
        except Exception as exc:
            _xoa_loi(exc)
            self.runtime.ngung_accept()

    def drain(self):
        if not self.runtime.drain(timeout=0.1):
            return False
        if self.worker.ident is not None:
            self.worker.join(0.3)
        return not self.worker.is_alive()


def chay_theo_khai_bao(xu_ly, *, su_kien=None, loi_nghiep_vu=None, kiem_chu_ky, tao_ket_noi,
                       cau_hinh_runtime, stdin=None, stdout=None):
    """Điểm vào chung do backend gói gọi từ ``chay(**tham_so_core)``."""
    from .module_runtime import ModuleRuntime

    if (not callable(kiem_chu_ky) or not callable(tao_ket_noi)
            or not isinstance(cau_hinh_runtime, dict) or 'phieu' not in cau_hinh_runtime):
        raise LoiChayModule('SDK_CAU_HINH_KHONG_HOP_LE')
    if su_kien is not None and (not isinstance(su_kien, dict)
                                or any(not callable(f) for f in su_kien.values())):
        raise LoiChayModule('SDK_CAU_HINH_KHONG_HOP_LE')
    cfg = cau_hinh_runtime
    phieu, bam = cfg['phieu'], cfg['ma_bam_goi']
    bang = dung_bang_route(phieu, xu_ly, binding=cfg['binding'], ma_bam_goi=bam,
                           loi_nghiep_vu=loi_nghiep_vu, su_kien=su_kien)
    bootstrap = Bootstrap.nhan(kiem_chu_ky=kiem_chu_ky, stdin=stdin, stdout=stdout)
    vong, da_dong, ma_loi = None, False, 'SDK_MODULE_RUNTIME_LOI'
    try:
        if bootstrap.bo_doc.module != phieu['ma']:
            raise LoiBootstrap('SDK_SAI_MODULE')
        login = bootstrap.tham_so['dang_nhap_csdl']
        ket_noi = tao_ket_noi(dang_nhap_csdl=login, cau_hinh=bootstrap.tham_so['csdl'])
        cua = CuaGiaoDich(module=phieu['ma'], dang_nhap_csdl=login, ket_noi=ket_noi)
        if bootstrap.socket.getsockopt(socket.SOL_SOCKET, socket.SO_ACCEPTCONN) != 1:
            raise LoiBootstrap('SDK_LISTENER_CHUA_NGHE')
        kiem = KiemSchema(cfg['schemas'], cfg.get('schemas_goi'), ma=phieu['ma'], bam=bam)

        def san_sang():
            nonlocal vong
            runtime = ModuleRuntime(bootstrap=bootstrap, khoa_cong_khai=cfg['khoa_cong_khai'],
                core_epoch=cfg['core_epoch'], registry=bang, kiem=kiem, cua_giao_dich=cua,
                binding=lambda route: (cfg['binding'][route.operation]['contract_id'],
                                       cfg['binding'][route.operation]['ma_bam_schema']),
                binding_core=cfg['binding_core'])
            vong = _VongNhan(runtime)
            return True

        contracts = sorted({p['contract_id'] for p in cfg['binding'].values()})
        bootstrap.bao_san_sang(phien_ban=phieu['phien_ban'], contracts=contracts,
                               kiem_san_sang=san_sang)
        vong.worker.start()
        bootstrap.cho_thu_hoi(ngung_accept=vong.runtime.ngung_accept, drain=vong.drain)
        da_dong = True
    except Exception as exc:
        code = exc.ma if isinstance(exc, (LoiBootstrap, LoiChayModule)) else ma_loi
        _xoa_loi(exc)
        raise LoiBootstrap(code) from None
    finally:
        if vong is not None:
            vong.runtime.ngung_accept()
            while not vong.drain():
                threading.Event().wait(0.05)
        if not da_dong:
            bootstrap.socket.close()
        bootstrap.bi_mat.thu_hoi()
