"""Client quy trình qua kênh Core do bootstrap cấp; không import runner/SQL.

kenh_core.goi(operation, ctx, method=..., duong_dan=..., body=..., headers=...)
chuyển yêu cầu HTTP tới Core và trả body đã giải mã (hoặc lỗi có ma/status).
N2 dùng operation SDK nội bộ; adapter HTTP cũ được giữ tương thích.
Ánh xạ quyền/tham chiếu chạy quy trình thuộc adapter Core.
Engine chỉ có GiuViec, không có NguCanh request để bắt đầu quy trình.
"""

import re
import time
from typing import TypedDict
from urllib.parse import urlencode
from uuid import UUID

from collections.abc import Mapping

from .dich_vu import LoiDichVu, _DichVu

from .engine import KenhCore
from .kenh_core import KenhCore as KenhModuleCore
from . import kenh_khung as k
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


class BienNhanViec(TypedDict):
    viec_id: str
    trang_thai: str
    request_id: str


class QuyTrinh(_DichVu):
    __slots__ = ('__kenh', '__tham_chieu', '__binding')

    def __init__(self, kenh_core=None, *, tham_chieu=None, ngu_canh=None):
        if kenh_core is not None and not isinstance(kenh_core, KenhCore):
            raise TypeError('Cần kênh Core do bootstrap cấp')
        if tham_chieu is not None and not callable(tham_chieu):
            raise TypeError('Cần resolver tham chiếu của module')
        if ngu_canh is not None and not callable(ngu_canh):
            raise TypeError('Cần bộ cấp ngữ cảnh do bootstrap cung cấp')
        self.__kenh, self.__tham_chieu = kenh_core, tham_chieu
        self.__binding = ngu_canh

    def _ctx(self, ctx):
        if not isinstance(ctx, NguCanh):
            raise LoiDichVu('QUY_TRINH_PHIEN', 403)
        if ctx._da_kiem is not _DA_KIEM or time.time() >= ctx.hieu_luc_den:
            raise LoiDichVu('QUY_TRINH_PHIEN', 401)
        if ctx.module == 'core' or not ctx.hanh_dong.startswith(ctx.module.upper() + ':'):
            raise LoiDichVu('QUY_TRINH_PHIEN', 403)

    def _goi(self, ctx, operation, method, path, *, body=None, khoa=None):
        self._ctx(ctx)
        if self.__kenh is None:
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        headers = {'X-Phap-Nhan-Id': str(ctx.phap_nhan_id)}
        if operation == 'quy_trinh.chay':
            headers['X-Module-Ma'] = ctx.module
        if khoa is not None:
            headers['Idempotency-Key'] = khoa
        ma, status = 'CHUA_SAN_SANG', 503
        try:
            return self.__kenh.goi(operation, ctx, method=method, duong_dan=path,
                                   body=body, headers=headers)
        except Exception as exc:
            code = getattr(exc, 'ma', None)
            http = getattr(exc, 'http_status', getattr(exc, 'status', None))
            if code in {'QUY_TRINH_PHIEN', 'QUY_TRINH_CAS', 'QUY_TRINH_TRUNG',
                        'QUY_TRINH_DAU_VAO', 'VIEC_CONG_TAC', 'CHUA_DANG_NHAP',
                        'KHONG_DU_QUYEN', 'XUNG_DOT_PHIEN_BAN', 'SAI_SCHEMA',
                        'CHUA_SAN_SANG', 'KHONG_TIM_THAY',
                        'KHOA_CHONG_TRUNG_KHAC_NOI_DUNG'}:
                ma = code
                status = (503 if code == 'VIEC_CONG_TAC' else
                          http if type(http) is int and http in {401, 403, 404, 409, 422, 503}
                          else 503)
            _xoa_loi(exc)
        finally:
            body = headers = None
        raise LoiDichVu(ma, status) from None

    def _goi_kenh(self, ctx, operation, data, khoa=None):
        self._ctx(ctx)
        if self.__binding is None:
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        ma, status = 'LOI_NOI_BO', 500
        try:
            binding = self.__binding(ctx, operation)
            k._can(type(binding) is dict and 'ngu_canh' in binding
                   and not (binding.keys() - {'ngu_canh', 'parent', 'thu_tu_con'}))
            h = binding['ngu_canh']
            k._can(isinstance(h, Mapping) and all(h.get(key) == value for key, value in {
                'module': ctx.module, 'module_nguon': ctx.module,
                'nguoi_dung_id': str(ctx.nguoi_dung_id),
                'phap_nhan_id': str(ctx.phap_nhan_id), 'instance_id': str(ctx.instance_id),
                'hanh_dong': ctx.hanh_dong}.items()), 'KENH_KHONG_DU_QUYEN')
            response = self.__kenh.goi(operation, data, khoa=khoa, **binding)
            k._can(response.header.get('stream') is None, 'PHAN_HOI_SAI_CONTRACT')
            if operation != 'quy_trinh.liet_ke':
                k._can(response.header.get('da_commit') is True, 'PHAN_HOI_SAI_CONTRACT')
            return response.json()
        except Exception as exc:
            if isinstance(exc, k.LoiKenh):
                ma, status = exc.ma, exc.http_status
            _xoa_loi(exc)
        raise LoiDichVu(ma, status) from None

    @staticmethod
    def _bien_nhan(result):
        if (type(result) is not dict
                or result.keys() != {'viec_id', 'trang_thai', 'request_id'}
                or not k._uuid(result.get('viec_id')) or not k._uuid(result.get('request_id'))
                or result.get('trang_thai') not in {'queued', 'running', 'waiting_input',
                    'cancel_requested', 'cancelled', 'succeeded', 'failed', 'interrupted'}):
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
        return result

    def liet_ke(self, ctx):
        if isinstance(self.__kenh, KenhModuleCore):
            result = self._goi_kenh(ctx, 'quy_trinh.liet_ke', {})
            if (type(result) is not dict or result.keys() != {'danh_sach'}
                    or type(result['danh_sach']) is not list
                    or any(type(row) is not dict or row.get('module') != ctx.module
                        or row.get('phap_nhan_id') != str(ctx.phap_nhan_id)
                        for row in result['danh_sach'])):
                raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
            return result['danh_sach']
        # API phân trang; SDK v1.0 trả danh sách, không bỏ mất các trang sau.
        self._ctx(ctx)
        base = '/api/v1/quy-trinh?' + urlencode({'module': ctx.module,
            'hanh_dong': ctx.hanh_dong.rsplit(':', 1)[0] + ':XEM'})
        rows, seen, path = [], set(), base
        while True:
            page = self._goi(ctx, 'quy_trinh.doc', 'GET', path)
            if (not isinstance(page, dict) or not isinstance(page.get('danh_sach'), list)
                    or any(not isinstance(r, dict) or r.get('module') != ctx.module
                           for r in page['danh_sach'])
                    or type(page.get('con_tiep')) is not bool):
                raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
            rows.extend(page['danh_sach'])
            if not page['con_tiep']:
                return rows
            token = page.get('con_tro_tiep')
            if (not isinstance(token, str) or not re.fullmatch('[A-Za-z0-9_.=-]{1,4096}', token)
                    or token in seen):
                raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
            seen.add(token)
            path = base + '&' + urlencode({'con_tro': token})

    def bat_dau(self, ctx, ma, phien_ban, dau_vao, khoa) -> BienNhanViec:
        self._ctx(ctx)
        if (not isinstance(ma, str) or not re.fullmatch('[a-z][a-z0-9_]{0,79}', ma)
                or not isinstance(phien_ban, str) or not 1 <= len(phien_ban) <= 64
                or not isinstance(dau_vao, dict)
                or dau_vao.keys() != {'tai_lieu_ids', 'ket_qua_ids'}
                or not isinstance(khoa, str)
                or not re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa)):
            raise LoiDichVu('QUY_TRINH_DAU_VAO', 422)
        try:
            for ids in dau_vao.values():
                if (not isinstance(ids, list) or len(ids) > 100
                        or any(not isinstance(id_, str) or str(UUID(id_)) != id_.lower()
                               for id_ in ids)
                        or len(set(ids)) != len(ids)):
                    raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise LoiDichVu('QUY_TRINH_DAU_VAO', 422) from None
        if isinstance(self.__kenh, KenhModuleCore):
            return self._bien_nhan(self._goi_kenh(ctx, 'quy_trinh.bat_dau',
                dict(ma=ma, phien_ban=phien_ban, dau_vao=dau_vao), khoa))
        result = self._goi(ctx, 'quy_trinh.chay', 'POST',
            '/api/v1/quy-trinh/' + ma + '/lan-chay', khoa=khoa,
            body=dict(phien_ban=phien_ban, **dau_vao))
        try:
            if not isinstance(result, dict):
                raise ValueError()
            if (result.keys() == {'viec_id', 'trang_thai', 'request_id'}
                    and result['trang_thai'] in {'queued', 'running', 'waiting_input',
                        'cancel_requested', 'cancelled', 'succeeded', 'failed', 'interrupted'}):
                UUID(result['viec_id'])
            else:
                raise ValueError()
            UUID(result['request_id'])
        except (ValueError, TypeError, AttributeError):
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502) from None
        return result

    def tiep_tuc(self, ctx, lan_chay_id, buoc, revision_truoc, du_lieu, khoa) -> BienNhanViec:
        # Không thêm HTTP chung; module dùng binding N2 đã đăng ký.
        if not isinstance(self.__kenh, KenhModuleCore):
            raise LoiDichVu('CHUA_HO_TRO', 501)
        self._ctx(ctx)
        if (not k._uuid(lan_chay_id) or type(buoc) is not str
                or not re.fullmatch('[a-z][a-z0-9_]{0,39}', buoc)
                or type(revision_truoc) is not str
                or not re.fullmatch('0|[1-9][0-9]{0,18}', revision_truoc)
                or int(revision_truoc) >= 2**63 or type(du_lieu) is not dict
                or type(khoa) is not str or not re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa)):
            raise LoiDichVu('QUY_TRINH_DAU_VAO', 422)
        return self._bien_nhan(self._goi_kenh(ctx, 'quy_trinh.tiep_tuc', dict(
            lan_chay_id=lan_chay_id, buoc=buoc, revision_truoc=revision_truoc,
            du_lieu=du_lieu), khoa))


_mac_dinh = QuyTrinh()
liet_ke = _mac_dinh.liet_ke
bat_dau = _mac_dinh.bat_dau
tiep_tuc = _mac_dinh.tiep_tuc
