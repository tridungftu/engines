"""Client chiều về trên kết nối đã được runtime module xác thực.

Runtime sở hữu socket/reader, gọi nhan_frame sau kiểm proof và tuần tự hóa
gui_frame(header, bytes, han_monotonic) (bao gồm số proof và deadline gửi).
Không mở listener, kết nối hay import server.
Không tự retry: caller giữ khóa và đối chiếu khi mất phản hồi sau dispatch.
"""

from __future__ import annotations

from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import queue
import threading
import time
from uuid import uuid4

from . import kenh_khung as k
from .engine import KenhCore as _KenhCore


GHI = frozenset({
    'ket_qua.ghi', 'ket_qua.tao_revision',
    'tai_lieu.tao', 'tep.tai_len', 'engine.gui_viec', 'quy_trinh.bat_dau',
    'quy_trinh.tiep_tuc', 'viec.huy', 'kiem_toan.ghi_so_do',
    'viec.bao_tien_do',
    'ma_hoa.ma_hoa', 'ma_hoa.tra_hmac', 'ma_hoa.hien_thi_rut_gon', 'ma_hoa.giai_ma',
})


def dieu_khien(kieu, h, than=b'', **them):
    return dict(protocol=k.PROTOCOL, phien_ban=k.PHIEN_BAN, kieu=kieu,
        chieu=h['chieu'], request_id=h['request_id'], call_id=h['call_id'],
        hash_than=hashlib.sha256(than).hexdigest(), **them)


class _HangDoi(queue.Queue):
    """Reader không chờ consumer; hàng đầy kết thúc riêng call bằng 429."""

    def __init__(self, maxsize):
        super().__init__(maxsize=maxsize)
        self.loi = None

    def them(self, frame):
        try:
            self.put_nowait(frame)
        except queue.Full:
            self.loi = k.LoiKenh('VUOT_HAN_MUC')

    def nhan(self, han):
        if self.loi is not None:
            raise self.loi
        try:
            frame = self.get(timeout=max(0, han - time.monotonic()))
        except queue.Empty:
            raise k.LoiKenh('PHAN_HOI_QUA_HAN') from None
        if self.loi is not None:
            raise self.loi
        k._can(frame is not None, 'PHAN_HOI_QUA_HAN')
        return frame


class _CuaSoChunk:
    """Tối đa bốn chunk chưa ACK; end chỉ đi sau ACK cuối cùng.

    ACK phải tuần tự, đúng call/trace/stream/chiều. Callback nhận chạy ở
    worker, reader chỉ đặt frame vào hàng hữu hạn và không chờ ACK.
    """

    def __init__(self, gui_frame, header, descriptor, nhan_ack):
        self._gui, self._h, self._sid = gui_frame, header, descriptor['stream_id']
        self._nhan = nhan_ack
        self._da_gui = self._da_ack = 0

    def _doi(self):
        f = self._nhan()
        h = f.header
        k._can(h['kieu'] == 'ack_chunk' and not f.than
               and h['call_id'] == self._h['call_id']
               and h['request_id'] == self._h['request_id']
               and h['chieu'] != self._h['chieu']
               and h['stream_id'] == self._sid
               and h['thu_tu_chunk'] == self._da_ack, 'PHAN_HOI_SAI_CONTRACT')
        self._da_ack += 1

    def gui(self, h, raw):
        if h['kieu'] == 'chunk':
            if self._da_gui - self._da_ack == 4:
                self._doi()
            self._gui(h, raw)
            self._da_gui += 1
        else:
            k._can(h['kieu'] == 'end')
            self.doi_het()
            self._gui(h, raw)

    def doi_het(self):
        while self._da_ack < self._da_gui:
            self._doi()


class TepHuuHan:
    """Spool RAM có chặn bytes thực; không nhận đường dẫn kho hoặc URL."""

    def __init__(self, cac_chunk, *, mime, ten, gioi_han=k.GIOI_HAN_TEP):
        k._can(type(gioi_han) is int and 0 <= gioi_han <= k.GIOI_HAN_TEP)
        data = bytearray()
        for chunk in cac_chunk:
            k._can(type(chunk) is bytes)
            k._can(len(data) + len(chunk) <= gioi_han, 'VUOT_GIOI_HAN_KICH_THUOC')
            data.extend(chunk)
        self.than = bytes(data)
        self.descriptor = dict(stream_id=str(uuid4()), kich_thuoc_byte=len(data),
            sha256=hashlib.sha256(data).hexdigest(), mime=mime, ten=ten)
        k.BoDemStream(self.descriptor, gioi_han=gioi_han)

    def __repr__(self):
        return 'TepHuuHan(<an>)'

    def gui(self, gui_frame, header):
        # Runtime truyền callback _CuaSoChunk.gui để giữ cửa sổ ACK cả khi
        # producer thay cách chia chunk; không giữ transaction trong khi chờ.
        for i, pos in enumerate(range(0, len(self.than), k.GIOI_HAN_CHUNK)):
            chunk = self.than[pos:pos + k.GIOI_HAN_CHUNK]
            gui_frame(dieu_khien('chunk', header, chunk,
                stream_id=self.descriptor['stream_id'], thu_tu_chunk=i,
                kich_thuoc_byte=len(chunk)), chunk)
        gui_frame(dieu_khien('end', header, stream_id=self.descriptor['stream_id'],
                            kich_thuoc_byte=len(self.than)), b'')


@dataclass(frozen=True, repr=False)
class PhanHoiCore:
    header: dict
    than: bytes

    def json(self):
        return k._doc_json(self.than)


class KenhCore(_KenhCore):
    """Kênh N2 cụ thể thuộc kiểu kênh bootstrap chung của SDK."""

    def __init__(self, *, gui_frame, kiem_the, tx_dang_mo, timeout=30):
        k._can(callable(gui_frame) and isinstance(kiem_the, k.BoKiemThe)
               and callable(tx_dang_mo) and type(timeout) in (int, float)
               and 0 < timeout <= 30)
        self._gui, self._kiem, self._tx = gui_frame, kiem_the, tx_dang_mo
        self.timeout = timeout
        self._khoa, self._cho = threading.Lock(), {}
        self._dong = False

    def __repr__(self):
        return 'KenhCore(<an>)'

    def dong(self):
        with self._khoa:
            self._dong = True
            cho = list(self._cho.values())
        for q in cho:
            q.them(None)

    def nhan_frame(self, frame):
        """Chỉ nhận Frame đã kiểm proof của đầu Core, trên reader runtime."""
        h = frame.header
        k._can(h['chieu'] == 'core_den_con' and h['kieu'] in
               {'cap_the', 'response', 'chunk', 'end', 'ack_chunk'},
               'KENH_XAC_THUC_KHONG_HOP_LE')
        with self._khoa:
            q = self._cho.get(h['call_id'])
        if q is not None:
            q.them(frame)

    def goi(self, operation, du_lieu, *, ngu_canh, parent=None, thu_tu_con=None,
            khoa=None, tep=None):
        """ngu_canh là binding đã ghim; parent là request handler đã kiểm thẻ.

        thu_tu_con do nghiệp vụ giữ ổn định qua replay, không đếm theo thread.
        tx_dang_mo do runtime ghép với transaction module, không lấy từ JSON.
        """
        k._can(operation in k.OPERATION_CORE, 'KHONG_TIM_THAY')
        ghi = operation in GHI
        k._can(not (ghi and self._tx()), 'XUNG_DOT')
        h = dict(ngu_canh)
        for ten in ('the_ky', 'con_tro'):
            h.pop(ten, None)
        if parent is not None:
            self._kiem.kiem(parent)
            h.update({ten: parent[ten] for ten in ('request_id', 'nguoi_dung_id',
                'phap_nhan_id', 'pham_vi', 'uy_nhiem', 'deadline')})
            k._can(type(thu_tu_con) is int and thu_tu_con > 0)
            if ghi:
                k._can(parent['khoa'] is not None, 'XUNG_DOT')
                khoa = k.dan_khoa_con(parent['khoa'].encode('utf-8'), operation, thu_tu_con)
        else:
            k._can(thu_tu_con is None)
        raw = k._json(du_lieu)
        now = time.time()
        deadline = min(now + self.timeout,
            datetime.fromisoformat(h['deadline'].replace('Z', '+00:00')).timestamp())
        han = time.monotonic() + max(0, deadline - now)
        h.update(protocol=k.PROTOCOL, phien_ban=k.PHIEN_BAN, kieu='request',
            chieu='con_den_core', operation=operation, call_id=str(uuid4()),
            parent_call_id=None if parent is None else parent['call_id'],
            thu_tu_con=thu_tu_con, module_nguon=h['module'], khoa=khoa if ghi else None,
            hash_than=hashlib.sha256(raw).hexdigest(), http=None,
            deadline=datetime.fromtimestamp(deadline, timezone.utc).isoformat(),
            stream=None if tep is None else tep.descriptor)
        k.kiem_header(h, can_the=False)
        k._can(len(raw) <= k.GIOI_HAN_JSON, 'VUOT_GIOI_HAN_KICH_THUOC')
        # Một response + bốn chunk, thêm một control; không buffer cả tệp.
        q = _HangDoi(6)
        with self._khoa:
            k._can(not self._dong, 'CHUA_SAN_SANG')
            k._can(len(self._cho) < 8, 'VUOT_HAN_MUC')
            self._cho[h['call_id']] = q

        def gui(header, than):
            k._can(time.monotonic() < han, 'PHAN_HOI_QUA_HAN')
            self._gui(header, than, han)

        def nhan():
            f = q.nhan(han)
            k._can(f.header['request_id'] == h['request_id'], 'PHAN_HOI_SAI_CONTRACT')
            if f.header['kieu'] == 'response':
                k._can(f.header['operation'] == operation, 'PHAN_HOI_SAI_CONTRACT')
                if f.header['status'] >= 400:
                    raise k.LoiKenh(f.header['loi']['ma'],
                        retry_after=f.header.get('retry_after'),
                        chi_tiet=f.header['loi'].get('chi_tiet'),
                        thu_lai_duoc=f.header['loi']['thu_lai_duoc'])
            return f

        try:
            control = k._json(dict(header=h, tx_module_mo=bool(self._tx())))
            gui(dieu_khien('chuan_bi', h, control), control)
            cap = nhan()
            k._can(cap.header['kieu'] == 'cap_the', 'PHAN_HOI_SAI_CONTRACT')
            duoc_cap = k._doc_json(cap.than)
            self._kiem.kiem(duoc_cap)
            du_kien = dict(h)
            if parent is None:
                # Trace luồng gốc do Core cấp, không nhận UUID caller làm trace.
                du_kien['request_id'] = duoc_cap['request_id']
            k._can({key: val for key, val in duoc_cap.items() if key != 'the_ky'} == du_kien,
                   'KENH_XAC_THUC_KHONG_HOP_LE')
            h = du_kien
            k._can(not (ghi and self._tx()), 'XUNG_DOT')
            gui(duoc_cap, raw)
            if tep is not None:
                window = _CuaSoChunk(gui, h, tep.descriptor, nhan)
                tep.gui(window.gui, h)
                window.doi_het()
            response = nhan()
            k._can(response.header['kieu'] == 'response', 'PHAN_HOI_SAI_CONTRACT')
            if response.header['stream'] is None:
                return PhanHoiCore(response.header, response.than)
            dem, data = k.BoDemStream(response.header['stream']), bytearray()
            while True:
                f = nhan()
                k._can(f.header.get('stream_id') == response.header['stream']['stream_id'])
                if f.header['kieu'] == 'end':
                    k._can(f.than == b'' and f.header['kich_thuoc_byte'] == dem.tong_byte)
                    dem.ket_thuc()
                    return PhanHoiCore(response.header, bytes(data))
                k._can(f.header['kieu'] == 'chunk')
                dem.nhan_chunk(f.header['stream_id'], f.header['thu_tu_chunk'], f.than)
                data.extend(f.than)
                gui(dieu_khien('ack_chunk', h,
                    stream_id=f.header['stream_id'],
                    thu_tu_chunk=f.header['thu_tu_chunk']), b'')
        except (TimeoutError, OSError):
            raise k.LoiKenh('PHAN_HOI_QUA_HAN') from None
        finally:
            with self._khoa:
                self._cho.pop(h['call_id'], None)
