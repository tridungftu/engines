"""Giao diện launcher và DTO kiểm gói dùng chung giữa Core và engine.

Chỉ chứa hợp đồng và metadata không bí mật; Core giữ implementation,
kiểm tài khoản/ACL và quyền khởi chạy. Không tự tạo tiến trình ở SDK.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from dataclasses import asdict, dataclass
import subprocess


__all__ = ('BoKhoiChayTaiKhoan', 'HoSoTaiKhoan', 'LoiKhoiChayTaiKhoan',
           'KetQuaKiem')

_MA_LOI = frozenset({
    'HO_SO_TAI_KHOAN_KHONG_HOP_LE', 'HO_SO_TAI_KHOAN_KHONG_THAY',
    'TAI_KHOAN_KHONG_TON_TAI', 'TAI_KHOAN_KHONG_DUOC_PHEP',
    'ACL_THU_MUC_KHONG_DUNG', 'KHOI_CHAY_TAI_KHOAN_CHUA_CAU_HINH',
    'KHOI_CHAY_TAI_KHOAN_LOI',
})


class LoiKhoiChayTaiKhoan(RuntimeError):
    def __init__(self, ma='KHOI_CHAY_TAI_KHOAN_LOI'):
        self.ma = ma if ma in _MA_LOI else 'KHOI_CHAY_TAI_KHOAN_LOI'
        super().__init__(self.ma)


@dataclass(frozen=True)
class HoSoTaiKhoan:
    """Metadata không bí mật; đường dẫn tuyệt đối do bộ cài khai trước."""

    ma: str
    tai_khoan: str
    thu_muc_chuong_trinh: str
    thu_muc_lam_viec: str


class BoKhoiChayTaiKhoan(ABC):
    """Hợp đồng fail-closed, không fallback sang danh tính Core hiện tại.

    Mỗi lần khoi_chay phải kiểm lại hồ sơ tồn tại, tài khoản tồn tại/được
    phép và ACL các thư mục đã khai trước khi tạo con. Trả handle tương
    thích Popen (pid, stdin/stdout, poll/wait, handle Windows cho Job).
    Bản thật phải bảo đảm danh tính/phiên và không thừa kế handle ngoài
    kênh bootstrap; không được xem kết quả của bản giả là bằng chứng OS.
    """

    @abstractmethod
    def kiem_tra(self, ma_ho_so: str) -> HoSoTaiKhoan:
        """Kiểm trạng thái hiện tại; lỗi trả LoiKhoiChayTaiKhoan có mã cố định."""

    @abstractmethod
    def khoi_chay(self, ma_ho_so: str, lenh, **tuy_chon) -> subprocess.Popen:
        """Kiểm trước khi chạy; không nhận mật khẩu qua args/env/hồ sơ."""


@dataclass(frozen=True)
class KetQuaKiem:
    ma: str
    ket_luan: str
    muc: str
    ly_do: tuple[str, ...]
    doi_tuong: str = 'chua_xac_dinh'
    phien_ban: str = 'chua_xac_dinh'

    def thanh_dict(self):
        return asdict(self)
