"""SDK engine 2.0: phiếu engine.json, năng lực, vòng nhận việc (lát L2.1).

Người viết engine chỉ cần:

    from kho_tri_thuc_sdk.engine import Engine, LoiNghiepVu, ChuaRo
    app = Engine.tu_khai_bao("engine.json")

    @app.nang_luc("<nhom>.<viec>@1")
    def xu_ly(viec):
        return {"loai": "van_ban", "van_ban": "..."}

    if __name__ == "__main__":
        app.chay()

SDK tự lo: nhận việc, gia hạn giữ việc, dừng khi Core báo hủy, gửi lại lệnh
ghi với cùng Idempotency-Key (tối đa 3 lượt), đổi ngoại lệ thành phong bì lỗi,
kiểm đầu vào theo `nhan`/`gioi_han`/`tham_so` và kết quả theo `tra`/`truong_ra`
(HOP-DONG-CONG.md phần b, c). Đường truyền thật là HTTP (`engine_http.py`),
Core giả trong bộ nhớ ở `thu.py`. Phần engine 2.0 chỉ dùng thư viện chuẩn và
không import phần máy chủ của Core.

Cuối tệp giữ các tên cũ KenhCore, SDKEngine, LoiEngine, GiuViec cho kênh
socket cũ mà Core đang dùng; phần đó không mở rộng.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
import copy
from datetime import date, datetime, timezone
import hashlib
import io
import json
import math
from pathlib import Path
import re
import sys
import threading
import time
import traceback


__all__ = (
    'Engine', 'Viec', 'LoiNghiepVu', 'ChuaRo', 'ViecDaHuy', 'LoiPhieu',
    'LoiDuongTruyen', 'DuongTruyen', 'kiem_phieu', 'doc_phieu',
    'kiem_phong_bi', 'chuan_hoa_tham_so', 'thoa_khoang', 'phien_ban_sdk', 'PHIEN_BAN_SDK_ENGINE',
    'LOAI_GOC', 'KIEU_COT',
    # Tên cũ cho kênh socket của Core.
    'KenhCore', 'SDKEngine', 'LoiEngine', 'GiuViec',
)

# Số phiên bản SDK chung đọc từ `sdk_core/__init__.py` (`__version__`, hợp đồng c.2
# chốt 9). Đọc trễ vì __init__ nạp tệp này trước khi gán __version__.
# `PHIEN_BAN_SDK_ENGINE` (thuộc tính module) = phien_ban_sdk().
LOAI_GOC = ('tep', 'van_ban', 'truong')
KIEU_COT = ('van_ban', 'so', 'so_tien', 'ngay', 'co_khong', 'tep')
KIEU_THAM_SO = ('van_ban', 'so', 'co_khong', 'chon')
SU_KIEN_WEBHOOK = ('viec.co_moi', 'viec.huy', 'engine.dung')
TRANG_THAI_KET_THUC = ('XONG', 'LOI', 'CHUA_RO', 'HUY')
SO_LAN_GUI_LAI = 3
HAN_GIU_MAC_DINH_GIAY = 60
CHO_NHAN_VIEC_GIAY = 30
TEP_TOI_DA_MAC_DINH_MIB = 20
_PHIEU_TOI_DA_BYTE = 1_048_576
_MAT_GIU = frozenset({404, 409, 410})

_MA_ENGINE = re.compile(r'e_[a-z0-9_]{2,29}')
_SEMVER = re.compile(r'(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)\.(0|[1-9][0-9]*)')
_KHOANG = re.compile(r'(\s*(>=|<=|>|<|==)\s*[0-9]+\.[0-9]+\.[0-9]+)+\s*')
_DIEU_KIEN = re.compile(r'(>=|<=|>|<|==)\s*([0-9]+)\.([0-9]+)\.([0-9]+)')
_DUONG_DAN = re.compile(r'[A-Za-z0-9_-][A-Za-z0-9_./-]{0,199}')
_MA_LOAI = re.compile(r'[a-z][a-z0-9_]{1,40}')
_MA_NANG_LUC = re.compile(r'[a-z][a-z0-9_]{1,40}\.[a-z][a-z0-9_]{1,40}@[1-9][0-9]{0,3}')
_MA_TRUONG = re.compile(r'[a-z][a-z0-9_]{0,62}')
_MIME = re.compile(r'[a-z0-9.+-]+/[a-z0-9.+-]+')
_BI_MAT = re.compile(r'[a-z][a-z0-9_]{1,60}')
_URL = re.compile(r'https?://\S+')
_TIEN_TE = re.compile(r'[A-Z]{3}')
_SO_CHUOI = re.compile(r'-?[0-9]+(\.[0-9]+)?')
_NGAY = re.compile(r'[0-9]{4}-[0-9]{2}-[0-9]{2}')
_MA_LOI = re.compile(r'[A-Za-z][A-Za-z0-9_]{1,63}')

_GIAI_THICH = {
    'nhan': 'loại dữ liệu nhận vào', 'tra': 'loại dữ liệu trả ra',
    'gioi_han': 'giới hạn đầu vào', 'diem_vao': 'lệnh Core dùng để chạy engine',
    'nang_luc': 'danh sách năng lực', 'che_do_chay': 'cuc_bo hoặc tu_xa',
    'thoi_han_giay': 'thời gian tối đa của bước', 'kieu': 'kiểu dữ liệu',
}


# ---------------------------------------------------------------------------
# Ngoại lệ

class LoiNghiepVu(Exception):
    """Lỗi engine muốn người dùng thấy. `thong_diep` là câu tiếng Việt dễ hiểu;
    `ma` nằm trong "Chi tiết hỗ trợ"."""

    def __init__(self, ma, thong_diep, *, thu_lai_duoc=False):
        ma = ma.upper() if isinstance(ma, str) and _MA_LOI.fullmatch(ma) else 'LOI_NGHIEP_VU'
        if not isinstance(thong_diep, str) or not thong_diep.strip():
            thong_diep = 'Engine không xử lý được việc này.'
        self.ma = ma
        self.thong_diep = thong_diep.strip()[:500]
        self.thu_lai_duoc = bool(thu_lai_duoc)
        super().__init__(f'{self.ma}: {self.thong_diep}')


class ChuaRo(Exception):
    """Nguồn bên ngoài đã nhận việc nhưng chưa trả lời: Core giữ lượt theo
    `ma_tuong_quan`, không báo thành công giả."""

    def __init__(self, ma_tuong_quan, thong_diep=None):
        if not isinstance(ma_tuong_quan, str) or not 1 <= len(ma_tuong_quan) <= 200:
            raise ValueError('ChuaRo cần mã tương quan là chuỗi 1–200 ký tự.')
        self.ma_tuong_quan = ma_tuong_quan
        self.thong_diep = (thong_diep or
                           'Nguồn bên ngoài đã nhận việc nhưng chưa trả kết quả.')
        super().__init__(self.thong_diep)


class ViecDaHuy(Exception):
    """Core đã hủy việc. SDK ném ra ở `viec.tien_do()`/`viec.kiem_huy()`;
    hàm năng lực không cần bắt, SDK tự báo kết thúc HUY."""


class LoiPhieu(ValueError):
    """Phiếu engine.json sai; `cac_loi` là các câu tiếng Việt."""

    def __init__(self, cac_loi):
        self.cac_loi = list(cac_loi) or ['Phiếu engine.json chưa đúng.']
        super().__init__('Phiếu engine.json chưa đúng:\n- ' + '\n- '.join(self.cac_loi))


class LoiDuongTruyen(RuntimeError):
    """Lỗi trao đổi với Core (HTTP hoặc Core giả)."""

    def __init__(self, ma, thong_diep='Không trao đổi được với Core.', *,
                 http_status=None, thu_lai_duoc=False):
        self.ma = ma if isinstance(ma, str) and _MA_LOI.fullmatch(ma) else 'LOI_DUONG_TRUYEN'
        self.thong_diep = thong_diep if isinstance(thong_diep, str) else ''
        self.http_status = http_status
        self.thu_lai_duoc = bool(thu_lai_duoc)
        super().__init__(f'{self.ma}: {self.thong_diep}')


# ---------------------------------------------------------------------------
# Kiểm phiếu: cùng luật với core/contract/manifest_engine_v2.json, cộng các
# kiểm chéo schema không diễn tả được. Câu lỗi tiếng Việt.

_BAT_BUOC_PHIEU = ('phien_ban_manifest', 'loai', 'ma', 'ten', 'phien_ban',
                   'tuong_thich', 'che_do_chay', 'nang_luc')
_TUY_CHON_PHIEU = ('diem_vao', 'loai_du_lieu_rieng', 'tai_nguyen', 'readiness',
                   'chay_thu_demo', 'bi_mat', 'webhook')


def _la_nguyen(v):
    return isinstance(v, int) and not isinstance(v, bool)


def _la_so(v):
    return (isinstance(v, (int, float)) and not isinstance(v, bool)
            and math.isfinite(v))


def _khop(mau, v):
    return isinstance(v, str) and mau.fullmatch(v) is not None


def _ten_hop_le(v):
    return isinstance(v, str) and 1 <= len(v) <= 120 and bool(v.strip())


def _hien(v):
    try:
        s = json.dumps(v, ensure_ascii=False)
    except (TypeError, ValueError):
        s = type(v).__name__
    return s if len(s) <= 60 else s[:57] + '...'


def _duong_dan_hop_le(v):
    return _khop(_DUONG_DAN, v) and '..' not in v


def _kiem_khoa(d, bat_buoc, tuy_chon, noi, loi):
    for k in bat_buoc:
        if k not in d:
            them = f' ({_GIAI_THICH[k]})' if k in _GIAI_THICH else ''
            loi.append(f'{noi}: thiếu trường bắt buộc "{k}"{them}.')
    for k in d:
        if k not in bat_buoc and k not in tuy_chon:
            loi.append(f'{noi}: có trường lạ {_hien(k)} — mẫu phiếu 2.0 không có trường này.')


def _kiem_nguyen(v, nho, lon, noi, ten, loi):
    if not _la_nguyen(v) or v < nho or (lon is not None and v > lon):
        tam = f'{nho}–{lon}' if lon is not None else f'từ {nho} trở lên'
        loi.append(f'{noi}: "{ten}" phải là số nguyên {tam}.')


def _kiem_ten(d, noi, loi):
    if 'ten' in d and not _ten_hop_le(d['ten']):
        loi.append(f'{noi}: "ten" phải là chữ, 1–120 ký tự.')


def _kiem_loai(x, cho_phep, noi, loi):
    if not _khop(_MA_LOAI, x):
        loi.append(f'{noi}: loại dữ liệu {_hien(x)} không hợp lệ.')
    elif x not in cho_phep:
        loi.append(f'{noi}: loại dữ liệu "{x}" không phải loại gốc (tep, van_ban, truong) '
                   'và chưa khai trong "loai_du_lieu_rieng".')


def _thoa_khoang(phien_ban, khoang):
    """True nếu phien_ban (x.y.z) nằm trong khoảng kiểu ">=2.0.0 <3.0.0"."""
    so = tuple(int(x) for x in phien_ban.split('.'))
    for op, a, b, c in _DIEU_KIEN.findall(khoang):
        moc = (int(a), int(b), int(c))
        if not {'>=': so >= moc, '<=': so <= moc, '>': so > moc,
                '<': so < moc, '==': so == moc}[op]:
            return False
    return True


def phien_ban_sdk():
    """Phiên bản SDK đang chạy (x.y.z), lấy từ __version__ của gói SDK."""
    goi = sys.modules.get(__package__ or '')
    v = getattr(goi, '__version__', None)
    if not isinstance(v, str) or not _SEMVER.fullmatch(v):
        raise RuntimeError('Không đọc được phiên bản SDK.')
    return v


def thoa_khoang(phien_ban, khoang):
    """Phiên bản x.y.z có nằm trong khoảng `tuong_thich` của phiếu không
    (cùng cú pháp schema: các điều kiện >=, <=, >, <, == nối bằng khoảng trắng)."""
    if not _khop(_SEMVER, phien_ban) or not _khop(_KHOANG, khoang):
        raise ValueError('Phiên bản hoặc khoảng phiên bản không hợp lệ.')
    return _thoa_khoang(phien_ban, khoang)


def _kiem_gia_tri_tham_so(khai, v):
    """None nếu giá trị hợp với ô cài đặt; nếu không, lý do (câu tiếng Việt)."""
    kieu = khai.get('kieu')
    nho, lon = khai.get('toi_thieu'), khai.get('toi_da')
    if kieu == 'co_khong':
        return None if isinstance(v, bool) else 'phải là true hoặc false.'
    if kieu == 'so':
        if not _la_so(v):
            return 'phải là số.'
        if _la_so(nho) and v < nho:
            return f'phải từ {nho} trở lên.'
        if _la_so(lon) and v > lon:
            return f'phải không quá {lon}.'
        return None
    if kieu == 'van_ban':
        if not isinstance(v, str):
            return 'phải là chữ.'
        if _la_so(nho) and len(v) < nho:
            return f'phải có ít nhất {nho} ký tự.'
        if _la_so(lon) and len(v) > lon:
            return f'phải có nhiều nhất {lon} ký tự.'
        return None
    if kieu == 'chon':
        ma = [x.get('ma') for x in khai.get('lua_chon', []) if isinstance(x, dict)]
        return None if isinstance(v, str) and v in ma else 'phải là một mã trong "lua_chon".'
    return 'có kiểu không hợp lệ.'


def _kiem_tham_so(ts, noi_nl, i, loi):
    if not isinstance(ts, dict):
        loi.append(f'{noi_nl}, ô cài đặt thứ {i + 1}: phải là một đối tượng {{...}}.')
        return None
    ma = ts.get('ma')
    noi = f'{noi_nl}, ô cài đặt "{ma}"' if isinstance(ma, str) and ma else \
        f'{noi_nl}, ô cài đặt thứ {i + 1}'
    _kiem_khoa(ts, ('ma', 'ten', 'kieu'),
               ('mac_dinh', 'bat_buoc', 'mo_ta', 'toi_thieu', 'toi_da', 'lua_chon'), noi, loi)
    if 'ma' in ts and not _khop(_MA_TRUONG, ma):
        loi.append(f'{noi}: mã ô cài đặt chỉ gồm chữ thường không dấu, số, gạch dưới.')
    _kiem_ten(ts, noi, loi)
    kieu = ts.get('kieu')
    if 'kieu' in ts and kieu not in KIEU_THAM_SO:
        loi.append(f'{noi}: "kieu" {_hien(kieu)} không hợp lệ; chỉ nhận van_ban, so, co_khong, chon.')
    if kieu == 'chon':
        if 'lua_chon' not in ts:
            loi.append(f'{noi}: kiểu "chon" phải có "lua_chon" (danh sách lựa chọn).')
    elif 'lua_chon' in ts:
        loi.append(f'{noi}: chỉ kiểu "chon" mới có "lua_chon".')
    if 'lua_chon' in ts:
        ds = ts['lua_chon']
        if not isinstance(ds, list) or not 1 <= len(ds) <= 100:
            loi.append(f'{noi}: "lua_chon" phải là danh sách 1–100 mục {{"ma", "ten"}}.')
        else:
            da_co = set()
            for j, lc in enumerate(ds):
                noi_lc = f'{noi}, lựa chọn thứ {j + 1}'
                if not isinstance(lc, dict):
                    loi.append(f'{noi_lc}: phải là {{"ma": ..., "ten": ...}}.')
                    continue
                _kiem_khoa(lc, ('ma', 'ten'), (), noi_lc, loi)
                if 'ma' in lc and not _khop(_MA_TRUONG, lc['ma']):
                    loi.append(f'{noi_lc}: mã lựa chọn chỉ gồm chữ thường không dấu, số, gạch dưới.')
                elif lc.get('ma') in da_co:
                    loi.append(f'{noi_lc}: mã "{lc["ma"]}" bị trùng.')
                da_co.add(lc.get('ma') if isinstance(lc.get('ma'), str) else None)
                _kiem_ten(lc, noi_lc, loi)
    if kieu in ('co_khong', 'chon') and ('toi_thieu' in ts or 'toi_da' in ts):
        loi.append(f'{noi}: kiểu "{kieu}" không dùng "toi_thieu"/"toi_da".')
    for k in ('toi_thieu', 'toi_da'):
        if k in ts and not _la_so(ts[k]):
            loi.append(f'{noi}: "{k}" phải là số.')
    if _la_so(ts.get('toi_thieu')) and _la_so(ts.get('toi_da')) and ts['toi_thieu'] > ts['toi_da']:
        loi.append(f'{noi}: "toi_thieu" lớn hơn "toi_da".')
    if 'bat_buoc' in ts and not isinstance(ts['bat_buoc'], bool):
        loi.append(f'{noi}: "bat_buoc" phải là true hoặc false.')
    if 'mo_ta' in ts and not (isinstance(ts['mo_ta'], str) and len(ts['mo_ta']) <= 500):
        loi.append(f'{noi}: "mo_ta" phải là chữ, tối đa 500 ký tự.')
    if 'mac_dinh' in ts and kieu in KIEU_THAM_SO:
        ly_do = _kiem_gia_tri_tham_so(ts, ts['mac_dinh'])
        if ly_do:
            loi.append(f'{noi}: giá trị mặc định {ly_do}')
    return ma if _khop(_MA_TRUONG, ma) else None


def _kiem_gioi_han(g, noi, loi):
    noi = f'{noi}, "gioi_han"'
    if not isinstance(g, dict):
        loi.append(f'{noi}: phải là một đối tượng {{...}}.')
        return
    _kiem_khoa(g, ('thoi_han_giay',), ('tep_toi_da_mib', 'mime', 'ky_tu_toi_da'), noi, loi)
    if 'thoi_han_giay' in g:
        _kiem_nguyen(g['thoi_han_giay'], 1, 86400, noi, 'thoi_han_giay', loi)
    if 'tep_toi_da_mib' in g:
        _kiem_nguyen(g['tep_toi_da_mib'], 1, 2048, noi, 'tep_toi_da_mib', loi)
    if 'ky_tu_toi_da' in g:
        _kiem_nguyen(g['ky_tu_toi_da'], 1, None, noi, 'ky_tu_toi_da', loi)
    if 'mime' in g:
        m = g['mime']
        if (not isinstance(m, list) or len(m) > 50
                or not all(_khop(_MIME, x) for x in m) or len(set(m)) != len(m)):
            loi.append(f'{noi}: "mime" phải là danh sách loại tệp không trùng, ví dụ ["text/plain"].')


def _kiem_truong_ra(ds, noi, loi):
    if not isinstance(ds, list) or not 1 <= len(ds) <= 200:
        loi.append(f'{noi}: "truong_ra" phải là danh sách 1–200 trường {{"ma", "ten", "kieu"}}.')
        return
    da_co = set()
    for j, t in enumerate(ds):
        noi_t = f'{noi}, trường ra thứ {j + 1}'
        if not isinstance(t, dict):
            loi.append(f'{noi_t}: phải là {{"ma", "ten", "kieu"}}.')
            continue
        _kiem_khoa(t, ('ma', 'ten', 'kieu'), (), noi_t, loi)
        if 'ma' in t and not _khop(_MA_TRUONG, t['ma']):
            loi.append(f'{noi_t}: mã trường chỉ gồm chữ thường không dấu, số, gạch dưới.')
        elif t.get('ma') in da_co:
            loi.append(f'{noi_t}: mã "{t["ma"]}" bị trùng.')
        da_co.add(t.get('ma') if isinstance(t.get('ma'), str) else None)
        _kiem_ten(t, noi_t, loi)
        if 'kieu' in t and t['kieu'] not in KIEU_COT:
            loi.append(f'{noi_t}: "kieu" {_hien(t["kieu"])} không hợp lệ; chỉ nhận '
                       + ', '.join(KIEU_COT) + '.')


def _kiem_nang_luc(nl, i, cho_phep_loai, loi):
    if not isinstance(nl, dict):
        loi.append(f'Năng lực thứ {i + 1}: phải là một đối tượng {{...}}.')
        return None
    ma = nl.get('ma')
    noi = f'Năng lực "{ma}"' if isinstance(ma, str) and ma else f'Năng lực thứ {i + 1}'
    _kiem_khoa(nl, ('ma', 'ten', 'nhan', 'tra', 'gioi_han'),
               ('truong_ra', 'huy_duoc', 'tham_so'), noi, loi)
    if 'ma' in nl and not _khop(_MA_NANG_LUC, ma):
        loi.append(f'{noi}: mã năng lực phải có dạng <nhóm>.<việc>@<số>, ví dụ "van_ban.dem_tu@1".')
    _kiem_ten(nl, noi, loi)
    if 'nhan' in nl:
        nhan = nl['nhan']
        if not isinstance(nhan, list) or not 1 <= len(nhan) <= 10:
            loi.append(f'{noi}: "nhan" phải là danh sách 1–10 loại dữ liệu, ví dụ ["van_ban"].')
        else:
            if len({_hien(x) for x in nhan}) != len(nhan):
                loi.append(f'{noi}: "nhan" có loại bị trùng.')
            for x in nhan:
                _kiem_loai(x, cho_phep_loai, f'{noi}, "nhan"', loi)
    if 'tra' in nl:
        _kiem_loai(nl['tra'], cho_phep_loai, f'{noi}, "tra"', loi)
    if nl.get('tra') == 'truong':
        if 'truong_ra' not in nl:
            loi.append(f'{noi}: trả "truong" thì phải khai "truong_ra" (danh sách trường trả ra).')
    elif 'truong_ra' in nl:
        loi.append(f'{noi}: chỉ khai "truong_ra" khi "tra" là "truong".')
    if 'truong_ra' in nl:
        _kiem_truong_ra(nl['truong_ra'], noi, loi)
    if 'gioi_han' in nl:
        _kiem_gioi_han(nl['gioi_han'], noi, loi)
    if 'huy_duoc' in nl and not isinstance(nl['huy_duoc'], bool):
        loi.append(f'{noi}: "huy_duoc" phải là true hoặc false.')
    if 'tham_so' in nl:
        ds = nl['tham_so']
        if not isinstance(ds, list) or len(ds) > 50:
            loi.append(f'{noi}: "tham_so" phải là danh sách tối đa 50 ô cài đặt.')
        else:
            da_co = set()
            for j, ts in enumerate(ds):
                ma_ts = _kiem_tham_so(ts, noi, j, loi)
                if ma_ts in da_co:
                    loi.append(f'{noi}: ô cài đặt "{ma_ts}" bị trùng.')
                da_co.add(ma_ts)
    return ma if _khop(_MA_NANG_LUC, ma) else None


def _kiem_dau_vao_demo(dv, noi, rieng, co_rieng, thu_muc_goi, loi):
    noi = f'{noi}, "dau_vao"'
    if not isinstance(dv, dict) or 'loai' not in dv:
        loi.append(f'{noi}: phải là phong bì {{"loai": ..., ...}}.')
        return None
    loai = dv['loai']
    if not _khop(_MA_LOAI, loai):
        loi.append(f'{noi}: loại dữ liệu {_hien(loai)} không hợp lệ.')
        return None
    if loai in LOAI_GOC:
        khoa = {'van_ban': 'van_ban', 'tep': 'tep_demo', 'truong': 'truong'}[loai]
        _kiem_khoa(dv, ('loai', khoa), (), noi, loi)
        if loai == 'van_ban' and 'van_ban' in dv and not (
                isinstance(dv['van_ban'], str) and len(dv['van_ban']) <= 100000):
            loi.append(f'{noi}: "van_ban" phải là chữ, tối đa 100.000 ký tự.')
        if loai == 'truong' and 'truong' in dv and not isinstance(dv['truong'], dict):
            loi.append(f'{noi}: "truong" phải là đối tượng {{...}}.')
        if loai == 'tep' and 'tep_demo' in dv:
            duong = dv['tep_demo']
            if not _duong_dan_hop_le(duong):
                loi.append(f'{noi}: "tep_demo" phải là đường dẫn trong gói, dùng dấu "/", '
                           'không có "..", ví dụ "demo/mau.txt".')
            elif isinstance(thu_muc_goi, (set, frozenset)):  # bảng kê tệp gói đã đọc
                if duong not in thu_muc_goi:
                    loi.append(f'{noi}: không thấy tệp DEMO "{duong}" trong gói.')
            elif thu_muc_goi is not None:
                goc = Path(thu_muc_goi).resolve()
                tep = (goc / duong).resolve()
                if not tep.is_relative_to(goc) or not tep.is_file():
                    loi.append(f'{noi}: không thấy tệp DEMO "{duong}" trong gói.')
    elif not co_rieng or loai not in rieng:
        loi.append(f'{noi}: loại dữ liệu "{loai}" không phải loại gốc (tep, van_ban, truong) '
                   'và chưa khai trong "loai_du_lieu_rieng".')
    elif loai not in dv:
        loi.append(f'{noi}: phong bì loại riêng phải có khóa "{loai}".')
    return loai


def _kiem_chay_thu(ct, i, cac_nl, rieng, co_rieng, thu_muc_goi, loi):
    noi = f'Chạy thử DEMO thứ {i + 1}'
    if not isinstance(ct, dict):
        loi.append(f'{noi}: phải là một đối tượng {{...}}.')
        return
    _kiem_khoa(ct, ('nang_luc', 'ten', 'dau_vao'), ('tham_so',), noi, loi)
    ma = ct.get('nang_luc')
    nl = None
    if 'nang_luc' in ct:
        if not _khop(_MA_NANG_LUC, ma):
            loi.append(f'{noi}: mã năng lực {_hien(ma)} không hợp lệ.')
        elif ma not in cac_nl:
            loi.append(f'{noi}: năng lực "{ma}" chưa khai trong "nang_luc".')
        else:
            nl = cac_nl[ma]
    _kiem_ten(ct, noi, loi)
    loai = None
    if 'dau_vao' in ct:
        loai = _kiem_dau_vao_demo(ct['dau_vao'], noi, rieng, co_rieng, thu_muc_goi, loi)
    if nl is not None and loai is not None and isinstance(nl.get('nhan'), list) \
            and loai not in nl['nhan']:
        loi.append(f'{noi}: năng lực "{ma}" không nhận loại "{loai}".')
    if 'tham_so' in ct:
        if not isinstance(ct['tham_so'], dict):
            loi.append(f'{noi}: "tham_so" phải là đối tượng {{...}}.')
        elif nl is not None and isinstance(nl.get('tham_so', []), list):
            khai = [t for t in nl.get('tham_so', []) if isinstance(t, dict)]
            _, loi_ts = chuan_hoa_tham_so(khai, ct['tham_so'])
            loi.extend(f'{noi}: {x}' for x in loi_ts)


def kiem_phieu(phieu, thu_muc_goi=None, *, cac_tep=None):
    """Trả danh sách lỗi (câu tiếng Việt) của phiếu engine.json; rỗng là đúng.

    thu_muc_goi: nếu có, kiểm thêm tệp `tep_demo` có thật trong gói.
    cac_tep: bảng kê đường dẫn POSIX các tệp gói đã đọc (Core dùng thay cho
    thư mục để không đọc đĩa lần hai).
    """
    if cac_tep is not None:
        thu_muc_goi = frozenset(cac_tep)
    loi = []
    if not isinstance(phieu, dict):
        return ['Phiếu phải là một đối tượng JSON dạng {...}.']
    _kiem_khoa(phieu, _BAT_BUOC_PHIEU, _TUY_CHON_PHIEU, 'Phiếu', loi)
    if 'phien_ban_manifest' in phieu and not (
            _la_nguyen(phieu['phien_ban_manifest']) and phieu['phien_ban_manifest'] == 2):
        loi.append('Phiếu: "phien_ban_manifest" phải là 2.')
    if 'loai' in phieu and phieu['loai'] != 'engine':
        loi.append('Phiếu: "loai" phải là "engine".')
    if 'ma' in phieu and not _khop(_MA_ENGINE, phieu['ma']):
        loi.append('Phiếu: mã engine phải bắt đầu bằng "e_", chỉ gồm chữ thường không dấu, '
                   'số, gạch dưới, dài 4–31 ký tự.')
    _kiem_ten(phieu, 'Phiếu', loi)
    if 'phien_ban' in phieu and not _khop(_SEMVER, phieu['phien_ban']):
        loi.append('Phiếu: "phien_ban" phải có dạng số.số.số, ví dụ "1.0.0".')
    if 'tuong_thich' in phieu:
        tt, noi = phieu['tuong_thich'], 'Phiếu, "tuong_thich"'
        if not isinstance(tt, dict):
            loi.append(f'{noi}: phải là đối tượng {{"core", "api", "sdk"}}.')
        else:
            _kiem_khoa(tt, ('core', 'api'), ('sdk',), noi, loi)
            for k in ('core', 'sdk'):
                if k in tt and not (_khop(_KHOANG, tt[k]) and len(tt[k]) <= 60):
                    loi.append(f'{noi}: "{k}" phải là khoảng phiên bản, ví dụ ">=2.0.0 <3.0.0".')
            if 'api' in tt and tt['api'] != 'v1':
                loi.append(f'{noi}: "api" phải là "v1".')
    che_do = phieu.get('che_do_chay')
    if 'che_do_chay' in phieu and che_do not in ('cuc_bo', 'tu_xa'):
        loi.append('Phiếu: "che_do_chay" chỉ nhận "cuc_bo" hoặc "tu_xa".')
    if che_do == 'cuc_bo' and 'diem_vao' not in phieu:
        loi.append('Phiếu: engine chạy "cuc_bo" phải khai "diem_vao" (lệnh Core dùng để chạy engine).')
    if 'diem_vao' in phieu:
        dv, noi = phieu['diem_vao'], 'Phiếu, "diem_vao"'
        if not isinstance(dv, dict):
            loi.append(f'{noi}: phải là đối tượng {{"lenh": [...], "thu_muc": "."}}.')
        else:
            _kiem_khoa(dv, ('lenh',), ('thu_muc',), noi, loi)
            lenh = dv.get('lenh')
            if 'lenh' in dv and not (isinstance(lenh, list) and 1 <= len(lenh) <= 32 and all(
                    isinstance(x, str) and 1 <= len(x) <= 500 for x in lenh)):
                loi.append(f'{noi}: "lenh" phải là danh sách 1–32 chuỗi, ví dụ '
                           '["{python}", "-m", "<goi>.chay"].')
            if 'thu_muc' in dv and dv['thu_muc'] != '.' and not _duong_dan_hop_le(dv['thu_muc']):
                loi.append(f'{noi}: "thu_muc" phải là "." hoặc đường dẫn trong gói.')
    rieng, co_rieng = set(), False
    if 'loai_du_lieu_rieng' in phieu:
        ds, noi = phieu['loai_du_lieu_rieng'], 'Phiếu, "loai_du_lieu_rieng"'
        if not isinstance(ds, list) or len(ds) > 50:
            loi.append(f'{noi}: phải là danh sách tối đa 50 mục {{"ma", "ten"}}.')
        else:
            co_rieng = len(ds) > 0
            for j, lr in enumerate(ds):
                noi_lr = f'{noi}, mục thứ {j + 1}'
                if not isinstance(lr, dict):
                    loi.append(f'{noi_lr}: phải là {{"ma", "ten"}}.')
                    continue
                _kiem_khoa(lr, ('ma', 'ten'), (), noi_lr, loi)
                _kiem_ten(lr, noi_lr, loi)
                ma = lr.get('ma')
                if 'ma' not in lr:
                    continue
                if not _khop(_MA_LOAI, ma) or ma in LOAI_GOC:
                    loi.append(f'{noi_lr}: mã loại riêng phải là chữ thường không dấu và '
                               'khác 3 loại gốc tep, van_ban, truong.')
                elif ma in rieng:
                    loi.append(f'{noi_lr}: mã "{ma}" bị trùng.')
                else:
                    rieng.add(ma)
    cho_phep_loai = set(LOAI_GOC) | rieng
    cac_nl = {}
    if 'nang_luc' in phieu:
        ds = phieu['nang_luc']
        if not isinstance(ds, list) or not 1 <= len(ds) <= 50:
            loi.append('Phiếu: "nang_luc" phải là danh sách 1–50 năng lực.')
        else:
            for i, nl in enumerate(ds):
                ma = _kiem_nang_luc(nl, i, cho_phep_loai, loi)
                if ma is None:
                    continue
                if ma in cac_nl:
                    loi.append(f'Năng lực "{ma}": mã bị trùng.')
                cac_nl[ma] = nl
    if 'tai_nguyen' in phieu:
        tn, noi = phieu['tai_nguyen'], 'Phiếu, "tai_nguyen"'
        if not isinstance(tn, dict):
            loi.append(f'{noi}: phải là đối tượng {{"so_viec_dong_thoi": 1}}.')
        else:
            _kiem_khoa(tn, ('so_viec_dong_thoi',), (), noi, loi)
            if 'so_viec_dong_thoi' in tn:
                _kiem_nguyen(tn['so_viec_dong_thoi'], 1, 64, noi, 'so_viec_dong_thoi', loi)
    if 'readiness' in phieu:
        rd, noi = phieu['readiness'], 'Phiếu, "readiness"'
        if not isinstance(rd, dict):
            loi.append(f'{noi}: phải là đối tượng {{"thoi_han_giay": 30}}.')
        else:
            _kiem_khoa(rd, ('thoi_han_giay',), (), noi, loi)
            if 'thoi_han_giay' in rd:
                _kiem_nguyen(rd['thoi_han_giay'], 1, 120, noi, 'thoi_han_giay', loi)
    if 'bi_mat' in phieu:
        bm = phieu['bi_mat']
        if (not isinstance(bm, list) or len(bm) > 20 or len({_hien(x) for x in bm}) != len(bm)
                or not all(_khop(_BI_MAT, x) for x in bm)):
            loi.append('Phiếu: "bi_mat" chỉ ghi tên bí mật (chữ thường không dấu), không trùng, '
                       'tối đa 20 tên; không bao giờ ghi giá trị.')
    if 'webhook' in phieu and phieu['webhook'] is not None:
        wh, noi = phieu['webhook'], 'Phiếu, "webhook"'
        if not isinstance(wh, dict):
            loi.append(f'{noi}: phải là null hoặc {{"url": ..., "su_kien": [...]}}.')
        else:
            _kiem_khoa(wh, ('url', 'su_kien'), (), noi, loi)
            if 'url' in wh and not (_khop(_URL, wh['url']) and len(wh['url']) <= 500):
                loi.append(f'{noi}: "url" phải bắt đầu bằng http:// hoặc https://.')
            sk = wh.get('su_kien')
            if 'su_kien' in wh and not (isinstance(sk, list) and sk
                                        and len({_hien(x) for x in sk}) == len(sk)
                                        and all(x in SU_KIEN_WEBHOOK for x in sk)):
                loi.append(f'{noi}: "su_kien" chỉ nhận ' + ', '.join(SU_KIEN_WEBHOOK) + '.')
    if 'chay_thu_demo' in phieu:
        ds = phieu['chay_thu_demo']
        if not isinstance(ds, list) or len(ds) > 50:
            loi.append('Phiếu: "chay_thu_demo" phải là danh sách tối đa 50 ví dụ.')
        else:
            for i, ct in enumerate(ds):
                _kiem_chay_thu(ct, i, cac_nl, rieng, co_rieng, thu_muc_goi, loi)
    return loi


def doc_phieu(duong_dan, *, kiem_sdk=True):
    """Đọc và kiểm engine.json; sai thì ném LoiPhieu với câu tiếng Việt."""
    tep = Path(duong_dan)
    try:
        raw = tep.read_bytes()
    except OSError:
        raise LoiPhieu([f'Không đọc được tệp phiếu "{tep.name}".']) from None
    if len(raw) > _PHIEU_TOI_DA_BYTE:
        raise LoiPhieu(['Tệp phiếu lớn quá 1 MiB.'])
    try:
        phieu = json.loads(raw.decode('utf-8-sig'))
    except UnicodeDecodeError:
        raise LoiPhieu(['Tệp phiếu phải lưu dạng UTF-8.']) from None
    except json.JSONDecodeError as exc:
        raise LoiPhieu([f'Tệp phiếu không phải JSON hợp lệ (dòng {exc.lineno}, cột {exc.colno}).']) from None
    loi = kiem_phieu(phieu, tep.parent)
    if not loi and kiem_sdk:
        khoang = phieu['tuong_thich'].get('sdk')
        if khoang and not _thoa_khoang(phien_ban_sdk(), khoang):
            loi.append(f'Phiếu đòi SDK "{khoang}", SDK đang có bản {phien_ban_sdk()}.')
    if loi:
        raise LoiPhieu(loi)
    return phieu


# ---------------------------------------------------------------------------
# Phong bì dữ liệu giữa các bước (b.3) và Cài đặt bước

def _kiem_gia_tri_truong(kieu, v):
    if v is None:
        return None
    if kieu == 'van_ban':
        return None if isinstance(v, str) else 'phải là chữ'
    if kieu == 'so':
        return None if _la_so(v) else 'phải là số'
    if kieu == 'co_khong':
        return None if isinstance(v, bool) else 'phải là true/false'
    if kieu == 'ngay':
        if _khop(_NGAY, v):
            try:
                date.fromisoformat(v)
                return None
            except ValueError:
                pass
        return 'phải là ngày dạng "YYYY-MM-DD"'
    if kieu == 'so_tien':
        if (isinstance(v, dict) and set(v) == {'so', 'tien_te'} and _khop(_TIEN_TE, v['tien_te'])
                and (_la_so(v['so']) or _khop(_SO_CHUOI, v['so']))):
            return None
        return 'phải là {"so": ..., "tien_te": "VND"}'
    if kieu == 'tep':
        return None if not _kiem_tep(v) else 'phải là đối tượng tệp {"tep_id", ...}'
    return 'có kiểu không hợp lệ'


def _kiem_tep(t, *, day_du=False):
    if not isinstance(t, dict):
        return ['tệp phải là đối tượng {"tep_id", "ten", "mime", "kich_thuoc"}']
    loi = []
    if not (isinstance(t.get('tep_id'), str) and 1 <= len(t['tep_id']) <= 200):
        loi.append('thiếu "tep_id"')
    for k, dung in (('ten', lambda x: isinstance(x, str) and 1 <= len(x) <= 255),
                    ('mime', lambda x: _khop(_MIME, x)),
                    ('kich_thuoc', lambda x: _la_nguyen(x) and x >= 0)):
        if k in t:
            if not dung(t[k]):
                loi.append(f'"{k}" của tệp không hợp lệ')
        elif day_du:
            loi.append(f'tệp thiếu "{k}"')
    return loi


def kiem_phong_bi(pb, cho_phep=None, truong_ra=None, *, chat=False):
    """Lỗi (danh sách câu) của một phong bì; rỗng là đúng.

    cho_phep: các loại được nhận. truong_ra: khai báo trường khi loại `truong`.
    chat=True (kiểm kết quả engine): không nhận khóa thừa, tệp phải đủ 4 khóa.
    """
    if not isinstance(pb, dict) or not isinstance(pb.get('loai'), str):
        return ['phải là phong bì {"loai": ..., ...}']
    loai = pb['loai']
    if cho_phep is not None and loai not in cho_phep:
        return [f'loại "{loai}" khác loại được nhận ({", ".join(cho_phep)})']
    khoa = loai if loai in LOAI_GOC or _khop(_MA_LOAI, loai) else None
    if khoa is None:
        return [f'loại {_hien(loai)} không hợp lệ']
    if khoa not in pb:
        return [f'phong bì loại "{loai}" thiếu khóa "{khoa}"']
    loi = []
    if chat and set(pb) != {'loai', khoa}:
        loi.append('phong bì có khóa thừa: ' + ', '.join(sorted(set(pb) - {'loai', khoa})))
    gt = pb[khoa]
    if loai == 'van_ban' and not isinstance(gt, str):
        loi.append('"van_ban" phải là chữ')
    elif loai == 'tep':
        loi.extend(_kiem_tep(gt, day_du=chat))
    elif loai == 'truong':
        if not isinstance(gt, dict):
            loi.append('"truong" phải là đối tượng {...}')
        elif truong_ra is not None:
            khai = {t['ma']: t['kieu'] for t in truong_ra}
            thieu = [k for k in khai if k not in gt]
            thua = [k for k in gt if k not in khai]
            if thieu:
                loi.append('thiếu trường ' + ', '.join(thieu))
            if thua:
                loi.append('có trường chưa khai ' + ', '.join(map(str, thua)))
            for k, kieu in khai.items():
                if k in gt:
                    ly_do = _kiem_gia_tri_truong(kieu, gt[k])
                    if ly_do:
                        loi.append(f'trường "{k}" {ly_do}')
    return loi


def chuan_hoa_tham_so(khai_bao, gia_tri):
    """Điền giá trị mặc định và kiểm Cài đặt bước; trả (giá trị, danh sách lỗi)."""
    if gia_tri is None:
        gia_tri = {}
    if not isinstance(gia_tri, dict):
        return {}, ['Cài đặt bước phải là đối tượng {...}.']
    theo_ma = {t['ma']: t for t in khai_bao if isinstance(t, dict) and isinstance(t.get('ma'), str)}
    loi = [f'ô cài đặt {_hien(k)} không có trong phiếu.' for k in gia_tri if k not in theo_ma]
    kq = {}
    for ma, t in theo_ma.items():
        ten = t.get('ten', ma)
        if gia_tri.get(ma) is not None:
            v = gia_tri[ma]
        elif 'mac_dinh' in t:
            v = t['mac_dinh']
        else:
            if t.get('bat_buoc'):
                loi.append(f'ô cài đặt "{ten}" bắt buộc nhưng chưa có giá trị.')
            kq[ma] = None
            continue
        ly_do = _kiem_gia_tri_tham_so(t, v)
        if ly_do:
            loi.append(f'ô cài đặt "{ten}" {ly_do}')
        kq[ma] = copy.deepcopy(v)
    return kq, loi


def _kiem_gioi_han_vao(khai, pb):
    """Ném LoiNghiepVu nếu đầu vào vượt `gioi_han` (không cắt bớt ngầm)."""
    g = khai.get('gioi_han', {})
    if pb['loai'] == 'van_ban' and 'ky_tu_toi_da' in g and len(pb['van_ban']) > g['ky_tu_toi_da']:
        so = f'{g["ky_tu_toi_da"]:,}'.replace(',', '.')
        raise LoiNghiepVu('VUOT_GIOI_HAN', f'Văn bản dài hơn {so} ký tự, bước này không nhận.')
    if pb['loai'] == 'tep':
        tep = pb['tep']
        mib = g.get('tep_toi_da_mib')
        if mib and _la_nguyen(tep.get('kich_thuoc')) and tep['kich_thuoc'] > mib * 1048576:
            raise LoiNghiepVu('VUOT_GIOI_HAN', f'Tệp lớn hơn {mib} MiB, bước này không nhận.')
        mime = g.get('mime') or []
        if mime and tep.get('mime') not in mime:
            raise LoiNghiepVu('LOAI_TEP_KHONG_NHAN',
                              'Loại tệp này không được bước này nhận (chỉ nhận: '
                              + ', '.join(mime) + ').')


# ---------------------------------------------------------------------------
# Đường truyền: một bộ thao tác như hợp đồng (c) c.2; HTTP và Core giả cài đặt.

class DuongTruyen(ABC):
    """Thao tác engine gọi Core. Lỗi ném LoiDuongTruyen; lệnh ghi nhận `khoa`
    (Idempotency-Key), cùng khóa thì Core trả kết quả lần đầu, không ghi trùng."""

    @abstractmethod
    def san_sang(self, phien_ban, nang_luc):
        """#1 POST /api/v1/engine/{ma}/san-sang → cấu hình (dict)."""

    @abstractmethod
    def nhan_viec(self, cho_toi_da_giay):
        """#2 POST /api/v1/engine/{ma}/viec/nhan → dict việc hoặc None (204)."""

    @abstractmethod
    def doc_dau_vao(self, viec_id):
        """#3 GET /api/v1/engine/viec/{id}/dau-vao → phong bì."""

    @abstractmethod
    def mo_tep(self, viec_id, tep_id, toi_da_byte):
        """#4 GET /api/v1/engine/viec/{id}/tep/{tep_id} → bytes."""

    @abstractmethod
    def tai_tep_ra(self, viec_id, ten, du_lieu, mime, khoa):
        """#5 POST /api/v1/engine/viec/{id}/tep → {"tep_id": ...}."""

    @abstractmethod
    def gia_han(self, viec_id, han_giu_giay):
        """#6 POST /api/v1/engine/viec/{id}/gia-han → {"han_giu", "huy"}."""

    @abstractmethod
    def tien_do(self, viec_id, phan_tram, cau):
        """#7 POST /api/v1/engine/viec/{id}/tien-do."""

    @abstractmethod
    def nop_ket_qua(self, viec_id, phong_bi, khoa):
        """#8 PUT /api/v1/engine/viec/{id}/ket-qua → {"da_luu": true}."""

    @abstractmethod
    def ket_thuc(self, viec_id, than, khoa):
        """#9 POST /api/v1/engine/viec/{id}/ket-thuc."""


class _CauHinhChay:
    __slots__ = ('han_giu_giay', 'khoang_gia_han', 'cho_gui_lai')

    def __init__(self, han_giu_giay, khoang_gia_han, cho_gui_lai):
        self.han_giu_giay = han_giu_giay
        self.khoang_gia_han = khoang_gia_han
        self.cho_gui_lai = cho_gui_lai


class _BoKhoa:
    """Idempotency-Key ổn định cho mỗi lệnh ghi của một lần thử việc."""

    def __init__(self, ma_engine, viec_id, lan_thu):
        self._goc = f'{ma_engine}|{viec_id}|{lan_thu}'
        self._dem = {}
        self._lock = threading.Lock()

    def cho(self, thao_tac):
        with self._lock:
            so = self._dem[thao_tac] = self._dem.get(thao_tac, 0) + 1
        return hashlib.sha256(f'{self._goc}|{thao_tac}|{so}'.encode()).hexdigest()[:40]


def _goi_lai(cfg, ham, *args, **kw):
    """Gọi lệnh; lỗi tạm thời thì gửi lại tối đa SO_LAN_GUI_LAI lượt, cùng tham số
    (cùng Idempotency-Key)."""
    lan = 0
    while True:
        try:
            return ham(*args, **kw)
        except LoiDuongTruyen as exc:
            if not exc.thu_lai_duoc or lan >= SO_LAN_GUI_LAI:
                raise
            lan += 1
            if cfg.cho_gui_lai:
                time.sleep(cfg.cho_gui_lai * lan)


class Viec:
    """Một việc engine đang làm; hàm năng lực nhận đối tượng này."""

    def __init__(self, du_lieu, duong_truyen, cfg, bo_khoa):
        self.id = str(du_lieu['id'])
        self.nang_luc = du_lieu['nang_luc']
        self.lan_thu = du_lieu.get('lan_thu', 1)
        self.han_giu = du_lieu.get('han_giu')
        ngu_canh = du_lieu.get('ngu_canh')
        self.ngu_canh = dict(ngu_canh) if isinstance(ngu_canh, dict) else {}
        self.dau_vao = None
        self.tham_so = {}
        self._dt, self._cfg, self._khoa = duong_truyen, cfg, bo_khoa
        self._gioi_han = {}
        self._huy = threading.Event()
        self._mat_giu = threading.Event()

    def __repr__(self):
        return f'Viec(id={self.id!r}, nang_luc={self.nang_luc!r})'

    @property
    def da_huy(self):
        """True khi Core đã báo hủy (hoặc engine đã mất quyền giữ việc)."""
        return self._huy.is_set()

    def kiem_huy(self):
        """Ném ViecDaHuy nếu việc đã bị hủy; engine chạy lâu nên gọi thường xuyên."""
        if self._huy.is_set():
            raise ViecDaHuy()

    def _bao_mat_giu(self, exc):
        if exc.http_status in _MAT_GIU:
            self._mat_giu.set()
            self._huy.set()

    def tien_do(self, phan_tram, cau=''):
        """Báo tiến độ (0–100) và một câu ngắn cho người dùng. Việc đã bị hủy
        thì lệnh này dừng hàm năng lực (ném ViecDaHuy)."""
        self.kiem_huy()
        if not _la_so(phan_tram) or not 0 <= phan_tram <= 100:
            raise ValueError('Tiến độ phải là số từ 0 đến 100.')
        if not isinstance(cau, str):
            raise ValueError('Câu tiến độ phải là chữ.')
        try:
            tl = self._dt.tien_do(self.id, int(phan_tram), cau.strip()[:200])
        except LoiDuongTruyen as exc:  # tiến độ không bắt buộc tới nơi
            self._bao_mat_giu(exc)
        else:
            if isinstance(tl, dict) and tl.get('huy') is True:  # hợp đồng c.2 chốt 6
                self._huy.set()
        self.kiem_huy()

    def mo_tep(self, tep_id):
        """Mở tệp đầu vào để đọc byte: `with viec.mo_tep(tep_id) as f: f.read()`."""
        self.kiem_huy()
        if not isinstance(tep_id, str) or not tep_id:
            raise ValueError('Cần tep_id là chuỗi.')
        toi_da = self._gioi_han.get('tep_toi_da_mib', TEP_TOI_DA_MAC_DINH_MIB) * 1048576
        du_lieu = _goi_lai(self._cfg, self._dt.mo_tep, self.id, tep_id, toi_da)
        if not isinstance(du_lieu, (bytes, bytearray)):
            raise LoiDuongTruyen('PHAN_HOI_SAI_CONTRACT', 'Core trả tệp không đọc được.')
        if len(du_lieu) > toi_da:
            raise LoiNghiepVu('VUOT_GIOI_HAN', 'Tệp lớn hơn giới hạn bước này nhận.')
        return io.BytesIO(bytes(du_lieu))

    def tai_tep_ra(self, ten, du_lieu, mime='application/octet-stream'):
        """Gửi tệp kết quả lên Core; trả đối tượng tệp để đặt vào
        `{"loai": "tep", "tep": ...}`."""
        self.kiem_huy()
        if (not isinstance(ten, str) or not 1 <= len(ten) <= 255
                or any(c in ten for c in '/\\\0')):
            raise ValueError('Tên tệp ra phải là chữ 1–255 ký tự, không chứa đường dẫn.')
        if not isinstance(du_lieu, (bytes, bytearray)):
            raise ValueError('Dữ liệu tệp ra phải là bytes.')
        if not _khop(_MIME, mime):
            raise ValueError('mime không hợp lệ, ví dụ "text/plain".')
        du_lieu = bytes(du_lieu)
        kq = _goi_lai(self._cfg, self._dt.tai_tep_ra, self.id, ten, du_lieu, mime,
                      khoa=self._khoa.cho('tep'))
        tep_id = kq.get('tep_id') if isinstance(kq, dict) else None
        if not isinstance(tep_id, str) or not tep_id:
            raise LoiDuongTruyen('PHAN_HOI_SAI_CONTRACT', 'Core không trả mã tệp.')
        return {'tep_id': tep_id, 'ten': ten, 'mime': mime, 'kich_thuoc': len(du_lieu)}


class _GiaHan(threading.Thread):
    """Gia hạn giữ việc định kỳ; cờ `huy` của Core thì đặt viec.da_huy."""

    def __init__(self, duong_truyen, viec, cfg):
        super().__init__(daemon=True, name=f'gia-han-{viec.id}')
        self._dt, self._viec, self._cfg = duong_truyen, viec, cfg
        self._dung = threading.Event()

    def run(self):
        while not self._dung.wait(self._cfg.khoang_gia_han):
            try:
                tl = self._dt.gia_han(self._viec.id, self._cfg.han_giu_giay)
            except LoiDuongTruyen as exc:
                self._viec._bao_mat_giu(exc)
                if self._viec._mat_giu.is_set():
                    return
                continue
            except Exception:  # lần sau thử lại; không làm chết việc vì lỗi gia hạn
                continue
            if isinstance(tl, dict) and tl.get('huy') is True:
                self._viec._huy.set()

    def dung(self):
        self._dung.set()
        if self.is_alive():
            self.join(timeout=5)


class Engine:
    """Một engine: phiếu đã kiểm + hàm xử lý từng năng lực."""

    def __init__(self, phieu, *, thu_muc_goi=None):
        loi = kiem_phieu(phieu, thu_muc_goi)
        if loi:
            raise LoiPhieu(loi)
        self.phieu = copy.deepcopy(phieu)
        self.ma = phieu['ma']
        self.ten = phieu['ten']
        self.phien_ban = phieu['phien_ban']
        self.thu_muc_goi = Path(thu_muc_goi) if thu_muc_goi is not None else None
        self._nang_luc = {nl['ma']: nl for nl in self.phieu['nang_luc']}
        self._ham = {}
        self._dung = threading.Event()

    def __repr__(self):
        return f'Engine(ma={self.ma!r}, phien_ban={self.phien_ban!r})'

    @classmethod
    def tu_khai_bao(cls, duong_dan='engine.json'):
        """Đọc và kiểm phiếu. Đường dẫn tương đối tìm cạnh tệp mã gọi (và thư mục
        cha của nó), rồi tới thư mục đang chạy."""
        p = Path(duong_dan)
        cac_cho = [p] if p.is_absolute() else []
        if not p.is_absolute():
            tep_goi = sys._getframe(1).f_globals.get('__file__')
            if tep_goi:
                thu_muc = Path(tep_goi).resolve().parent
                cac_cho += [thu_muc / p, thu_muc.parent / p]
            cac_cho.append(Path.cwd() / p)
        for cho in cac_cho:
            if cho.is_file():
                return cls(doc_phieu(cho), thu_muc_goi=cho.parent)
        raise LoiPhieu([f'Không thấy tệp phiếu "{duong_dan}" cạnh mã engine '
                        'hoặc trong thư mục đang chạy.'])

    @property
    def cac_nang_luc(self):
        return tuple(self._nang_luc)

    def nang_luc(self, ma):
        """Gắn hàm xử lý cho một năng lực đã khai: `@app.nang_luc("x.y@1")`."""
        if ma not in self._nang_luc:
            raise LoiPhieu([f'Năng lực "{ma}" chưa khai trong engine.json.'])
        if ma in self._ham:
            raise LoiPhieu([f'Năng lực "{ma}" đã có hàm xử lý.'])

        def gan(ham):
            if not callable(ham):
                raise TypeError('Cần một hàm nhận đối tượng việc.')
            self._ham[ma] = ham
            return ham
        return gan

    def dung(self):
        """Dừng vòng nhận việc sau việc đang làm (drain)."""
        self._dung.set()

    def _ghi(self, cau):
        try:
            print(f'[engine {self.ma}] {cau}', file=sys.stderr, flush=True)
        except Exception:
            pass

    def chay(self, duong_truyen=None, *, dung_khi_het_viec=False, khoang_gia_han=None,
             han_giu_giay=HAN_GIU_MAC_DINH_GIAY, cho_gui_lai_giay=0.5):
        """Vòng nhận và làm việc. Không truyền đường truyền thì dùng HTTP, đọc
        địa chỉ Core và khóa engine từ dòng khởi động trên stdin (hoặc biến môi
        trường khi chạy tay) — xem engine_http.doc_khoi_dong."""
        thieu = [m for m in self._nang_luc if m not in self._ham]
        if thieu:
            raise LoiPhieu([f'Năng lực "{m}" đã khai trong phiếu nhưng chưa có hàm xử lý '
                            f'(@app.nang_luc("{m}")).' for m in thieu])
        if duong_truyen is None:
            from .engine_http import DuongHttp
            duong_truyen = DuongHttp.tu_khoi_dong(self.ma)
        if not isinstance(duong_truyen, DuongTruyen):
            raise TypeError('Cần một DuongTruyen (HTTP hoặc Core giả).')
        if not _la_so(han_giu_giay) or not 1 <= han_giu_giay <= 3600:
            raise ValueError('han_giu_giay phải từ 1 đến 3600.')
        cfg = _CauHinhChay(han_giu_giay, khoang_gia_han or han_giu_giay / 3, cho_gui_lai_giay)
        self._dung.clear()
        _goi_lai(cfg, duong_truyen.san_sang, phien_ban=self.phien_ban,
                 nang_luc=list(self._nang_luc))
        so_luong = self.phieu.get('tai_nguyen', {}).get('so_viec_dong_thoi', 1)
        try:
            if so_luong <= 1 or dung_khi_het_viec:
                self._vong(duong_truyen, cfg, dung_khi_het_viec)
                return
            loi_luong = []

            def chay_luong():
                try:
                    self._vong(duong_truyen, cfg, False)
                except BaseException as exc:  # một luồng hỏng thì dừng cả engine
                    loi_luong.append(exc)
                    self._dung.set()
            luong = [threading.Thread(target=chay_luong, daemon=True,
                                      name=f'engine-{self.ma}-{i}') for i in range(so_luong)]
            for t in luong:
                t.start()
            while any(t.is_alive() for t in luong):
                for t in luong:
                    t.join(0.5)
            if loi_luong:
                raise loi_luong[0]
        except KeyboardInterrupt:
            self._dung.set()

    def _vong(self, dt, cfg, dung_khi_het_viec):
        so_lan_loi = 0
        while not self._dung.is_set():
            bat_dau = time.monotonic()
            try:
                du_lieu = dt.nhan_viec(0 if dung_khi_het_viec else CHO_NHAN_VIEC_GIAY)
                so_lan_loi = 0
            except LoiDuongTruyen as exc:
                if not exc.thu_lai_duoc:
                    raise
                so_lan_loi = min(so_lan_loi + 1, 5)
                self._dung.wait(max(cfg.cho_gui_lai, 0.01) * 2 * so_lan_loi)
                continue
            if du_lieu is None:
                if dung_khi_het_viec:
                    return
                if time.monotonic() - bat_dau < 1:  # Core không giữ chờ: tránh hỏi dồn
                    self._dung.wait(1)
                continue
            self.xu_ly_viec(dt, du_lieu, cfg)

    def xu_ly_viec(self, dt, du_lieu, cfg):
        """Làm một việc Core giao; trả trạng thái đã báo Core (hoặc lý do không báo)."""
        if not (isinstance(du_lieu, dict) and du_lieu.get('id') is not None
                and isinstance(du_lieu.get('nang_luc'), str)):
            self._ghi('Core giao việc thiếu mã việc hoặc năng lực; bỏ qua.')
            return None
        viec = Viec(du_lieu, dt, cfg, _BoKhoa(self.ma, du_lieu['id'], du_lieu.get('lan_thu', 1)))
        gia_han = _GiaHan(dt, viec, cfg)
        try:
            gia_han.start()
            kq = self._lam(dt, viec, du_lieu, cfg)
            if isinstance(kq, str):
                return kq
            try:
                _goi_lai(cfg, dt.nop_ket_qua, viec.id, kq, khoa=viec._khoa.cho('ket_qua'))
            except LoiDuongTruyen as exc:
                self._ghi(f'Không nộp được kết quả việc {viec.id} ({exc.ma}); Core sẽ giao lại.')
                return 'CHUA_NOP'
            return self._ket_thuc(dt, viec, cfg, 'XONG')
        finally:
            gia_han.dung()

    def _lam(self, dt, viec, du_lieu, cfg):
        """Chạy hàm năng lực; trả phong bì kết quả đã kiểm, hoặc chuỗi trạng thái
        đã kết thúc (LOI/CHUA_RO/HUY/MAT_GIU)."""
        try:
            khai = self._nang_luc.get(viec.nang_luc)
            ham = self._ham.get(viec.nang_luc)
            if khai is None or ham is None:
                raise LoiNghiepVu('NANG_LUC_KHONG_CO', 'Engine không có năng lực được giao cho bước này.')
            dau_vao = du_lieu.get('dau_vao')
            if dau_vao is None:
                dau_vao = _goi_lai(cfg, dt.doc_dau_vao, viec.id)
            if kiem_phong_bi(dau_vao, khai['nhan']):
                raise LoiNghiepVu('DAU_VAO_KHONG_HOP_LE', 'Dữ liệu vào không đúng loại bước này nhận.')
            _kiem_gioi_han_vao(khai, dau_vao)
            tham_so, loi = chuan_hoa_tham_so(khai.get('tham_so', []), du_lieu.get('tham_so'))
            if loi:
                raise LoiNghiepVu('CAI_DAT_BUOC_KHONG_HOP_LE', 'Cài đặt bước không hợp lệ: ' + loi[0])
            viec.dau_vao = copy.deepcopy(dau_vao)
            viec.tham_so = tham_so
            viec._gioi_han = dict(khai.get('gioi_han', {}))
            viec.kiem_huy()
            kq = ham(viec)
            viec.kiem_huy()
            loi = kiem_phong_bi(kq, [khai['tra']], khai.get('truong_ra'), chat=True)
            if loi:
                self._ghi(f'Kết quả năng lực "{viec.nang_luc}" sai khai báo: ' + '; '.join(loi))
                raise LoiNghiepVu('KET_QUA_SAI_KHAI_BAO',
                                  'Kết quả của engine không đúng khai báo trong phiếu.')
            return kq
        except ViecDaHuy:
            pass
        except LoiNghiepVu as exc:
            if not viec.da_huy:
                return self._ket_thuc(dt, viec, cfg, 'LOI', loi=exc)
        except ChuaRo as exc:
            if not viec.da_huy:
                return self._ket_thuc(dt, viec, cfg, 'CHUA_RO', ma_tuong_quan=exc.ma_tuong_quan)
        except LoiDuongTruyen as exc:
            viec._bao_mat_giu(exc)
            if not viec.da_huy:
                self._ghi(f'Lỗi trao đổi với Core khi làm việc {viec.id}: {exc.ma}.')
                return self._ket_thuc(dt, viec, cfg, 'LOI', loi=LoiNghiepVu(
                    'KHONG_TRAO_DOI_DUOC_CORE', 'Engine không trao đổi được với Core.',
                    thu_lai_duoc=True))
        except Exception:
            if not viec.da_huy:
                self._ghi('Lỗi khi xử lý việc ' + viec.id + ':\n' + traceback.format_exc())
                return self._ket_thuc(dt, viec, cfg, 'LOI', loi=LoiNghiepVu(
                    'ENGINE_LOI_XU_LY', 'Engine gặp lỗi khi xử lý việc này.'))
        if viec._mat_giu.is_set():
            self._ghi(f'Mất quyền giữ việc {viec.id}; Core sẽ giao lại, không nộp kết quả.')
            return 'MAT_GIU'
        return self._ket_thuc(dt, viec, cfg, 'HUY')

    def _ket_thuc(self, dt, viec, cfg, trang_thai, *, loi=None, ma_tuong_quan=None):
        than = {'trang_thai': trang_thai}
        if loi is not None:
            than['loi'] = {'ma': loi.ma, 'thong_diep': loi.thong_diep,
                           'thu_lai_duoc': loi.thu_lai_duoc}
        if ma_tuong_quan is not None:
            than['ma_tuong_quan'] = ma_tuong_quan
        try:
            _goi_lai(cfg, dt.ket_thuc, viec.id, than, khoa=viec._khoa.cho('ket_thuc'))
        except LoiDuongTruyen as exc:
            self._ghi(f'Không báo được kết thúc việc {viec.id} ({exc.ma}).')
            return 'CHUA_BAO_KET_THUC'
        return trang_thai


# ---------------------------------------------------------------------------
# Tương thích mã cũ: kênh socket của Core (core/kenh_engine.py,
# core/khoi_chay_engine.py) vẫn dùng các tên dưới đây. Không mở rộng; engine
# mới dùng Engine ở trên. Phần client Core (GiuViec, mã lỗi kênh) lấy trễ để
# nạp tệp này không kéo theo Core.

def __getattr__(ten):
    if ten == 'PHIEN_BAN_SDK_ENGINE':
        return phien_ban_sdk()
    if ten == 'GiuViec':
        from ._core.viec import GiuViec
        return GiuViec
    raise AttributeError(f'module {__name__!r} has no attribute {ten!r}')


def _lop_giu_viec():
    from ._core.viec import GiuViec
    return GiuViec


def _xoa_loi_cu(exc):
    from .ngu_canh import _xoa_loi
    _xoa_loi(exc)


class LoiEngine(RuntimeError):
    def __init__(self, ma='ENGINE_CORE'):
        from . import kenh_khung as k
        self.ma = ma
        self.http_status = 403 if ma == '42501' else k.MA_LOI_HTTP.get(
            ma, 409 if ma == 'VIEC_MAT_LEASE' else 503)
        self.thu_lai_duoc = False
        super().__init__(ma)


class KenhCore(ABC):
    """Kiểu kênh socket cũ do bootstrap Core cấp; adapter IPC triển khai goi.

    Không bọc callable tùy ý do engine đưa vào. Engine 2.0 dùng DuongTruyen.
    """

    __slots__ = ()

    @abstractmethod
    def goi(self, operation, giu_viec, **payload):
        raise NotImplementedError

    def __repr__(self):
        return 'KenhCore(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize KenhCore')


class SDKEngine:
    """Đối tượng việc của kênh socket cũ: doc_dau_vao, mo_doc, ghi_ket_qua,
    heartbeat. Lượt "chưa rõ" riêng đã bỏ (thành chung ở hợp đồng c.2 #10)."""

    __slots__ = ('__giu', '__kenh', '__dong_ho')

    def __init__(self, giu_viec, *, kenh_core, dong_ho=None):
        if not isinstance(giu_viec, _lop_giu_viec()) or not isinstance(kenh_core, KenhCore):
            raise TypeError('Cần GiuViec và kênh Core')
        self.__giu, self.__kenh = giu_viec, kenh_core
        self.__dong_ho = dong_ho or (lambda: datetime.now(timezone.utc))

    def __repr__(self):
        return 'SDKEngine(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize SDKEngine')

    def _goi(self, operation, **payload):
        if self.__giu.giu_den <= self.__dong_ho():
            raise LoiEngine('VIEC_MAT_LEASE')
        ma = 'ENGINE_CORE'
        try:
            return self.__kenh.goi(operation, self.__giu, **payload)
        except Exception as exc:
            if getattr(exc, 'ma', None) == 'VIEC_MAT_LEASE':
                ma = 'VIEC_MAT_LEASE'
            _xoa_loi_cu(exc)
        finally:
            payload = None
        raise LoiEngine(ma) from None

    def doc_dau_vao(self):
        return self._goi('doc_dau_vao')

    def mo_doc(self, tep_id):
        # Core đối chiếu tệp với đầu vào được cấp cho chính lease này.
        return self._goi('mo_doc', tep_id=tep_id)

    def ghi_ket_qua(self, *, luong, ten, du_lieu, revision_tep_truoc):
        # Không có tai_lieu/module/actor/engine/version tự khai trên API.
        truong = {'bien_the', 'ma_contract', 'phien_ban_contract',
                  'trang_thai', 'ly_do', 'revision_truoc', 'nguon'}
        if (not isinstance(du_lieu, dict) or not truong <= set(du_lieu)
                or set(du_lieu) - truong - {'goc_id'}):
            raise ValueError('Trường kết quả ngoài phạm vi')
        data = dict(du_lieu)
        return self._goi('ghi_ket_qua', luong=luong, ten=ten, du_lieu=data,
                         revision_tep_truoc=revision_tep_truoc)

    def heartbeat(self, *, lease_giay=120):
        if type(lease_giay) is not int or not 1 <= lease_giay <= 3600:
            raise ValueError('Lease ngoài giới hạn')
        moi = self._goi('heartbeat', lease_giay=lease_giay)
        cu = self.__giu
        # Chỉ gia hạn cùng lease; không cho kênh đổi việc/thế hệ/danh tính.
        if (not isinstance(moi, _lop_giu_viec()) or any(getattr(moi, k) != getattr(cu, k)
                for k in ('viec_id', 'buoc_viec_id', 'lan_thu_id', 'phap_nhan_id',
                          'module', 'hanh_dong', 'instance_id', 'the_he'))
                or moi.ma is not cu.ma or moi.giu_den <= self.__dong_ho()):
            raise LoiEngine('VIEC_MAT_LEASE')
        self.__giu = moi
        return True
