"""Core giả trong bộ nhớ để engine tự thử, không cần Core thật (lát L2.1).

    from kho_tri_thuc_sdk.thu import CoreGia
    kq = CoreGia().chay_thu(app, "<nhom>.<viec>@1", {"loai": "van_ban", "van_ban": "..."})
    kq["trang_thai"], kq["ket_qua"], kq["loi"]

CoreGia làm đúng bộ thao tác hợp đồng (c) c.2: nhận việc (engine chỉ thấy việc
của năng lực mình), đọc đầu vào, đọc tệp, tải tệp ra, gia hạn kèm cờ hủy, tiến
độ, nộp kết quả, kết thúc. Lệnh ghi phải có Idempotency-Key; cùng khóa thì trả
kết quả lần đầu, không ghi trùng. "Xong" chỉ nhận khi kết quả đã nộp.

MayChuGia bọc CoreGia thành máy chủ HTTP loopback cùng đường dẫn
/api/v1/engine/… để thử đường HTTP (kể cả chạy engine thành tiến trình riêng).

Chạy mọi ví dụ chay_thu_demo của một gói engine:
    python -m kho_tri_thuc_sdk.thu <thư mục gói>
Chỉ dùng dữ liệu DEMO.
"""

from __future__ import annotations

from collections import Counter
import copy
from datetime import datetime, timedelta, timezone
import http.server
import importlib
import itertools
import json
import mimetypes
from pathlib import Path
import re
import sys
import threading
import time
import urllib.parse
import uuid

from .engine import (DuongTruyen, Engine, LoiDuongTruyen, LoiPhieu, TRANG_THAI_KET_THUC,
                     doc_phieu)


__all__ = ('CoreGia', 'MayChuGia', 'main')

_GIO_VN = timezone(timedelta(hours=7))
_MIME_THEO_DUOI = {'.txt': 'text/plain', '.csv': 'text/csv', '.json': 'application/json',
                   '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg',
                   '.jpeg': 'image/jpeg', '.xml': 'application/xml'}


def _loi(ma, thong_diep, status, thu_lai=False):
    return LoiDuongTruyen(ma, thong_diep, http_status=status, thu_lai_duoc=thu_lai)


def _mime(ten):
    return (_MIME_THEO_DUOI.get(Path(ten).suffix.lower())
            or mimetypes.guess_type(ten)[0] or 'application/octet-stream')


class CoreGia:
    """Core giả trong bộ nhớ, an toàn khi nhiều luồng gọi."""

    def __init__(self):
        self._lock = threading.RLock()
        self._viec = {}
        self._hang = []
        self._tep = {}
        self._idem = {}
        self._engine = {}
        self._mat_xac_nhan = Counter()
        self._dem = itertools.count(1)
        self.so_lan_ghi = Counter()   # số lần Core thật sự ghi, theo thao tác
        self.nhat_ky = []             # (thao_tac, ma_engine, viec_id, khoa) mỗi lời gọi ghi

    # -- phía "người dùng/Core" ------------------------------------------
    def them_tep(self, ten, du_lieu, mime=None):
        """Đưa một tệp DEMO vào kho; trả đối tượng tệp cho phong bì."""
        with self._lock:
            tep_id = f'tep-{next(self._dem)}'
            self._tep[tep_id] = (ten, mime or _mime(ten), bytes(du_lieu))
            return {'tep_id': tep_id, 'ten': ten, 'mime': mime or _mime(ten),
                    'kich_thuoc': len(du_lieu)}

    def doc_tep(self, tep_id):
        with self._lock:
            return self._tep[tep_id][2]

    def giao_viec(self, nang_luc, dau_vao, tham_so=None, *, buoc=1,
                  phap_nhan_id='pn-demo', gui_kem_dau_vao=True):
        """Xếp một việc vào hàng; trả mã việc."""
        with self._lock:
            viec_id = f'viec-{next(self._dem)}'
            self._viec[viec_id] = dict(
                id=viec_id, nang_luc=nang_luc, dau_vao=copy.deepcopy(dau_vao),
                tham_so=copy.deepcopy(tham_so or {}), buoc=buoc, phap_nhan_id=phap_nhan_id,
                gui_kem=gui_kem_dau_vao, trang_thai='CHO', ma_engine=None, co_huy=False,
                lan_thu=0, ket_qua=None, loi=None, ma_tuong_quan=None, tien_do=[])
            self._hang.append(viec_id)
            return viec_id

    def huy(self, viec_id):
        """Người dùng bấm Hủy: việc chờ thì hủy ngay, đang chạy thì báo cờ `huy`."""
        with self._lock:
            v = self._viec[viec_id]
            if v['trang_thai'] == 'CHO':
                v['trang_thai'] = 'HUY'
                self._hang.remove(viec_id)
            elif v['trang_thai'] == 'DANG_CHAY':
                v['co_huy'] = True

    def xem(self, viec_id):
        with self._lock:
            v = self._viec[viec_id]
            return copy.deepcopy({k: v[k] for k in (
                'id', 'nang_luc', 'trang_thai', 'ket_qua', 'loi', 'ma_tuong_quan',
                'tien_do', 'lan_thu', 'ma_engine')})

    def gay_mat_xac_nhan(self, thao_tac, so_lan=1):
        """Thử: `so_lan` lời gọi `thao_tac` kế tiếp (ket_qua, ket_thuc, tep) được
        Core ghi xong nhưng phản hồi mất trên đường về."""
        with self._lock:
            self._mat_xac_nhan[thao_tac] += so_lan

    def duong_truyen(self, ma_engine, instance=None):
        return _DuongGia(self, ma_engine, instance or f'gia-{uuid.uuid4().hex[:8]}')

    def chay(self, app, **tuy_chon):
        """Cho engine làm hết việc đang chờ của nó rồi dừng."""
        tuy_chon.setdefault('khoang_gia_han', 0.01)
        tuy_chon.setdefault('cho_gui_lai_giay', 0)
        app.chay(self.duong_truyen(app.ma), dung_khi_het_viec=True, **tuy_chon)

    def chay_thu(self, app, nang_luc, dau_vao, tham_so=None, **tuy_chon):
        """Giao một việc, cho engine chạy, trả trạng thái và kết quả."""
        viec_id = self.giao_viec(nang_luc, dau_vao, tham_so)
        self.chay(app, **tuy_chon)
        return self.xem(viec_id)

    def chay_thu_demo(self, app, thu_muc_goi=None):
        """Chạy mọi ví dụ `chay_thu_demo` trong phiếu; `tep_demo` đọc trong gói."""
        goc = Path(thu_muc_goi or app.thu_muc_goi or '.')
        ket_qua = []
        for vd in app.phieu.get('chay_thu_demo', []):
            dau_vao = copy.deepcopy(vd['dau_vao'])
            if dau_vao.get('loai') == 'tep' and 'tep_demo' in dau_vao:
                tep = goc / dau_vao['tep_demo']
                dau_vao = {'loai': 'tep', 'tep': self.them_tep(tep.name, tep.read_bytes())}
            kq = self.chay_thu(app, vd['nang_luc'], dau_vao, vd.get('tham_so'))
            ket_qua.append({'ten': vd['ten'], **kq})
        return ket_qua

    # -- phía engine (qua _DuongGia) --------------------------------------
    def _cua_engine(self, ma_engine, viec_id):
        v = self._viec.get(viec_id)
        if v is None or v['ma_engine'] != ma_engine:
            raise _loi('KHONG_TIM_THAY', 'Không thấy việc.', 404)
        return v

    def _dang_giu(self, ma_engine, viec_id):
        v = self._cua_engine(ma_engine, viec_id)
        if v['trang_thai'] != 'DANG_CHAY':
            raise _loi('MAT_LEASE', 'Việc không còn do engine này giữ.', 409)
        return v

    def _ghi(self, thao_tac, ma_engine, viec_id, khoa, lam):
        """Lệnh ghi có Idempotency-Key: cùng khóa trả kết quả lần đầu."""
        with self._lock:
            self.nhat_ky.append((thao_tac, ma_engine, viec_id, khoa))
            if not isinstance(khoa, str) or not 8 <= len(khoa) <= 200:
                raise _loi('YEU_CAU_KHONG_HOP_LE', 'Lệnh ghi thiếu Idempotency-Key.', 400)
            k = (ma_engine, thao_tac, viec_id, khoa)
            if k in self._idem:
                kq = copy.deepcopy(self._idem[k])
            else:
                kq = lam()
                self.so_lan_ghi[thao_tac] += 1
                self._idem[k] = copy.deepcopy(kq)
            if self._mat_xac_nhan[thao_tac] > 0:
                self._mat_xac_nhan[thao_tac] -= 1
                raise _loi('MAT_PHAN_HOI', 'Mất phản hồi (giả lập).', 503, True)
            return kq

    def _san_sang(self, ma, instance, phien_ban, nang_luc):
        with self._lock:
            self._engine[ma] = dict(instance=instance, phien_ban=phien_ban,
                                    nang_luc=list(nang_luc))
            return {'cau_hinh': {}}

    def _nhan_viec(self, ma):
        with self._lock:
            dk = self._engine.get(ma)
            if dk is None:
                raise _loi('CHUA_SAN_SANG', 'Engine chưa báo sẵn sàng.', 409)
            for viec_id in self._hang:
                v = self._viec[viec_id]
                if v['nang_luc'] in dk['nang_luc']:
                    self._hang.remove(viec_id)
                    v.update(trang_thai='DANG_CHAY', ma_engine=ma, lan_thu=v['lan_thu'] + 1)
                    viec = dict(id=viec_id, nang_luc=v['nang_luc'],
                                tham_so=copy.deepcopy(v['tham_so']),
                                ngu_canh={'viec_id': viec_id, 'buoc': v['buoc'],
                                          'phap_nhan_id': v['phap_nhan_id']},
                                han_giu=self._han(60), lan_thu=v['lan_thu'])
                    if v['gui_kem']:
                        viec['dau_vao'] = copy.deepcopy(v['dau_vao'])
                    return viec
            return None

    @staticmethod
    def _han(giay):
        return (datetime.now(_GIO_VN) + timedelta(seconds=giay)).isoformat(timespec='seconds')

    def _doc_dau_vao(self, ma, viec_id):
        with self._lock:
            return copy.deepcopy(self._dang_giu(ma, viec_id)['dau_vao'])

    def _mo_tep(self, ma, viec_id, tep_id, toi_da_byte):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            # Engine chỉ đọc được tệp nằm trong đầu vào việc của mình.
            if tep_id not in self._tep or json.dumps(tep_id) not in json.dumps(v['dau_vao']):
                raise _loi('KHONG_TIM_THAY', 'Không thấy tệp.', 404)
            du_lieu = self._tep[tep_id][2]
            if len(du_lieu) > toi_da_byte:
                raise _loi('VUOT_GIOI_HAN_KICH_THUOC', 'Tệp lớn quá giới hạn.', 413)
            return du_lieu

    def _tai_tep_ra(self, ma, viec_id, ten, du_lieu, mime, khoa):
        with self._lock:
            self._dang_giu(ma, viec_id)

            def lam():
                return {'tep_id': self.them_tep(ten, du_lieu, mime)['tep_id']}
            return self._ghi('tep', ma, viec_id, khoa, lam)

    def _gia_han(self, ma, viec_id, han_giu_giay):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            return {'han_giu': self._han(han_giu_giay), 'huy': v['co_huy']}

    def _tien_do(self, ma, viec_id, phan_tram, cau):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            v['tien_do'].append((phan_tram, cau))
            return {'huy': v['co_huy']}

    def _nop_ket_qua(self, ma, viec_id, phong_bi, khoa):
        with self._lock:
            k = (ma, 'ket_qua', viec_id, khoa)
            if k not in self._idem:
                self._dang_giu(ma, viec_id)

            def lam():
                self._viec[viec_id]['ket_qua'] = copy.deepcopy(phong_bi)
                return {'da_luu': True}
            return self._ghi('ket_qua', ma, viec_id, khoa, lam)

    def _ket_thuc(self, ma, viec_id, than, khoa):
        with self._lock:
            k = (ma, 'ket_thuc', viec_id, khoa)
            if k not in self._idem:
                v = self._dang_giu(ma, viec_id)
                tt = than.get('trang_thai') if isinstance(than, dict) else None
                if tt not in TRANG_THAI_KET_THUC:
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Trạng thái kết thúc không hợp lệ.', 400)
                if tt == 'XONG' and v['ket_qua'] is None:
                    raise _loi('XUNG_DOT', 'Chưa nộp kết quả thì chưa được báo xong.', 409)
                loi = than.get('loi')
                if tt == 'LOI' and not (isinstance(loi, dict)
                                        and {'ma', 'thong_diep', 'thu_lai_duoc'} <= set(loi)):
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Báo lỗi thiếu phong bì lỗi.', 400)
                if tt == 'CHUA_RO' and not than.get('ma_tuong_quan'):
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Báo "chưa rõ" thiếu mã tương quan.', 400)

            def lam():
                v = self._viec[viec_id]
                v.update(trang_thai=than['trang_thai'], loi=copy.deepcopy(than.get('loi')),
                         ma_tuong_quan=than.get('ma_tuong_quan'))
                if than['trang_thai'] != 'XONG':
                    v['ket_qua'] = None
                return {}
            return self._ghi('ket_thuc', ma, viec_id, khoa, lam)


class _DuongGia(DuongTruyen):
    """Đường truyền của một engine tới CoreGia (không qua mạng)."""

    def __init__(self, core, ma_engine, instance):
        self._core, self.ma_engine, self.instance = core, ma_engine, instance

    def san_sang(self, phien_ban, nang_luc):
        return self._core._san_sang(self.ma_engine, self.instance, phien_ban, nang_luc)['cau_hinh']

    def nhan_viec(self, cho_toi_da_giay):
        # Core giả chờ tối đa 1 giây để engine dừng (app.dung) nhanh khi thử.
        han = time.monotonic() + max(0, min(cho_toi_da_giay, 1))
        while True:
            viec = self._core._nhan_viec(self.ma_engine)
            if viec is not None or time.monotonic() >= han:
                return viec
            time.sleep(0.02)

    def doc_dau_vao(self, viec_id):
        return self._core._doc_dau_vao(self.ma_engine, viec_id)

    def mo_tep(self, viec_id, tep_id, toi_da_byte):
        return self._core._mo_tep(self.ma_engine, viec_id, tep_id, toi_da_byte)

    def tai_tep_ra(self, viec_id, ten, du_lieu, mime, khoa):
        return self._core._tai_tep_ra(self.ma_engine, viec_id, ten, du_lieu, mime, khoa)

    def gia_han(self, viec_id, han_giu_giay):
        return self._core._gia_han(self.ma_engine, viec_id, han_giu_giay)

    def tien_do(self, viec_id, phan_tram, cau):
        return self._core._tien_do(self.ma_engine, viec_id, phan_tram, cau)

    def nop_ket_qua(self, viec_id, phong_bi, khoa):
        return self._core._nop_ket_qua(self.ma_engine, viec_id, phong_bi, khoa)

    def ket_thuc(self, viec_id, than, khoa):
        return self._core._ket_thuc(self.ma_engine, viec_id, than, khoa)


# ---------------------------------------------------------------------------
# Máy chủ HTTP giả: cùng đường dẫn và xác thực như hợp đồng (c), chỉ loopback.

_DUONG_ENGINE = re.compile(r'/api/v1/engine/([a-z0-9_]+)/(san-sang|viec/nhan)')
_DUONG_VIEC = re.compile(r'/api/v1/engine/viec/([^/]+)/(dau-vao|tep|tep/[^/]+|gia-han|'
                         r'tien-do|ket-qua|ket-thuc)')


class MayChuGia:
    """`with MayChuGia(core, {"<ma engine>": "<khóa>"}) as may: may.url`.

    Ghi lại header mỗi lời gọi ở `cac_loi_goi` để test kiểm xác thực, khóa chống trùng.
    """

    def __init__(self, core, khoa_engine=None, *, xac_thuc=None, khi_san_sang=None):
        """khoa_engine: {ma: khóa} cố định; hoặc xac_thuc(ma, khoa, instance) -> bool
        do bên ngoài cấp (vd bộ khởi động engine của Core). khi_san_sang(ma, khoa,
        instance, phien_ban, nang_luc) được gọi khi engine báo `san-sang`."""
        self.core = core
        self._khoa = dict(khoa_engine or {})
        self._xac_thuc = xac_thuc
        self._khi_san_sang = khi_san_sang
        self.cac_loi_goi = []
        self._may = None
        self._luong = None

    @property
    def url(self):
        return f'http://127.0.0.1:{self._may.server_address[1]}'

    def __enter__(self):
        cha = self

        class XuLy(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *a):
                pass

            def do_GET(self):
                cha._xu_ly(self, 'GET')

            def do_POST(self):
                cha._xu_ly(self, 'POST')

            def do_PUT(self):
                cha._xu_ly(self, 'PUT')

        class MayChu(http.server.ThreadingHTTPServer):
            daemon_threads = True

            def handle_error(self, request, client_address):
                if not isinstance(sys.exc_info()[1], ConnectionError):
                    super().handle_error(request, client_address)

        self._may = MayChu(('127.0.0.1', 0), XuLy)
        self._luong = threading.Thread(target=self._may.serve_forever, daemon=True)
        self._luong.start()
        return self

    def __exit__(self, *exc):
        self._may.shutdown()
        self._may.server_close()

    def _tra(self, h, status, du_lieu=None, *, nhi_phan=None, loai='application/json'):
        raw = nhi_phan if nhi_phan is not None else (
            b'' if du_lieu is None else json.dumps(du_lieu, ensure_ascii=False).encode('utf-8'))
        h.send_response(status)
        if status != 204:
            h.send_header('Content-Type', loai)
        h.send_header('Content-Length', str(len(raw) if status != 204 else 0))
        h.end_headers()
        if status != 204:
            h.wfile.write(raw)

    def _xu_ly(self, h, phuong_thuc):
        duong = urllib.parse.urlsplit(h.path).path
        do_dai = int(h.headers.get('Content-Length') or 0)
        than = h.rfile.read(do_dai) if do_dai else b''
        ma = h.headers.get('X-KTT-Engine', '')
        instance = h.headers.get('X-KTT-Instance', '')
        khoa = h.headers.get('Idempotency-Key')
        self.cac_loi_goi.append(dict(phuong_thuc=phuong_thuc, duong=duong, ma_engine=ma,
                                     instance=instance, idempotency_key=khoa,
                                     co_bearer=h.headers.get('Authorization', '').startswith('Bearer ')))
        try:
            auth = h.headers.get('Authorization', '')
            khoa_gui = auth[7:] if auth.startswith('Bearer ') else ''
            if self._xac_thuc is not None:
                dung = bool(instance) and self._xac_thuc(ma, khoa_gui, instance)
            else:
                dung = bool(instance) and ma in self._khoa and khoa_gui == self._khoa[ma]
            if not dung:
                raise _loi('KENH_XAC_THUC_KHONG_HOP_LE', 'Khóa engine không đúng.', 401)
            c = self.core
            m = _DUONG_ENGINE.fullmatch(duong)
            if m:
                if m[1] != ma:
                    raise _loi('KENH_KHONG_DU_QUYEN', 'Engine chỉ gọi đường của mình.', 403)
                du = json.loads(than or b'{}')
                if m[2] == 'san-sang' and phuong_thuc == 'POST':
                    if self._khi_san_sang is not None:
                        try:
                            self._khi_san_sang(ma, khoa_gui, instance, du.get('phien_ban'),
                                               du.get('nang_luc') or [])
                        except Exception as exc:  # Core từ chối báo sẵn sàng
                            raise _loi(getattr(exc, 'ma', 'KHONG_NHAN_SAN_SANG'),
                                       getattr(exc, 'thong_diep', 'Core không nhận báo sẵn sàng.'),
                                       getattr(exc, 'http_status', 409)) from None
                    return self._tra(h, 200, c._san_sang(ma, instance, du.get('phien_ban'),
                                                         du.get('nang_luc') or []))
                if m[2] == 'viec/nhan' and phuong_thuc == 'POST':
                    viec = _DuongGia(c, ma, instance).nhan_viec(
                        min(float(du.get('cho_toi_da_giay', 0)), 2))
                    return self._tra(h, 204) if viec is None else self._tra(h, 200, {'viec': viec})
            m = _DUONG_VIEC.fullmatch(duong)
            if m:
                viec_id, viec_duoi = urllib.parse.unquote(m[1]), m[2]
                if viec_duoi == 'dau-vao' and phuong_thuc == 'GET':
                    return self._tra(h, 200, c._doc_dau_vao(ma, viec_id))
                if viec_duoi.startswith('tep/') and phuong_thuc == 'GET':
                    tep_id = urllib.parse.unquote(viec_duoi[4:])
                    return self._tra(h, 200, nhi_phan=c._mo_tep(ma, viec_id, tep_id, 1 << 31),
                                     loai='application/octet-stream')
                if viec_duoi == 'tep' and phuong_thuc == 'POST':
                    ten = urllib.parse.unquote(h.headers.get('X-KTT-Ten-Tep', ''))
                    return self._tra(h, 200, c._tai_tep_ra(
                        ma, viec_id, ten, than, h.headers.get('Content-Type'), khoa))
                du = json.loads(than or b'{}')
                if viec_duoi == 'gia-han' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._gia_han(ma, viec_id, du.get('han_giu_giay', 60)))
                if viec_duoi == 'tien-do' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._tien_do(ma, viec_id, du.get('phan_tram'),
                                                        du.get('cau', '')))
                if viec_duoi == 'ket-qua' and phuong_thuc == 'PUT':
                    return self._tra(h, 200, c._nop_ket_qua(ma, viec_id, du, khoa))
                if viec_duoi == 'ket-thuc' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._ket_thuc(ma, viec_id, du, khoa))
            raise _loi('KHONG_TIM_THAY', 'Không có đường này.', 404)
        except ConnectionError:  # engine đã đóng kết nối (bị dừng giữa lúc chờ)
            raise
        except LoiDuongTruyen as exc:
            # Phong bì lỗi dạng phẳng như máy chủ Core (hợp đồng bản 1.3).
            self._tra(h, exc.http_status or 400, {
                'ma': exc.ma, 'thong_diep': exc.thong_diep, 'request_id': uuid.uuid4().hex,
                'thu_lai_duoc': exc.thu_lai_duoc})
        except Exception:
            self._tra(h, 500, {'ma': 'LOI_NOI_BO', 'thong_diep': 'Core giả gặp lỗi.',
                               'request_id': uuid.uuid4().hex, 'thu_lai_duoc': False})


# ---------------------------------------------------------------------------
# Lệnh: python -m kho_tri_thuc_sdk.thu <thư mục gói>

def _module_diem_vao(phieu):
    lenh = phieu.get('diem_vao', {}).get('lenh', [])
    for i, x in enumerate(lenh[:-1]):
        if x == '-m':
            return lenh[i + 1]
    return phieu['ma'] + '.chay'


def nap_engine_tu_goi(thu_muc_goi):
    """Nạp đối tượng Engine của một gói (module ở diem_vao, sau "-m")."""
    goc = Path(thu_muc_goi).resolve()
    phieu = doc_phieu(goc / 'engine.json')
    thu_muc = goc / phieu.get('diem_vao', {}).get('thu_muc', '.')
    if str(thu_muc) not in sys.path:
        sys.path.insert(0, str(thu_muc))
    module = importlib.import_module(_module_diem_vao(phieu))
    for gia_tri in vars(module).values():
        if isinstance(gia_tri, Engine) and gia_tri.ma == phieu['ma']:
            return gia_tri
    raise LoiPhieu([f'Không thấy đối tượng Engine trong module "{module.__name__}".'])


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        print('Cách dùng: python -m kho_tri_thuc_sdk.thu <thư mục gói engine>')
        return 2
    try:
        app = nap_engine_tu_goi(argv[0])
    except LoiPhieu as exc:
        print(str(exc))
        return 2
    ket_qua = CoreGia().chay_thu_demo(app)
    if not ket_qua:
        print('Phiếu chưa có ví dụ chay_thu_demo.')
        return 1
    dat = True
    for kq in ket_qua:
        ok = kq['trang_thai'] == 'XONG'
        dat = dat and ok
        chi_tiet = kq['ket_qua'] if ok else (kq['loi'] or {}).get('thong_diep', kq['trang_thai'])
        s = json.dumps(chi_tiet, ensure_ascii=False)
        print(f'[{"ĐẠT" if ok else "LỖI"}] {kq["ten"]}: {s[:300]}')
    print(f'Engine {app.ma} {app.phien_ban}: '
          + ('mọi ví dụ chạy thử DEMO đều đạt.' if dat else 'có ví dụ chạy thử DEMO chưa đạt.'))
    return 0 if dat else 1


if __name__ == '__main__':
    raise SystemExit(main())
