"""Façade tệp qua N2; không giữ KhoTep, đường dẫn hay kết nối Core.

Bootstrap cấp KenhCore và binding từng operation trong ngu_canh. ctx là
header cha đã kiểm của runtime N1/N2, hoặc None cho call gốc. Call con ghi
phải có thu_tu_con ổn định qua replay, do nghiệp vụ chọn.
"""

from datetime import datetime
import io
import re

def _tham_chieu(value):
    from . import kenh_khung as k
    ma = 'PHAN_HOI_SAI_CONTRACT'
    k._dong(value, {'contract', 'phien_ban', 'tep_id', 'ten_tep', 'mime',
                    'kich_thuoc', 'sha256', 'het_han_luc'}, ma=ma)
    k._can(value['contract'] == 'tham_chieu_tep.v1'
           and value['phien_ban'] == '1.0.0' and k._uuid(value['tep_id'])
           and k._hash(value['sha256']) and k._chuoi(value['mime'])
           and type(value['kich_thuoc']) is int
           and 0 <= value['kich_thuoc'] <= k.GIOI_HAN_TEP, ma)
    _ten(value['ten_tep'], ma)
    han = value['het_han_luc']
    if han is not None:
        k._can(type(han) is str, ma)
        try:
            dung = datetime.fromisoformat(han.replace('Z', '+00:00')).tzinfo is not None
        except ValueError:
            dung = False
        k._can(dung, ma)
    return dict(value)


def _ten(value, ma='KENH_DU_LIEU_KHONG_HOP_LE'):
    from . import kenh_khung as k
    k._can(type(value) is str and bool(value.strip()) and len(value) <= 240
           and value not in {'.', '..'}
           and not any(c in '/\\:' or ord(c) < 32 or ord(c) == 127 for c in value), ma)


class Tep:
    __slots__ = ('__kenh', '__ngu_canh', '__gioi_han')

    def __init__(self, kenh_core, *, ngu_canh, gioi_han=None):
        # Giữ import SDK thuần không nạp cryptography/transport khi chưa dùng.
        from . import kenh_khung as k
        from .kenh_core import KenhCore
        if gioi_han is None:
            gioi_han = k.GIOI_HAN_TEP
        k._can(isinstance(kenh_core, KenhCore) and type(ngu_canh) is dict
               and set(ngu_canh) == {'tep.tai_len', 'tep.tham_chieu', 'tep.mo_doc'}
               and all(type(h) is dict for h in ngu_canh.values())
               and type(gioi_han) is int and 0 < gioi_han <= k.GIOI_HAN_TEP)
        self.__kenh = kenh_core
        self.__ngu_canh = {op: dict(h) for op, h in ngu_canh.items()}
        self.__gioi_han = gioi_han

    def __repr__(self):
        return 'TepSDK(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize dịch vụ tệp SDK')

    def _goi(self, op, ctx, data, *, khoa=None, tep=None, thu_tu_con=None):
        return self.__kenh.goi(op, data, ngu_canh=self.__ngu_canh[op],
            parent=ctx, thu_tu_con=thu_tu_con, khoa=khoa, tep=tep)

    def tai_len(self, ctx, luong, ten, mime, khoa, *, thu_tu_con=None):
        """Đọc hữu hạn ≤20 MiB; luồng đầu vào vẫn thuộc caller.

        MIME là khai báo để Core đối chiếu bytes, không quyết định MIME lưu.
        """
        from . import kenh_khung as k
        from .kenh_core import TepHuuHan
        _ten(ten)
        k._can(type(mime) is str and re.fullmatch(r'[\w.+-]+/[\w.+-]+', mime) is not None)
        k._can(type(khoa) is str and re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa) is not None)

        def chunks():
            tong = 0
            while True:
                chunk = luong.read(min(k.GIOI_HAN_CHUNK, self.__gioi_han - tong + 1))
                k._can(type(chunk) is bytes)
                tong += len(chunk)
                k._can(tong <= self.__gioi_han, 'VUOT_GIOI_HAN_KICH_THUOC')
                if not chunk:
                    return
                yield chunk

        tep = TepHuuHan(chunks(), mime=mime, ten=ten, gioi_han=self.__gioi_han)
        got = self._goi('tep.tai_len', ctx, dict(ten=ten, mime=mime),
                        khoa=khoa, tep=tep, thu_tu_con=thu_tu_con)
        k._can(got.header['stream'] is None and got.header['da_commit'], 'PHAN_HOI_SAI_CONTRACT')
        ref = _tham_chieu(got.json())
        k._can(ref['sha256'] == tep.descriptor['sha256']
               and ref['kich_thuoc'] == tep.descriptor['kich_thuoc_byte']
               and ref['mime'] == mime, 'PHAN_HOI_SAI_CONTRACT')
        return ref

    def tham_chieu(self, ctx, tep_id, *, thu_tu_con=None):
        """Core tự tra ngữ cảnh và quyền hiện tại, cả sau khi tệp đã gắn tài liệu."""
        from . import kenh_khung as k
        k._can(k._uuid(str(tep_id)))
        got = self._goi('tep.tham_chieu', ctx, dict(tep_id=str(tep_id)), thu_tu_con=thu_tu_con)
        k._can(got.header['stream'] is None, 'PHAN_HOI_SAI_CONTRACT')
        ref = _tham_chieu(got.json())
        k._can(ref['tep_id'] == str(tep_id), 'PHAN_HOI_SAI_CONTRACT')
        return ref

    def mo_doc(self, ctx, tep_id, *, thu_tu_con=None):
        """BinaryIO RAM; dùng ``with tep.mo_doc(ctx, id) as luong`` để đóng.

        Cùng tep_id vẫn dùng được sau attach; Core kiểm lại quyền tài liệu.
        """
        from . import kenh_khung as k
        k._can(k._uuid(str(tep_id)))
        got = self._goi('tep.mo_doc', ctx, dict(tep_id=str(tep_id)), thu_tu_con=thu_tu_con)
        k._can(got.header['stream'] is not None, 'PHAN_HOI_SAI_CONTRACT')
        k._can(len(got.than) <= self.__gioi_han, 'VUOT_GIOI_HAN_KICH_THUOC')
        return io.BytesIO(got.than)
