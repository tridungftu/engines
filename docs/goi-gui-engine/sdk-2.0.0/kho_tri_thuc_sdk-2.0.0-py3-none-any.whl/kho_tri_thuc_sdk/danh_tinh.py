"""Façade danh tính; chỉ dùng ngữ cảnh đã kiểm và kênh bootstrap cấp.

Runtime cấp kênh gắn request, tự giữ header cha và binding operation.
Khi dùng trực tiếp KenhCore N2, composition root cấp binding(ctx, operation)
và parent đã kiểm. Không lấy actor, quyền hay binding từ body nghiệp vụ.
"""

from dataclasses import dataclass
import re
import time
from uuid import UUID

from .dich_vu import LoiDichVu, _DichVu
from .ngu_canh import NguCanh, NhanRequest, LoiNguCanh, _DA_KIEM, _xoa_loi


@dataclass(frozen=True)
class DanhTinh:
    nguoi_dung_id: UUID
    phap_nhan_id: UUID
    module: str
    hanh_dong: str


def nhan_request(request, instance):
    """request đóng chứa thẻ/bytes gốc và operation lấy từ registry tin cậy.

    instance là NhanRequest đã được bootstrap bằng public key ghim.
    """
    required = {'the', 'method', 'duong_dan', 'body', 'operation', 'hanh_dong'}
    if (not isinstance(instance, NhanRequest) or type(request) is not dict
            or not required <= request.keys() or request.keys() - required - {'khoa'}):
        raise LoiNguCanh()
    return instance.nhan_request(**request)


class DichVuDanhTinh(_DichVu):
    __slots__ = ('__kenh', '__binding', '__parent')

    def __init__(self, kenh_core=None, *, binding=None, parent=None):
        if (kenh_core is not None and not callable(getattr(kenh_core, 'goi', None))
                or binding is not None and not callable(binding)):
            raise TypeError('Cần kênh và binding do bootstrap cấp')
        self.__kenh, self.__binding, self.__parent = kenh_core, binding, parent

    nhan_request = staticmethod(nhan_request)

    def _goi(self, ctx, operation, data, thu_tu):
        # Import SDK thuần/wheel không đòi thư viện chữ ký trước khi dùng kênh.
        from . import kenh_khung as k
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den):
            raise LoiNguCanh()
        if self.__kenh is None:
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        ma, status = 'LOI_NOI_BO', 500
        da_nhan = False
        try:
            header = ctx if self.__binding is None else self.__binding(ctx, operation)
            if self.__binding is not None:
                k._can(all(header[name] == value for name, value in {
                    'module': ctx.module, 'hanh_dong': ctx.hanh_dong,
                    'instance_id': str(ctx.instance_id),
                    'nguoi_dung_id': str(ctx.nguoi_dung_id),
                    'phap_nhan_id': str(ctx.phap_nhan_id)}.items()),
                    'KENH_KHONG_DU_QUYEN')
            args = dict(ngu_canh=header, thu_tu_con=thu_tu)
            if self.__parent is not None:
                args['parent'] = self.__parent
            elif self.__binding is not None:
                args['thu_tu_con'] = None
            result = self.__kenh.goi(operation, data, **args)
            da_nhan = True
            return result.json()
        except Exception as exc:
            if da_nhan:
                ma, status = 'PHAN_HOI_SAI_CONTRACT', 502
            elif isinstance(exc, k.LoiKenh):
                ma, status = exc.ma, exc.http_status
            _xoa_loi(exc)
        raise LoiDichVu(ma, status) from None

    def hien_tai(self, ctx) -> DanhTinh:
        data = self._goi(ctx, 'danh_tinh.hien_tai', {}, 1)
        expected = dict(nguoi_dung_id=str(ctx.nguoi_dung_id),
            phap_nhan_id=str(ctx.phap_nhan_id), module=ctx.module, hanh_dong=ctx.hanh_dong)
        if type(data) is not dict or data != expected:
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
        return DanhTinh(ctx.nguoi_dung_id, ctx.phap_nhan_id, ctx.module, ctx.hanh_dong)

    def kiem_quyen(self, ctx, hanh_dong, doi_tuong) -> None:
        if (not isinstance(ctx, NguCanh) or not isinstance(hanh_dong, str)
                or not re.fullmatch(ctx.module.upper() + r':[A-Z0-9_]+:[A-Z_]+', hanh_dong)
                or type(doi_tuong) is not dict
                or not {'bang', 'id'} <= doi_tuong.keys()
                or doi_tuong.keys() - {'bang', 'id', 'phong_id'}
                or not isinstance(doi_tuong['bang'], str) or not doi_tuong['bang'].strip()):
            raise LoiDichVu('SDK_DAU_VAO', 422)
        try:
            target = dict(doi_tuong, id=str(UUID(str(doi_tuong['id']))))
            if target.get('phong_id') is not None:
                target['phong_id'] = str(UUID(str(target['phong_id'])))
        except (ValueError, TypeError, AttributeError):
            raise LoiDichVu('SDK_DAU_VAO', 422) from None
        data = self._goi(ctx, 'danh_tinh.kiem_quyen',
                         dict(hanh_dong=hanh_dong, doi_tuong=target), 2)
        if type(data) is not dict or data:
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)


_mac_dinh = DichVuDanhTinh()
hien_tai = _mac_dinh.hien_tai
kiem_quyen = _mac_dinh.kiem_quyen
