"""LHD-E1: kiểm danh mục thuần, không truy cập Core, engine hay dữ liệu ngoài.

kiem_tra_danh_muc nhận dòng gồm tiêu đề và dữ liệu; doc_danh_muc nhận bytes
Excel (không nhận đường dẫn). Kết quả chứa cả dòng ngừng dùng và tham_so chỉ
gồm dòng đang dùng, tương thích danh_muc_xd. Lỗi có mã cố định, dòng/cột Excel
và thông báo tiếng Việt riêng; không dùng mã lỗi làm nội dung hiển thị.

Sheet Quy_tac tùy chọn có QUY_TAC_HEADER. Ba kiểu: Tổng tỷ lệ (điều kiện =
hoặc <=, đối chiếu 100); Ngày không sau (<=, đối chiếu một mã); Có thì phải
có (điều kiện trống, đối chiếu một mã). Các mã nguồn phân cách bằng dấu ;.
Mã băm nội dung là SHA-256 JSON chuẩn của đúng 10 cột đã chuẩn hóa, gồm cả
dòng ngừng dùng và thứ tự; mã băm tệp ghim cả sheet quy tắc.
"""

from __future__ import annotations

from dataclasses import dataclass, field
import hashlib
import io
import json
import posixpath
import re
import unicodedata
import xml.etree.ElementTree as ET
import zipfile
import zlib

from . import xlsx_mini


HEADER = ["Mã", "Nhóm", "Mô tả cho AI", "Từ khoá tiêu đề", "Từ khoá nội dung",
          "Dùng (Có/Không)", "Mức quan trọng (0–3)", "Từ khoá bắt buộc (L4)",
          "Từ khoá loại trừ (L4)", "Luôn hỏi Claude (Có/Không)"]
KHOA = ["ma", "nhom", "mo_ta", "tk", "bk", "dung", "muc", "bat_buoc", "loai_tru", "luon_cloud"]
DO_RONG = [8, 22, 80, 28, 36, 10, 10, 30, 30, 14]
QUY_TAC_HEADER = ["Kiểu quy tắc", "Mã tham số", "Điều kiện", "Giá trị hoặc mã đối chiếu"]
GIOI_HAN_TEP = 2 * 1024 * 1024
# Chặn ZIP phình trước khi bộ đọc nguồn giải nén hoặc tạo danh sách ô.
GIOI_HAN_GIAI_NEN = 16 * 1024 * 1024
_NS = "{http://schemas.openxmlformats.org/spreadsheetml/2006/main}"
_REL = "{http://schemas.openxmlformats.org/officeDocument/2006/relationships}"
_MA = re.compile(r"[A-Z]{2,3}-[0-9]{2,3}\Z")
_O = re.compile(r"([A-Z]{1,3})([1-9][0-9]*)\Z")


@dataclass(frozen=True)
class VanDeDanhMuc:
    ma: str
    dong: int | None
    cot: str | None
    thong_bao: str


class LoiDanhMuc(ValueError):
    def __init__(self, loi):
        self.loi = tuple(loi)
        super().__init__("\n".join(v.thong_bao for v in self.loi))


@dataclass
class DanhMucThamSo:
    cac_dong: list[dict]
    quy_tac: list[dict]
    ma_bam_noi_dung: str
    canh_bao: list[VanDeDanhMuc] = field(default_factory=list)
    ma_bam: str | None = None
    co_sheet_quy_tac: bool = False

    @property
    def tham_so(self):
        """Định dạng pipeline gốc, giữ nguyên chữ mô tả và thứ tự mã."""
        return [{"ma": r["ma"], "nhom": r["nhom"], "mo_ta": r["mo_ta"],
                 "ten": re.split(r"[(:;—]", r["mo_ta"])[0].strip()[:60],
                 "tieu_de_kws": _tach(r["tk"]), "noi_dung_kws": _tach(r["bk"]),
                 "muc": r["muc"], "bat_buoc": _tach(r["bat_buoc"]),
                 "loai_tru": _tach(r["loai_tru"]), "luon_cloud": r["luon_cloud"]}
                for r in self.cac_dong if r["dung"]]

    @property
    def tom_tat(self):
        return {"so_tham_so": len(self.cac_dong),
                "so_dang_dung": sum(r["dung"] for r in self.cac_dong),
                "so_muc_3": sum(r["muc"] == 3 for r in self.cac_dong),
                "so_luon_hoi": sum(r["luon_cloud"] for r in self.cac_dong),
                "co_quy_tac": self.co_sheet_quy_tac or bool(self.quy_tac)}


def _tach(s):
    return [x.strip().lower() for x in re.split(r"[;\n]", s) if x.strip()]


def _chu(s):
    return "" if s is None else str(s).strip()


def _tieu_de(s):
    return unicodedata.normalize("NFC", _chu(s)).replace("khóa", "khoá")


def _loi(ma, thong_bao, dong=None, cot=None):
    return VanDeDanhMuc(ma, dong, cot, f"Dòng {dong}: {thong_bao}" if dong else thong_bao)


def _kiem_header(rows, header, loi, sheet):
    head = rows[0] if rows else []
    names = [_tieu_de(v) for v in head]
    for i, ten in enumerate(header):
        if _tieu_de(ten) not in names:
            loi.append(_loi("THIEU_COT", f"{sheet}: thiếu cột '{ten}'", 1, ten))
        elif i >= len(head) or names[i] != _tieu_de(ten):
            loi.append(_loi("SAI_COT", f"{sheet}: cột {i + 1} phải là '{ten}'", 1, ten))
    if any(_chu(v) for v in head[len(header):]):
        loi.append(_loi("THUA_COT", f"{sheet}: chỉ được có {len(header)} cột", 1))


def kiem_tra_danh_muc(cac_dong, *, quy_tac=None, ma_bam_da_co=()):
    """Kiểm danh sách dòng; trả DanhMucThamSo hoặc ném LoiDanhMuc đầy đủ lỗi.

    Bỏ dòng hoàn toàn trống, không bỏ dòng thiếu mã. Boolean chỉ nhận chuỗi
    Có/Không; mức nhận int hoặc chuỗi chữ số 0–3, không ép float/bool.
    """
    return _kiem_danh_muc(cac_dong, quy_tac, ma_bam_da_co)


def _kiem_danh_muc(rows, rules, hashes, so_dong=None, so_dong_qt=None):
    loi, canh_bao, out, seen = [], [], [], {}
    _kiem_header(rows, HEADER, loi, "Danh mục")
    for index, row in enumerate(rows[1:], 2):
        n = so_dong[index - 1] if so_dong else index
        if not any(_chu(v) for v in row):
            continue
        if any(_chu(v) for v in row[10:]):
            loi.append(_loi("THUA_COT", "có dữ liệu ngoài 10 cột danh mục", n))
        values = list(row[:10]) + [""] * max(0, 10 - len(row))
        for c, value in enumerate(values):
            if c != 6 and value is not None and not isinstance(value, str):
                loi.append(_loi("SAI_KIEU_O", "ô phải chứa văn bản", n, HEADER[c]))
        r = dict(zip(KHOA, map(_chu, values)))
        for key, code, text in (("ma", "THIEU_MA", "thiếu mã tham số"),
                                ("nhom", "THIEU_NHOM", "thiếu nhóm"),
                                ("mo_ta", "THIEU_MO_TA", "thiếu mô tả cho AI")):
            if not r[key]:
                loi.append(_loi(code, text, n, HEADER[KHOA.index(key)]))
        ma = r["ma"]
        if ma and not _MA.fullmatch(ma):
            loi.append(_loi("SAI_MA", f"mã '{ma}' không hợp lệ; mã Y- dành cho hỏi thêm", n, HEADER[0]))
        if ma in seen:
            loi.append(_loi("TRUNG_MA", f"mã {ma} trùng dòng {seen[ma]}", n, HEADER[0]))
        elif ma:
            seen[ma] = n
        if len(r["mo_ta"]) > 1000:
            loi.append(_loi("MO_TA_QUA_DAI", "mô tả cho AI vượt 1.000 ký tự", n, HEADER[2]))
        for key in ("tk", "bk", "bat_buoc", "loai_tru"):
            for word in _tach(r[key]):
                if len(word) > 60:
                    loi.append(_loi("TU_KHOA_QUA_DAI", "mỗi từ khoá chỉ được tối đa 60 ký tự", n, HEADER[KHOA.index(key)]))
                if "@" in word and (key != "tk" or word != "@mo_dau"):
                    loi.append(_loi("SAI_TU_KHOA", f"từ khoá '{word}' không hợp lệ", n, HEADER[KHOA.index(key)]))
        for key in ("dung", "luon_cloud"):
            if r[key] not in ("Có", "Không"):
                loi.append(_loi("SAI_CO_KHONG", "ghi Có hoặc Không", n, HEADER[KHOA.index(key)]))
            r[key] = r[key] == "Có"
        muc = values[6]
        if not (type(muc) is int and 0 <= muc <= 3 or
                isinstance(muc, str) and muc.strip() in ("0", "1", "2", "3")):
            loi.append(_loi("SAI_MUC", "mức quan trọng phải là số nguyên 0–3, không để trống", n, HEADER[6]))
        else:
            r["muc"] = int(muc)
        if not any(_tach(r[k]) for k in ("tk", "bk", "bat_buoc", "loai_tru")):
            canh_bao.append(_loi("KHONG_TU_KHOA", "không có từ khoá, tìm bằng mục lục có thể chậm hơn", n))
        out.append(r)
    active = sum(r["dung"] for r in out)
    if not active:
        loi.append(_loi("KHONG_CO_THAM_SO_DUNG", "Danh mục không có tham số nào đang dùng"))
    if active > 60:
        canh_bao.append(_loi("NHIEU_THAM_SO", "Danh mục có hơn 60 tham số đang dùng"))
    parsed_rules = _kiem_quy_tac(rules, seen, loi, so_dong_qt)
    if loi:
        raise LoiDanhMuc(loi)
    raw = json.dumps(out, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    bam = hashlib.sha256(raw).hexdigest()
    if bam in hashes:
        canh_bao.append(_loi("TRUNG_NOI_DUNG", "Nội dung danh mục trùng phiên bản đã có"))
    return DanhMucThamSo(out, parsed_rules, bam, canh_bao, co_sheet_quy_tac=rules is not None)


def _kiem_quy_tac(rows, seen, loi, so_dong):
    if rows is None:
        return []
    _kiem_header(rows, QUY_TAC_HEADER, loi, "Quy tắc")
    out = []
    for i, row in enumerate(rows[1:], 2):
        n = so_dong[i - 1] if so_dong else i
        if not any(_chu(v) for v in row):
            continue
        vals = [_chu(v) for v in row[:4]] + [""] * max(0, 4 - len(row))
        kieu, nguon, dk, dich = vals
        codes = [s.strip() for s in nguon.split(";") if s.strip()]
        hop_le = bool(codes) and len(codes) == len(set(codes))
        if kieu == "Tổng tỷ lệ":
            hop_le &= dk in ("=", "<=") and dich == "100"
        elif kieu in ("Ngày không sau", "Có thì phải có"):
            hop_le &= len(codes) == 1 and bool(dich) and dk == ("<=" if kieu == "Ngày không sau" else "")
        else:
            hop_le = False
        if not hop_le or any(_chu(v) for v in row[4:]):
            loi.append(_loi("SAI_QUY_TAC", "quy tắc không đúng kiểu hoặc điều kiện cho phép", n))
        for ma in codes + ([dich] if kieu in ("Ngày không sau", "Có thì phải có") and dich else []):
            if ma not in seen:
                loi.append(_loi("QUY_TAC_MA_KHONG_CO", f"quy tắc: mã {ma} không có trong danh mục", n))
        out.append({"kieu": kieu, "ma_tham_so": codes, "dieu_kien": dk, "doi_chieu": dich})
    return out


def _xml(z, ten):
    raw = z.read(ten)
    if b"<!DOCTYPE" in raw.upper() or b"<!ENTITY" in raw.upper():
        raise ValueError("XML có khai báo thực thể")
    return ET.fromstring(raw)


def _doc_sheet(z, ten, index, loi):
    """Lấy giá trị bằng bản nguồn; metadata bổ sung lỗi và số dòng vật lý."""
    sheet = _xml(z, ten)
    ns = _NS
    numbers = []
    for row in sheet.findall(f"{ns}sheetData/{ns}row"):
        if not row.findall(f"{ns}c"):
            continue
        n = int(row.attrib["r"])
        if not 1 <= n <= 1048576 or numbers and n <= numbers[-1]:
            raise ValueError("Thứ tự dòng không hợp lệ")
        numbers.append(n)
        refs = set()
        for c in row.findall(f"{ns}c"):
            ref = c.get("r", "")
            match = _O.fullmatch(ref)
            if not match or int(match[2]) != n or ref in refs:
                raise ValueError("Địa chỉ ô không hợp lệ")
            refs.add(ref)
            col = match[1]
            col_index = 0
            for ch in col:
                col_index = col_index * 26 + ord(ch) - 64
            if col_index > 16384:
                raise ValueError("Địa chỉ cột không hợp lệ")
            if c.find(f"{ns}f") is not None:
                loi.append(_loi("O_CONG_THUC", "ô công thức — ghi giá trị", n, col))
            if c.get("t") in ("b", "e", "d"):
                loi.append(_loi("SAI_KIEU_O", "ô phải chứa văn bản hoặc số phù hợp với cột", n, col))
    for merge in sheet.findall(f"{ns}mergeCells/{ns}mergeCell"):
        start, end = merge.attrib["ref"].split(":")
        a, b = _O.fullmatch(start), _O.fullmatch(end)
        if not a or not b:
            raise ValueError("Vùng gộp không hợp lệ")
        loi.append(_loi("O_GOP", "ô gộp — tách ô và ghi giá trị từng dòng", int(a[2]), a[1]))
    rows = xlsx_mini.read_xlsx(z.fp, sheet_index=index)
    if numbers and numbers[0] != 1:
        rows.insert(0, [])
        numbers.insert(0, 1)
    return rows, numbers


def doc_danh_muc(du_lieu, ten_tep="danh_muc.xlsx", *, ma_bam_da_co=()):
    """Đọc bytes upload .xlsx ≤ 2 MiB; từ chối macro, công thức, ô gộp.

    Không ghi ra đĩa, không mở đường dẫn hay dịch vụ. Ưu tiên Danh_muc,
    nếu không có dùng sheet đầu; giữ đúng số dòng khi Excel bỏ dòng trống.
    """
    if not isinstance(ten_tep, str) or not ten_tep.lower().endswith(".xlsx") or not isinstance(du_lieu, bytes):
        raise LoiDanhMuc([_loi("SAI_TEP", "Tệp không phải Excel .xlsx")])
    if len(du_lieu) > GIOI_HAN_TEP:
        raise LoiDanhMuc([_loi("TEP_QUA_LON", "Tệp Excel vượt quá 2 MiB")])
    loi = []
    try:
        with zipfile.ZipFile(io.BytesIO(du_lieu)) as z:
            infos = z.infolist()
            if sum(i.file_size for i in infos) > GIOI_HAN_GIAI_NEN:
                raise LoiDanhMuc([_loi("TEP_QUA_LON", "Nội dung giải nén của tệp Excel quá lớn")])
            if len({i.filename for i in infos}) != len(infos):
                raise ValueError("Trùng thành phần ZIP")
            ct = z.read("[Content_Types].xml").lower()
            if b"macroenabled" in ct or b"vbaproject" in ct or any("vbaproject" in i.filename.lower() for i in infos):
                raise LoiDanhMuc([_loi("TEP_CO_MACRO", "Tệp Excel có macro, cần lưu thành .xlsx không macro")])
            wb = _xml(z, "xl/workbook.xml")
            sheets = list(wb.find(f"{_NS}sheets"))
            names = [s.attrib["name"] for s in sheets]
            if not names or len(names) != len(set(names)):
                raise ValueError("Thiếu hoặc trùng sheet")
            rels = _xml(z, "xl/_rels/workbook.xml.rels")
            targets = {}
            for r in rels:
                if r.get("TargetMode") == "External":
                    raise ValueError("Liên kết ngoài không hợp lệ")
                target = r.attrib["Target"].lstrip("/")
                target = target if target.startswith("xl/") else "xl/" + target
                if posixpath.normpath(target) != target or "\\" in target:
                    raise ValueError("Đường dẫn sheet không hợp lệ")
                targets[r.attrib["Id"]] = target
            idx = names.index("Danh_muc") if "Danh_muc" in names else 0
            rows, nums = _doc_sheet(z, targets[sheets[idx].attrib[f"{_REL}id"]], idx, loi)
            rules, rule_nums = None, None
            if "Quy_tac" in names:
                qi = names.index("Quy_tac")
                rules, rule_nums = _doc_sheet(z, targets[sheets[qi].attrib[f"{_REL}id"]], qi, loi)
        try:
            result = _kiem_danh_muc(rows, rules, ma_bam_da_co, nums, rule_nums)
        except LoiDanhMuc as exc:
            raise LoiDanhMuc(loi + list(exc.loi)) from None
        if loi:
            raise LoiDanhMuc(loi)
    except LoiDanhMuc:
        raise
    except (ValueError, KeyError, IndexError, TypeError, AttributeError, ET.ParseError,
            zipfile.BadZipFile, RuntimeError, OSError, NotImplementedError, zlib.error) as exc:
        raise LoiDanhMuc([_loi("SAI_TEP", "Tệp không phải Excel .xlsx hợp lệ")]) from exc
    result.ma_bam = hashlib.sha256(du_lieu).hexdigest()
    return result


def khac_biet(truoc: DanhMucThamSo, sau: DanhMucThamSo):
    """So theo mã; thay Dùng tách riêng. Đổi thứ tự xét các mã chung."""
    a = {r["ma"]: r for r in truoc.cac_dong}
    b = {r["ma"]: r for r in sau.cac_dong}
    chung = a.keys() & b.keys()
    doi, bat_tat = [], []
    for ma in b:
        if ma not in chung:
            continue
        for key, ten in zip(KHOA[1:], HEADER[1:]):
            if a[ma][key] != b[ma][key]:
                item = {"ma": ma, "cot": ten, "truoc": a[ma][key], "sau": b[ma][key]}
                (bat_tat if key == "dung" else doi).append(item)
    return {"them": [ma for ma in b if ma not in a], "bo": [ma for ma in a if ma not in b],
            "doi": doi, "bat_tat": bat_tat,
            "doi_thu_tu": [ma for ma in a if ma in chung] != [ma for ma in b if ma in chung],
            "doi_quy_tac": truoc.quy_tac != sau.quy_tac}


def tao_mau_excel(*, co_quy_tac=False):
    """Sinh bytes Excel trống, cùng bộ ghi SDK; không ghi đường dẫn ra đĩa."""
    sheets = {"Danh_muc": {"rows": [HEADER], "widths": DO_RONG},
              "Huong_dan": {"rows": [["Nội dung", "Hướng dẫn"],
                  ["Mã", "Hai hoặc ba chữ cái in hoa, dấu -, hai hoặc ba chữ số; không dùng Y-"],
                  ["Mô tả cho AI", "Bắt buộc, tối đa 1.000 ký tự; Nhóm không được trống"],
                  ["Từ khoá", "Phân cách bằng dấu ;, mỗi từ tối đa 60 ký tự"],
                  ["Mở đầu", "Chỉ cột Từ khoá tiêu đề được dùng @mo_dau"],
                  ["Dùng và Luôn hỏi Claude", "Chỉ ghi Có hoặc Không; ít nhất một dòng Dùng = Có"],
                  ["Mức quan trọng", "Số nguyên từ 0 đến 3, không để trống"],
                  ["Ô dữ liệu", "Ghi giá trị, không dùng công thức hoặc gộp ô"],
                  ["Tổng tỷ lệ", "Mã tham số cách nhau bằng ;, điều kiện = hoặc <=, đối chiếu 100"],
                  ["Ngày không sau", "Một mã tham số, điều kiện <=, đối chiếu một mã khác"],
                  ["Có thì phải có", "Một mã tham số, điều kiện để trống, đối chiếu một mã khác"]],
                  "widths": [28, 95]}}
    if co_quy_tac:
        sheets["Quy_tac"] = {"rows": [QUY_TAC_HEADER], "widths": [24, 35, 16, 35]}
    output = io.BytesIO()
    xlsx_mini.write_xlsx(output, sheets)
    return output.getvalue()
