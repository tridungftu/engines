"""G2-15: nâng bus XS-1/M0052 sang Core, giữ dedupe và caller-owned tx.

Phát cùng transaction nghiệp vụ. Nhận giữ khóa inbox tới hết transaction;
ghi kết quả và ACK trên chính kết nối đó. Exception phải thoát transaction.
``xu_ly`` ghép nhận/handler/ACK theo quy tắc này; không tự mở/commit/rollback.
Giao ít nhất một lần, không bảo đảm exactly-once cho tác động ngoài PostgreSQL.
Contract chỉ tham chiếu UUID; schema chưa hỗ trợ bị từ chối ở SQL.
Nhận/ACK cần ủy nhiệm riêng ``<MODULE>:SU_KIEN:SUA``; SQL cố định và kiểm
hành động này, kể cả caller gọi thẳng SQL hoặc khai quyền ghi nghiệp vụ khác.
"""

from collections.abc import Mapping
import json
import re
from uuid import UUID

from .tai_lieu import _ngu_canh
from .tiep_nhan import _tx


class LoiSuKien(RuntimeError):
    def __init__(self, ma):
        self.ma = ma
        self.http_status = 409 if ma in {'BUS_DEDUPE_XUNG_DOT', 'BUS_CHUA_NHAN'} else (
            403 if ma in {'BUS_PHIEN', 'BUS_DANG_KY', 'BUS_CONG_TAC', 'BUS_HANH_DONG'} else 400)
        super().__init__('Thao tác sự kiện thất bại (' + ma + ')')


_LOI = {'BUS_PHIEN', 'BUS_DANG_KY', 'BUS_CONG_TAC', 'BUS_HANH_DONG', 'BUS_CONTRACT', 'BUS_PAYLOAD',
        'BUS_DAU_VAO', 'BUS_DEDUPE_XUNG_DOT', 'BUS_CHUA_NHAN', 'BUS_CAN_READ_COMMITTED'}


def _goi(conn, cau, ts):
    ma = 'BUS_THAT_BAI'
    try:
        row = conn.execute(cau, ts).fetchone()
        return row['r'] if isinstance(row, Mapping) else row[0]
    except Exception as exc:
        chinh = getattr(getattr(exc, 'diag', None), 'message_primary', None)
        if isinstance(chinh, str) and chinh in _LOI:
            ma = chinh
    ts = None
    raise LoiSuKien(ma)


def _ctx(conn, ctx):
    _tx(conn)
    return _ngu_canh(**ctx)


def _loai(loai):
    if not isinstance(loai, str) or not re.fullmatch('[a-z][a-z0-9_.]{0,95}', loai):
        raise ValueError('Loại sự kiện không hợp lệ')
    return loai


def phat(conn, loai, phien_ban, tham_chieu, khoa, **ctx):
    """Trả UUID, cùng khóa/cùng nội dung trả lại UUID cũ; không commit."""
    ts = _ctx(conn, ctx)
    _loai(loai)
    if (type(phien_ban) is not int or not 1 <= phien_ban <= 2**31-1
            or not isinstance(khoa, str) or not 1 <= len(khoa) <= 200 or khoa != khoa.strip()
            or not isinstance(tham_chieu, dict) or not tham_chieu
            or ts[3].split(':')[2] not in {'LAP', 'SUA', 'DUYET'}):
        raise ValueError('Thông tin sự kiện không hợp lệ')
    # SQL kiểm lại toàn bộ, kể cả trường UUID không được contract khai báo.
    for k, v in tham_chieu.items():
        if isinstance(k, str) and re.fullmatch('[a-z][a-z0-9_]*_id', k) and isinstance(v, str):
            UUID(v)
        elif isinstance(k, str) and re.fullmatch('[a-z][a-z0-9_]*_ids', k) and isinstance(v, list):
            for item in v:
                if not isinstance(item, str):
                    raise ValueError('Tham chiếu phải là UUID')
                UUID(item)
        else:
            raise ValueError('Payload chỉ chứa tham chiếu UUID')
    return _goi(conn, 'SELECT loi.su_kien_phat(%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s) AS r',
                (*ts[:4], loai, phien_ban, khoa, json.dumps(tham_chieu, allow_nan=False), *ts[4:]))


def nhan(conn, loai=None, gioi_han=100, **ctx):
    """Trả list dict, giữ khóa inbox cho đến khi caller commit/rollback."""
    ts = _ctx(conn, ctx)
    if loai is not None:
        _loai(loai)
    if type(gioi_han) is not int or not 1 <= gioi_han <= 1000:
        raise ValueError('Giới hạn phải từ 1 tới 1000')
    return _goi(conn, 'SELECT loi.su_kien_nhan(%s,%s,%s,%s,%s,%s,%s,%s) AS r',
                (*ts[:4], loai, gioi_han, *ts[4:]))


def ack(conn, su_kien_id, **ctx):
    """ACK đầu True, lặp False; chưa nhận bị từ chối. Cùng tx xử lý."""
    ts = _ctx(conn, ctx)
    return _goi(conn, 'SELECT loi.su_kien_ack(%s,%s,%s,%s,%s,%s,%s) AS r',
                (*ts[:4], UUID(str(su_kien_id)), *ts[4:]))


def xu_ly(conn, handler, loai=None, gioi_han=100, **ctx):
    """Handler nhận (conn, sự kiện); lỗi phải thoát transaction của caller."""
    so = 0
    for sk in nhan(conn, loai, gioi_han, **ctx):
        handler(conn, sk)
        ack(conn, sk['id'], **ctx)
        so += 1
    return so


# ---------------------------------------------------------------------------
# Thông báo engine/quy trình (HOP-DONG-CONG.md c.4): một chuẩn phong bì cho
# engine và module. Chỉ mang THAM CHIẾU (mã việc, mã kết quả, mã tệp, bảng
# ghép trường → cột), không mang nội dung tài liệu hay bí mật.
# - Core → engine: viec.co_moi, viec.huy, engine.dung. Engine cục bộ không cần
#   webhook: kéo việc theo chu kỳ + cờ `huy` ở gia-han/tien-do; Core dùng bộ
#   thông báo trong tiến trình để đánh thức lượt chờ việc (ApiEngine.danh_thuc).
# - Core → module / người theo dõi: viec.da_nhan, viec.tien_do, viec.buoc_xong,
#   quy_trinh.xong, quy_trinh.loi, viec.huy — module nhận qua bus bền ở trên
#   (`phat_len_bus`), cần contract sự kiện đã đăng ký.
# Nợ (để sau đợt 1): gửi webhook HTTP ra ngoài (HMAC `X-KTT-Chu-Ky`) và sổ gửi lại.

from datetime import datetime, timedelta, timezone
import logging
import threading
from uuid import uuid4

DANH_MUC_THONG_BAO = {
    'viec.co_moi': 'core_den_engine', 'viec.huy': 'chung', 'engine.dung': 'core_den_engine',
    'viec.da_nhan': 'core_den_module', 'viec.tien_do': 'core_den_module',
    'viec.buoc_xong': 'core_den_module', 'quy_trinh.xong': 'core_den_module',
    'quy_trinh.loi': 'core_den_module',
}
_GIO_VN = timezone(timedelta(hours=7))
_MA_THAM_CHIEU = re.compile(r'[A-Za-z0-9_.:-]{1,100}')
_LOG = logging.getLogger(__name__)


def tao_phong_bi(su_kien, *, ma_engine=None, ma_module=None, viec_id=None, buoc=None,
                 tham_chieu=None, luc=None, id=None):
    """Phong bì thông báo c.4: {su_kien, phien_ban: 1, id, luc, nguon: "core", ...}.

    tham_chieu chỉ nhận khóa `<ten>_id` (mã ngắn) và `bang_ghep` ({trường: cột}).
    """
    if su_kien not in DANH_MUC_THONG_BAO:
        raise ValueError('Sự kiện không có trong danh mục thông báo')
    pb = {'su_kien': su_kien, 'phien_ban': 1, 'id': str(id or uuid4()),
          'luc': (luc or datetime.now(_GIO_VN)).isoformat(timespec='seconds'), 'nguon': 'core'}
    if ma_engine is not None:
        if not isinstance(ma_engine, str) or not re.fullmatch(r'e_[a-z0-9_]{2,29}', ma_engine):
            raise ValueError('Mã engine không hợp lệ')
        pb['ma_engine'] = ma_engine
    if ma_module is not None:
        if not isinstance(ma_module, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', ma_module):
            raise ValueError('Mã module không hợp lệ')
        pb['ma_module'] = ma_module
    if viec_id is not None:
        if not isinstance(viec_id, str) or not _MA_THAM_CHIEU.fullmatch(viec_id):
            raise ValueError('Mã việc không hợp lệ')
        pb['viec_id'] = viec_id
    if buoc is not None:
        if type(buoc) is not int or not 1 <= buoc <= 1000:
            raise ValueError('Số bước không hợp lệ')
        pb['buoc'] = buoc
    tc = {}
    for k, v in (tham_chieu or {}).items():
        if k == 'bang_ghep' and isinstance(v, dict) and len(v) <= 200 and all(
                isinstance(a, str) and isinstance(b, str) and re.fullmatch(r'[a-z][a-z0-9_]{0,62}', a)
                and re.fullmatch(r'[a-z][a-z0-9_]{0,62}', b) for a, b in v.items()):
            tc[k] = dict(v)
        elif (isinstance(k, str) and re.fullmatch(r'[a-z][a-z0-9_]{0,40}_id', k)
              and isinstance(v, str) and _MA_THAM_CHIEU.fullmatch(v)):
            tc[k] = v
        else:
            raise ValueError('Thông báo chỉ mang tham chiếu (mã), không mang nội dung')
    pb['tham_chieu'] = tc
    return pb


class BoThongBao:
    """Bộ phát thông báo trong tiến trình Core (không bền): đánh thức lượt chờ
    việc, nối bộ điều phối. Người nhận lỗi thì bị bỏ qua, không làm hỏng bên phát."""

    def __init__(self):
        self._lock = threading.Lock()
        self._nguoi_nhan = []

    def dang_ky(self, ham, su_kien=None):
        """ham(phong_bi); su_kien None = mọi loại. Trả hàm hủy đăng ký."""
        if su_kien is not None and su_kien not in DANH_MUC_THONG_BAO:
            raise ValueError('Sự kiện không có trong danh mục thông báo')
        muc = (su_kien, ham)
        with self._lock:
            self._nguoi_nhan.append(muc)

        def huy():
            with self._lock:
                if muc in self._nguoi_nhan:
                    self._nguoi_nhan.remove(muc)
        return huy

    def phat(self, phong_bi):
        with self._lock:
            ds = [h for loai, h in self._nguoi_nhan if loai in (None, phong_bi['su_kien'])]
        so = 0
        for ham in ds:
            try:
                ham(dict(phong_bi))
                so += 1
            except Exception:
                _LOG.warning('Người nhận thông báo %s gặp lỗi; bỏ qua.', phong_bi['su_kien'])
        return so

    def phat_nhanh(self, su_kien, **kw):
        """Dựng phong bì rồi phát (ApiEngine dùng làm `thong_bao`)."""
        return self.phat(tao_phong_bi(su_kien, **kw))


def phat_len_bus(conn, phong_bi, **ctx):
    """Đưa thông báo lên bus bền (module nhận qua inbox) trong tx của caller.
    Bus chỉ nhận tham chiếu UUID nên chỉ chuyển các khóa `*_id` dạng UUID; khóa
    chống trùng = id phong bì. Cần contract sự kiện `<su_kien>` bản 1 đã đăng ký."""
    tc = {}
    for k, v in {**phong_bi.get('tham_chieu', {}), 'viec_id': phong_bi.get('viec_id')}.items():
        if isinstance(v, str) and k.endswith('_id'):
            try:
                tc[k] = str(UUID(v))
            except ValueError:
                continue
    if not tc:
        raise ValueError('Thông báo không có tham chiếu UUID để đưa lên bus')
    return phat(conn, phong_bi['su_kien'], 1, tc, phong_bi['id'], **ctx)
