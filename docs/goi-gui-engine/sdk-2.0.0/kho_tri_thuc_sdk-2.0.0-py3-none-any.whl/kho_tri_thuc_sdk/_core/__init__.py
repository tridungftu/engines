"""Client Core cua SDK."""
