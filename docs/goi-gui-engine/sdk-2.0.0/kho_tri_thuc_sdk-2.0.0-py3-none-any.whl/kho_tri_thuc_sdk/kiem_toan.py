"""Kiểm toán module: ghi trên tx module, tra cứu bằng kênh Core.

Bootstrap cấp danh mục {hành động: [loại đối tượng]} và resolver binding
kênh đã ghim. Không lấy actor, trace, thời điểm từ metadata của caller.
"""

from dataclasses import dataclass, field
from datetime import datetime, timezone
import math
import re
import time
from uuid import UUID

from .dich_vu import LoiDichVu, _Audit, _DichVu, _ctx
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


KET_LUAN = frozenset({'DAT', 'KHONG_DAT', 'TU_CHOI', 'LOI', 'CHO'})
TRUONG_LOC = frozenset({'hanh_dong', 'loai_doi_tuong', 'doi_tuong_id',
                        'tu_luc', 'den_luc', 'kich_thuoc_trang'})
_CURSOR = r'[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}'
_TEN = r'[A-Za-z][A-Za-z0-9_.:-]{0,95}'
_SO_DO = frozenset({'chay_viec_ms', 'ranh_ms', 'ram_dinh_byte',
                    'ram_trung_binh_byte', 'cpu_ms'})


def _sai():
    return LoiDichVu('SDK_KIEM_TOAN_DAU_VAO', 422)


def _thoi_diem(value):
    if not isinstance(value, str) or not re.fullmatch(
            r'\d{4}-\d\d-\d\d[Tt]\d\d:\d\d:\d\d(?:\.\d{1,6})?(?:[Zz]|[+-]\d\d:\d\d)', value):
        raise _sai()
    try:
        dt = datetime.fromisoformat(value.upper().replace('Z', '+00:00'))
        return dt.astimezone(timezone.utc)
    except ValueError:
        raise _sai() from None


def kiem_loc(loc, con_tro=None):
    """Schema kín dùng lại ở SDK và adapter Core; không nhận phạm vi/actor."""
    if type(loc) is not dict or not loc.keys() <= TRUONG_LOC:
        raise _sai()
    data = dict(loc)
    n = data.setdefault('kich_thuoc_trang', 25)
    if type(n) is not int or not 1 <= n <= 100:
        raise _sai()
    for key in ('hanh_dong', 'loai_doi_tuong'):
        if key in data and (not isinstance(data[key], str)
                or not re.fullmatch(r'[A-Za-z0-9_.:-]{1,128}', data[key])):
            raise _sai()
    if 'doi_tuong_id' in data:
        try:
            data['doi_tuong_id'] = str(UUID(data['doi_tuong_id']))
        except (ValueError, TypeError, AttributeError):
            raise _sai() from None
    tu = _thoi_diem(data['tu_luc']) if 'tu_luc' in data else None
    den = _thoi_diem(data['den_luc']) if 'den_luc' in data else None
    if tu is not None and den is not None and tu >= den:
        raise _sai()
    if con_tro is not None and (not isinstance(con_tro, str)
            or len(con_tro) > 4096 or not re.fullmatch(_CURSOR, con_tro)):
        raise _sai()
    return data


def kiem_so_do(so_do):
    """Danh mục đóng; không có module/instance/thế hệ/actor trong payload."""
    if (type(so_do) is not dict or not so_do.keys() <= _SO_DO | {'cua_so_tu', 'cua_so_den'}
            or not {'cua_so_tu', 'cua_so_den'} <= so_do.keys()
            or not _SO_DO.intersection(so_do)):
        raise _sai()
    data = dict(so_do)
    for name in _SO_DO.intersection(data):
        v = data[name]
        if name.startswith('ram_'):
            if type(v) is not int or not 0 <= v < 2**63:
                raise _sai()
        elif type(v) not in (int, float) or not 0 <= v < 1e18 or not math.isfinite(v):
            raise _sai()
    if ('ram_dinh_byte' in data and 'ram_trung_binh_byte' in data
            and data['ram_trung_binh_byte'] > data['ram_dinh_byte']):
        raise _sai()
    tu, den = (_thoi_diem(data[name]) for name in ('cua_so_tu', 'cua_so_den'))
    if not 0 <= (den-tu).total_seconds() <= 86400:
        raise _sai()
    data.update(cua_so_tu=tu.isoformat(), cua_so_den=den.isoformat())
    return data


@dataclass(frozen=True, slots=True, repr=False, init=False)
class NguCanhTienTrinh:
    """Runtime dựng từ Bootstrap.nhan() sau bao_san_sang(), không cần phiên user.

    Resolver kênh do runtime cấp vẫn giữ credential riêng; context chỉ ghim
    danh tính tiến trình. Core/proof và cửa SQL tiếp tục kiểm lease hiện hành.
    """

    module: str
    instance_id: UUID
    the_he: int
    nonce_khoi_dong: str = field(repr=False)
    _bootstrap: object = field(repr=False, compare=False)

    def __init__(self, bootstrap):
        from .bootstrap import Bootstrap
        try:
            if not isinstance(bootstrap, Bootstrap) or not bootstrap._duoc_accept:
                raise ValueError()
            cfg, reader = bootstrap._cfg, bootstrap.bo_doc
            if (cfg['module'] != reader.module
                    or UUID(cfg['instance_id']) != reader.instance_id
                    or cfg['nonce_khoi_dong'] != reader._nonce_khoi_dong
                    or type(cfg['the_he']) is not int or cfg['the_he'] < 1):
                raise ValueError()
            for name, value in (('module', reader.module), ('instance_id', reader.instance_id),
                                ('the_he', cfg['the_he']),
                                ('nonce_khoi_dong', cfg['nonce_khoi_dong']),
                                ('_bootstrap', bootstrap)):
                object.__setattr__(self, name, value)
            return
        except Exception as exc:
            _xoa_loi(exc)
        raise LoiDichVu('SDK_NGU_CANH', 401) from None

    def _kiem(self):
        b = self._bootstrap
        if (not b._duoc_accept or any(b._cfg.get(name) != value for name, value in (
                ('module', self.module), ('instance_id', str(self.instance_id)),
                ('the_he', self.the_he), ('nonce_khoi_dong', self.nonce_khoi_dong)))):
            raise LoiDichVu('SDK_NGU_CANH', 401)

    def __repr__(self):
        return 'NguCanhTienTrinh(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize ngữ cảnh tiến trình')


class KiemToan(_DichVu):
    __slots__ = ('__cu', '__kenh', '__binding', '__danh_muc')

    def __init__(self, kenh_core=None, *, khai_bao=None, danh_muc=None,
                 ngu_canh_kenh=None):
        if ngu_canh_kenh is not None and not callable(ngu_canh_kenh):
            raise TypeError('Cần resolver binding do bootstrap cấp')
        if kenh_core is not None and not callable(getattr(kenh_core, 'goi', None)):
            raise TypeError('Cần kênh Core do bootstrap cấp')
        if danh_muc is not None and (type(danh_muc) is not dict or any(
                not isinstance(hd, str) or not re.fullmatch(_TEN, hd)
                or type(ds) not in (list, tuple, frozenset)
                or any(not isinstance(t, str) or not re.fullmatch(
                    r'[A-Za-z][A-Za-z0-9_.:-]{0,95}', t) for t in ds)
                for hd, ds in danh_muc.items())):
            raise _sai()
        self.__cu, self.__kenh, self.__binding = _Audit(khai_bao), kenh_core, ngu_canh_kenh
        self.__danh_muc = {hd: frozenset(ds) for hd, ds in (danh_muc or {}).items()}

    def ghi(self, tx, hanh_dong, doi_tuong, ket_luan) -> str:
        ctx = _ctx(tx)
        if (hanh_dong != ctx.hanh_dong or type(doi_tuong) is not dict
                or doi_tuong.keys() != {'bang', 'id'}
                or not isinstance(doi_tuong['bang'], str)
                or doi_tuong['bang'] not in self.__danh_muc.get(hanh_dong, ())
                or not isinstance(ket_luan, str) or ket_luan not in KET_LUAN):
            raise _sai()
        try:
            id_ = UUID(str(doi_tuong['id']))
        except (ValueError, TypeError, AttributeError):
            raise _sai() from None
        # Cửa 020 xác minh lại phiên/login, MTQ và tự gắn actor/thời điểm.
        return str(self.__cu.ghi(tx, doi_tuong=doi_tuong['bang'],
                               doi_tuong_id=id_, ket_luan=ket_luan))

    def _ctx(self, ctx, *, tien_trinh=False):
        if tien_trinh:
            if not isinstance(ctx, NguCanhTienTrinh):
                raise LoiDichVu('SDK_NGU_CANH', 401)
            ctx._kiem()
            return
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den
                or ctx.nguoi_dung_id is None or ctx.phap_nhan_id is None):
            raise LoiDichVu('SDK_NGU_CANH', 401)

    def _goi(self, ctx, operation, data):
        if self.__kenh is None or self.__binding is None:
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        ma, status = 'LOI_NOI_BO', 500
        try:
            options = self.__binding(ctx, operation)
            if (type(options) is not dict or not options.keys() <= {
                    'ngu_canh', 'parent', 'thu_tu_con', 'khoa'} or 'ngu_canh' not in options):
                raise LoiDichVu('SDK_NGU_CANH', 401)
            binding = options['ngu_canh']
            if (type(binding) is not dict or binding.get('module') != ctx.module
                    or binding.get('instance_id') != str(ctx.instance_id)):
                raise LoiDichVu('SDK_NGU_CANH', 401)
            if isinstance(ctx, NguCanhTienTrinh) and (
                    binding.get('the_he') != ctx.the_he
                    or binding.get('nonce_khoi_dong') != ctx.nonce_khoi_dong
                    or binding.get('pham_vi') != 'tien_trinh'
                    or binding.get('nguoi_dung_id') is not None
                    or binding.get('phap_nhan_id') is not None
                    or options.get('parent') is not None):
                raise LoiDichVu('SDK_NGU_CANH', 401)
            return self.__kenh.goi(operation, data, **options)
        except Exception as exc:
            code, http = getattr(exc, 'ma', None), getattr(exc, 'http_status', None)
            if code in {'SDK_NGU_CANH', 'KENH_XAC_THUC_KHONG_HOP_LE', 'KENH_KHONG_DU_QUYEN',
                        'KENH_DU_LIEU_KHONG_HOP_LE', 'YEU_CAU_KHONG_HOP_LE',
                        'PHAN_HOI_SAI_CONTRACT', 'KHONG_TIM_THAY', 'XUNG_DOT',
                        'CHUA_SAN_SANG', 'PHAN_HOI_QUA_HAN', 'VUOT_HAN_MUC'}:
                ma = code
                status = http if type(http) is int and 400 <= http <= 599 else 500
            _xoa_loi(exc)
        finally:
            options = binding = data = None
        raise LoiDichVu(ma, status) from None

    def ghi_so_do(self, ctx_tien_trinh, so_do):
        """Runtime dùng NguCanhTienTrinh(bootstrap); kênh gắn credential instance."""
        self._ctx(ctx_tien_trinh, tien_trinh=True)
        response = self._goi(ctx_tien_trinh, 'kiem_toan.ghi_so_do', kiem_so_do(so_do))
        try:
            data = response.json()
            if (type(data) is not dict or data.keys() != {'id', 'request_id'}
                    or str(UUID(data['id'])) != data['id']
                    or str(UUID(data['request_id'])) != data['request_id']
                    or data['request_id'] != response.header['request_id']):
                raise ValueError()
            return data
        except Exception as exc:
            _xoa_loi(exc)
        raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502) from None

    def tra_cuu(self, ctx, loc, con_tro=None):
        from .du_lieu_rieng import Trang
        self._ctx(ctx)
        data = kiem_loc(loc, con_tro)
        response = self._goi(ctx, 'kiem_toan.tra_cuu', dict(loc=data, con_tro=con_tro))
        try:
            result = response.json()
            if (type(result) is not dict or result.keys() != {
                    'danh_sach', 'con_tiep', 'con_tro_tiep'}
                    or type(result['danh_sach']) is not list
                    or len(result['danh_sach']) > data['kich_thuoc_trang']
                    or type(result['con_tiep']) is not bool
                    or (result['con_tiep'] and (not result['danh_sach']
                        or not isinstance(result['con_tro_tiep'], str)
                        or len(result['con_tro_tiep']) > 4096
                        or not re.fullmatch(_CURSOR, result['con_tro_tiep'])))
                    or (not result['con_tiep'] and result['con_tro_tiep'] is not None)):
                raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
            for row in result['danh_sach']:
                if (type(row) is not dict or row.keys() != {'id', 'luc', 'phap_nhan_id',
                        'ma_module', 'nguoi_thuc_hien_hien_thi', 'hanh_dong',
                        'loai_doi_tuong', 'doi_tuong_id', 'ket_luan', 'request_id'}
                        or row['ma_module'] != ctx.module
                        or row['phap_nhan_id'] != str(ctx.phap_nhan_id)):
                    raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
            return Trang(result['danh_sach'], result['con_tiep'], result['con_tro_tiep'])
        except Exception as exc:
            _xoa_loi(exc)
        finally:
            result = data = None
        raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502) from None


_mac_dinh = KiemToan()
ghi = _mac_dinh.ghi
tra_cuu = _mac_dinh.tra_cuu
ghi_so_do = _mac_dinh.ghi_so_do
