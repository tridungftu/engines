"""Crypto client qua KenhCore; không giữ két, khóa hoặc bộ mã hóa.

Bootstrap cấp tham_chieu(operation, ctx) -> kwargs cho KenhCore.goi, gồm
ngu_canh và (nếu đang xử lý request cha) parent/thu_tu_con ổn định.
Module lưu ban_ghi_id cùng bản mã; không đổi ID dùng làm AAD. CotMaHoa
chỉ định bản ghi khi cập nhật hoặc mã hóa nhiều cột trên cùng một bản ghi.
"""

from dataclasses import dataclass, asdict
from functools import wraps
import re
import time
from uuid import UUID

from .kenh_core import KenhCore
from . import kenh_khung as k
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


def _an_loi(ham):
    @wraps(ham)
    def goi(*args, **kwargs):
        ma, retry = 'LOI_NOI_BO', None
        try:
            return ham(*args, **kwargs)
        except Exception as exc:
            if isinstance(exc, k.LoiKenh):
                ma, retry = exc.ma, exc.retry_after
            _xoa_loi(exc)
        finally:
            args = kwargs = None
        raise k.LoiKenh(ma, retry_after=retry)
    return goi


@dataclass(frozen=True, slots=True, repr=False)
class CotMaHoa:
    ma: str
    doi_tuong_id: UUID

    def __repr__(self):
        return 'CotMaHoa(<an>)'


@dataclass(frozen=True, slots=True, repr=False)
class BanMa:
    cot: str
    module: str
    phap_nhan_id: str
    ban_ghi_id: str
    phien_ban_khoa: int
    du_lieu: str
    hien_thi: str
    chu_ky: str

    def __repr__(self):
        return 'BanMa(<an>)'


@dataclass(frozen=True, slots=True, repr=False)
class DauTraCuu:
    gia_tri: str
    phien_ban: int

    def __repr__(self):
        return 'DauTraCuu(<an>)'


def _cot(cot):
    row_id = None
    if type(cot) is CotMaHoa:
        k._can(type(cot.doi_tuong_id) is UUID)
        row_id, cot = str(cot.doi_tuong_id), cot.ma
    k._can(type(cot) is str and 1 <= len(cot) <= 128)
    return cot, row_id


class MaHoa:
    __slots__ = ('__kenh', '__tham_chieu')

    def __init__(self, kenh_core=None, *, tham_chieu=None):
        if kenh_core is not None and not isinstance(kenh_core, KenhCore):
            raise TypeError('Cần KenhCore do bootstrap cấp')
        if tham_chieu is not None and not callable(tham_chieu):
            raise TypeError('Cần tham chiếu do bootstrap cấp')
        self.__kenh, self.__tham_chieu = kenh_core, tham_chieu

    def __repr__(self):
        return 'MaHoaSDK(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize dịch vụ SDK')

    def _goi(self, ctx, ten, data):
        k._can(isinstance(ctx, NguCanh) and ctx._da_kiem is _DA_KIEM
               and time.time() < ctx.hieu_luc_den, 'KENH_XAC_THUC_KHONG_HOP_LE')
        k._can(self.__kenh is not None and self.__tham_chieu is not None,
               'CHUA_SAN_SANG')
        op = 'ma_hoa.' + ten
        tham_chieu = self.__tham_chieu(op, ctx)
        k._can(type(tham_chieu) is dict
               and {'ngu_canh'} <= tham_chieu.keys()
               and tham_chieu.keys() <= {'ngu_canh', 'parent', 'thu_tu_con'},
               'KENH_KHONG_DU_QUYEN')
        h = tham_chieu['ngu_canh']
        danh_tinh = {
            'module': ctx.module, 'instance_id': str(ctx.instance_id),
            'nguoi_dung_id': str(ctx.nguoi_dung_id),
            'phap_nhan_id': str(ctx.phap_nhan_id),
        }
        k._can(type(h) is dict and all(h.get(ten) == val for ten, val in danh_tinh.items()),
               'KENH_KHONG_DU_QUYEN')
        parent = tham_chieu.get('parent')
        if parent is not None:
            k._can(type(parent) is dict and all(parent.get(ten) == val
                   for ten, val in danh_tinh.items()), 'KENH_KHONG_DU_QUYEN')
        # Mọi crypto K được N2 xếp GHI: chặn tx module mở, dẫn khóa con
        # từ cha hoặc dùng khóa request đã được NhanRequest kiểm.
        response = self.__kenh.goi(op, data, khoa=ctx.khoa, **tham_chieu)
        k._can(response.header.get('stream') is None, 'PHAN_HOI_SAI_CONTRACT')
        return response.json()

    @_an_loi
    def ma_hoa(self, ctx, cot, gia_tri) -> BanMa:
        cot, row_id = _cot(cot)
        k._can(type(gia_tri) is str and len(gia_tri.encode('utf-8')) <= 16384)
        payload = dict(cot=cot, gia_tri=gia_tri)
        if row_id is not None:
            payload['doi_tuong_id'] = row_id
        data = self._goi(ctx, 'ma_hoa', payload)
        k._can(type(data) is dict and data.keys() == BanMa.__dataclass_fields__.keys(),
               'PHAN_HOI_SAI_CONTRACT')
        k._can(data['cot'] == cot and data['module'] == ctx.module
               and data['phap_nhan_id'] == str(ctx.phap_nhan_id)
               and all(type(data[t]) is str for t in ('ban_ghi_id', 'du_lieu',
                   'hien_thi', 'chu_ky'))
               and k._so_nguyen(data['phien_ban_khoa'], 1, 2147483647),
               'PHAN_HOI_SAI_CONTRACT')
        k._can(k._uuid(data['ban_ghi_id']) and 28 <= len(data['du_lieu']) <= 24000
               and len(data['chu_ky']) == 88 and data['hien_thi'].startswith('****'),
               'PHAN_HOI_SAI_CONTRACT')
        k._can(row_id is None or data['ban_ghi_id'] == row_id, 'PHAN_HOI_SAI_CONTRACT')
        return BanMa(**data)

    @_an_loi
    def tra_hmac(self, ctx, cot, gia_tri) -> DauTraCuu:
        cot, _ = _cot(cot)
        k._can(type(gia_tri) is str and len(gia_tri.encode('utf-8')) <= 16384)
        data = self._goi(ctx, 'tra_hmac', dict(cot=cot, gia_tri=gia_tri))
        k._can(type(data) is dict and data.keys() == {'gia_tri', 'phien_ban'}
               and type(data['gia_tri']) is str
               and re.fullmatch('[0-9a-f]{64}', data['gia_tri']) is not None
               and k._so_nguyen(data['phien_ban'], 1, 2147483647),
               'PHAN_HOI_SAI_CONTRACT')
        return DauTraCuu(**data)

    @_an_loi
    def hien_thi_rut_gon(self, ctx, cot, ban_ma) -> str:
        cot, row_id = _cot(cot)
        k._can(type(ban_ma) is BanMa and ban_ma.cot == cot
               and (row_id is None or row_id == ban_ma.ban_ghi_id))
        data = self._goi(ctx, 'hien_thi_rut_gon', dict(cot=cot, ban_ma=asdict(ban_ma)))
        k._can(type(data) is dict and data.keys() == {'gia_tri'}
               and type(data['gia_tri']) is str and data['gia_tri'].startswith('****')
               and len(data['gia_tri']) <= 512,
               'PHAN_HOI_SAI_CONTRACT')
        return data['gia_tri']

    @_an_loi
    def giai_ma(self, ctx, cot, doi_tuong_id, ly_do) -> str:
        cot, row_id = _cot(cot)
        k._can(isinstance(doi_tuong_id, (str, UUID))
               and type(ly_do) is str and bool(ly_do.strip()) and len(ly_do) <= 2000)
        k._can(k._uuid(str(doi_tuong_id)))
        doi_tuong_id = str(UUID(str(doi_tuong_id)))
        k._can(row_id is None or row_id == doi_tuong_id)
        data = self._goi(ctx, 'giai_ma', dict(cot=cot, doi_tuong_id=doi_tuong_id, ly_do=ly_do))
        k._can(type(data) is dict and data.keys() == {'gia_tri'}
               and type(data['gia_tri']) is str, 'PHAN_HOI_SAI_CONTRACT')
        return data['gia_tri']


_mac_dinh = MaHoa()
ma_hoa = _mac_dinh.ma_hoa
tra_hmac = _mac_dinh.tra_hmac
hien_thi_rut_gon = _mac_dinh.hien_thi_rut_gon
giai_ma = _mac_dinh.giai_ma
