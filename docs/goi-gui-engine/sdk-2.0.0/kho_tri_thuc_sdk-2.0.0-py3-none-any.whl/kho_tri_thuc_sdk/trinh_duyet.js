/* SDK trình duyệt Core. Không giữ cookie, CSRF hoặc nháp trong kho trình duyệt. */
(function (root, factory) {
  'use strict';
  const sdk = factory();
  if (typeof module === 'object' && module.exports) module.exports = sdk;
  else root.KttCore = sdk;
})(typeof globalThis === 'object' ? globalThis : this, function () {
  'use strict';
  const ketThuc = new Set(['succeeded', 'failed', 'cancelled', 'interrupted']);
  const dangChay = new Set(['queued', 'running', 'waiting_input', 'cancel_requested']);
  const chuongTheoNut = new WeakMap();
  const mocDaXemChuong = new Map();
  // Một làn đọc cho cả trang, dùng chung giữa Shell và mọi SDK/adapter.
  let luotDocViec = null;
  const sao = value => value === undefined ? undefined : JSON.parse(JSON.stringify(value));
  const loi = (ma, message) => Object.assign(new Error(message), { ma });
  const mimeTep = new Set(['application/octet-stream', 'application/pdf', 'application/zip',
    'application/json', 'text/plain', 'text/csv',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet']);

  function maTaiNguyen(id) {
    if (typeof id !== 'string' || !/^[A-Za-z0-9_-]+$/.test(id)) {
      throw loi('DUONG_DAN_KHONG_HOP_LE', 'Mã tài nguyên Core không hợp lệ.');
    }
    return id;
  }

  function tenTep(disposition) {
    const params = new Map();
    for (const match of (disposition || '').matchAll(/;\s*(filename\*?)\s*=\s*("(?:[^"\\]|\\.)*"|[^;]*)/gi)) {
      const value = match[2].trim();
      params.set(match[1].toLowerCase(), value.startsWith('"')
        ? value.slice(1, -1).replace(/\\(["\\])/g, '$1') : value);
    }
    let name = params.get('filename') || '';
    const extended = params.get('filename*')?.match(/^UTF-8'[^']*'(.*)$/i);
    if (extended) {
      try { name = decodeURIComponent(extended[1]); } catch (_) { /* Dùng filename dự phòng. */ }
    }
    name = name.normalize('NFC').replace(/[\u0000-\u001f\u007f-\u009f\u202a-\u202e\u2066-\u2069]/g, '')
      .replace(/\\/g, '/').split('/').pop().replace(/[<>:"|?*]/g, '_')
      .replace(/^[.\s]+|[.\s]+$/g, '').slice(0, 180).replace(/[.\s]+$/g, '');
    if (!name) return 'tep-tai-ve';
    return /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(name) ? `_${name}` : name;
  }

  function duongDan(value) {
    if (typeof value !== 'string' || !value.startsWith('/api/v1/') ||
        /[\\\s#]/.test(value) || /[\u0000-\u001f\u007f]/.test(value)) {
      throw loi('DUONG_DAN_KHONG_HOP_LE', 'Chỉ được gửi yêu cầu tới Core.');
    }
    // Không cho URL parser chuẩn hóa traversal hoặc encoded separator trước kiểm tra.
    const path = value.split('?')[0];
    if (path.includes('%') || path.includes('//') || path.split('/').some(s => s === '.' || s === '..')) {
      throw loi('DUONG_DAN_KHONG_HOP_LE', 'Đường dẫn yêu cầu không hợp lệ.');
    }
    return value;
  }

  function tre(ms, signal) {
    return new Promise((resolve, reject) => {
      if (signal.aborted) return reject(new DOMException('Đã dừng theo dõi.', 'AbortError'));
      const dung = () => { clearTimeout(timer); reject(new DOMException('Đã dừng theo dõi.', 'AbortError')); };
      const timer = setTimeout(() => { signal.removeEventListener('abort', dung); resolve(); }, ms);
      signal.addEventListener('abort', dung, { once: true });
    });
  }

  function doiSau(value, now = Date.now()) {
    if (value === null || value === undefined || value === '') return 2000;
    if (/^\d+(\.\d+)?$/.test(value)) return Number(value) * 1000;
    const date = Date.parse(value);
    return Number.isFinite(date) ? Math.max(0, date - now) : 2000;
  }

  async function docPhanHoi(response, method, nhiPhan) {
    const contentType = response.headers.get('Content-Type') || '';
    if (nhiPhan && response.ok) {
      const mime = contentType.split(';')[0].trim().toLowerCase();
      if (!mimeTep.has(mime)) {
        throw loi('CONTENT_TYPE_KHONG_HO_TRO', 'Định dạng tệp tải xuống không được hỗ trợ.');
      }
      return { blob: await response.blob(), ten_tep: tenTep(response.headers.get('Content-Disposition')) };
    }
    if (response.ok && (response.status === 204 || method === 'HEAD')) return null;
    const khongHopLe = () => Object.assign(loi('PHAN_HOI_KHONG_HOP_LE',
      'Phản hồi từ Core không hợp lệ. Hãy thử tải lại hoặc kiểm tra phiên đăng nhập.'), {
      status: response.status, request_id: response.headers.get('X-Request-Id')
    });
    // Không đọc body ngoài JSON hoặc đưa nội dung lỗi parse vào thông báo.
    if (!/^application\/json(?:\s*;|\s*$)/i.test(contentType)) throw khongHopLe();
    try { return await response.json(); }
    catch (_) { throw khongHopLe(); }
  }

  function tao({ fetch: tai = globalThis.fetch?.bind(globalThis), cho = tre, dong_ho = Date.now,
                 tao_ma = () => globalThis.crypto.randomUUID(), chuong_shell = false } = {}) {
    let context = Object.freeze({}), csrf = '', theHe = 0;
    const controllers = new Set(), yDinh = new Map(), viecNhan = new Map();
    const thongBaoMan = new Set();
    const chuChuong = { cap_nhat(key, data, options) {
      if (key === khoaMocDaXem(context)) chuong?.cap_nhat(data, options);
    } };
    let chuong = null;
    // Shell giữ quyền chuông ngay cả trước đăng nhập/chọn pháp nhân.
    // SDK module không được nhận chuông khi chỉ phạm vi riêng của module đã đủ.
    const nutShell = chuong_shell && globalThis.document?.getElementById?.('mo-viec-toi');
    if (nutShell && !chuongTheoNut.has(nutShell)) chuongTheoNut.set(nutShell, chuChuong);

    function doi_ngu_canh(next = {}) {
      chuong?.dung(); chuong = null;
      for (const view of thongBaoMan) view.dung();
      thongBaoMan.clear();
      theHe += 1;
      for (const controller of controllers) controller.abort();
      controllers.clear();
      viecNhan.clear();
      // Bỏ nội dung nháp khi đổi chủ; giữ fingerprint để không tái dùng nhầm khóa.
      if ((next.nguoi_dung_id ?? null) !== (context.nguoi_dung_id ?? null) ||
          (next.phap_nhan_id ?? null) !== (context.phap_nhan_id ?? null)) {
        for (const intent of yDinh.values()) intent.nhap = undefined;
      }
      // CSRF do Core cấp; không kế thừa token của người trước.
      if (next.nguoi_dung_id !== context.nguoi_dung_id) csrf = '';
      context = Object.freeze({ nguoi_dung_id: next.nguoi_dung_id ?? null,
        phap_nhan_id: next.phap_nhan_id ?? null, module: next.module ?? null, man: next.man ?? null });
      // Chỉ instance có pháp nhân mới sở hữu chuông; SDK danh sách không tranh
      // quyền hiển thị. Đổi màn/chủ hủy dữ liệu và lịch của ngữ cảnh cũ.
      const nut = globalThis.document?.getElementById?.('mo-viec-toi');
      if (nut && context.nguoi_dung_id && context.phap_nhan_id &&
          (!chuongTheoNut.has(nut) || chuongTheoNut.get(nut) === chuChuong)) {
        // Giữ chủ đã đăng ký qua cả đổi màn và đăng xuất; SDK nhúng cũ
        // chưa đăng ký tường minh vẫn tự gắn khi chưa có chủ.
        chuongTheoNut.set(nut, chuChuong);
        chuong = taoChuong(nut, {
          doc: request => api.goi(request),
          nguoi_dung_id: context.nguoi_dung_id, phap_nhan_id: context.phap_nhan_id,
          tam_dung: context.man === 'viec_toi', du_lieu_gia: laDuLieuGia(nut.ownerDocument)
        });
      }
    }

    async function trongContext(signal, fn) {
      const epoch = theHe, ctx = context, controller = new AbortController();
      const stop = () => controller.abort();
      if (signal?.aborted) stop();
      else signal?.addEventListener('abort', stop, { once: true });
      controllers.add(controller);
      const kiem = () => {
        if (epoch !== theHe) throw loi('NGU_CANH_DA_DOI', 'Đã đổi màn hoặc pháp nhân. Phản hồi cũ được bỏ qua.');
        if (controller.signal.aborted) throw new DOMException('Đã dừng theo dõi.', 'AbortError');
      };
      try {
        kiem();
        const result = await fn(ctx, controller.signal, kiem);
        kiem();
        return result;
      } catch (error) {
        kiem();
        throw error;
      } finally {
        controllers.delete(controller);
        signal?.removeEventListener('abort', stop);
      }
    }

    function gui(request, ctx, signal, kiem, nhiPhan = false, multipart = null) {
      const doc = () => guiThucHien(request, ctx, signal, kiem, nhiPhan, multipart);
      const docViec = (request.phuong_thuc || 'GET').toUpperCase() === 'GET' &&
        /^\/api\/v1\/viec(?:\?|\/[^/?]+(?:\?|$)|$)/.test(request.duong_dan);
      if (!docViec) return doc();
      // Bao cả theo_doi lẫn api.goi. Abort chỉ bỏ kết quả; vẫn giữ lượt
      // cho tới khi fetch (và đọc body) settle, kể cả transport bỏ qua abort.
      const truoc = luotDocViec; let xong;
      const luot = new Promise(resolve => { xong = resolve; });
      luotDocViec = luot;
      return (async () => {
        try {
          if (truoc) await truoc;
          return await doc();
        } finally {
          if (luotDocViec === luot) luotDocViec = null;
          xong();
        }
      })();
    }

    async function guiThucHien(request, ctx, signal, kiem, nhiPhan = false, multipart = null) {
      const path = duongDan(request.duong_dan), method = (request.phuong_thuc || 'GET').toUpperCase();
      if (!['GET', 'HEAD', 'POST', 'PATCH', 'PUT', 'DELETE'].includes(method)) {
        throw loi('PHUONG_THUC_KHONG_HOP_LE', 'Thao tác không được hỗ trợ.');
      }
      const ghi = !['GET', 'HEAD'].includes(method);
      const phapNhan = request.phap_nhan_id === undefined ? ctx.phap_nhan_id : request.phap_nhan_id;
      const maModule = request.module === undefined ? ctx.module : request.module;
      if ((ctx.phap_nhan_id && phapNhan !== ctx.phap_nhan_id) || (ctx.module && maModule !== ctx.module)) {
        throw loi('SAI_NGU_CANH', 'Hãy chọn lại đúng pháp nhân và màn trước khi gửi.');
      }
      const body = multipart ? multipart.body
        : request.du_lieu === undefined ? undefined : JSON.stringify(request.du_lieu);
      const nhap = multipart || body === undefined ? undefined : JSON.parse(body);
      if (nhap?.row_version !== undefined &&
          (typeof nhap.row_version !== 'string' || !/^\d+$/.test(nhap.row_version))) {
        throw loi('PHIEN_BAN_KHONG_HOP_LE', 'Hãy tải lại phiên bản dữ liệu trước khi lưu.');
      }
      const headers = { Accept: nhiPhan ? [...mimeTep].join(', ') : 'application/json', 'X-Request-Id': tao_ma() };
      if (phapNhan) headers['X-Phap-Nhan-Id'] = phapNhan;
      if (maModule) headers['X-Module-Ma'] = maModule;
      // FormData: trình duyệt tự đặt Content-Type cùng boundary.
      if (body !== undefined && !multipart) headers['Content-Type'] = 'application/json';
      if (ghi) {
        if (!csrf) throw loi('THIEU_CSRF', 'Hãy tải lại phiên đăng nhập trước khi lưu.');
        headers['X-CSRF-Token'] = csrf;
        // API §3.6: đăng nhập và đăng xuất miễn khóa, vẫn cần CSRF.
        if (path.split('?')[0] !== '/api/v1/phien' || !['POST', 'DELETE'].includes(method)) {
          if (typeof request.khoa !== 'string' || !request.khoa.trim()) {
            throw loi('THIEU_KHOA', 'Cần giữ khóa thao tác để gửi lại an toàn.');
          }
        }
        if (request.khoa) {
          const fingerprint = JSON.stringify([ctx.nguoi_dung_id, phapNhan, maModule, method, path,
            multipart ? multipart.fingerprint : body]);
          const old = yDinh.get(request.khoa);
          if (old && old.fingerprint !== fingerprint) {
            throw loi('KHOA_KHAC_NOI_DUNG', 'Nội dung hoặc pháp nhân đã đổi. Hãy đối chiếu kết quả trước khi tạo thao tác mới.');
          }
          if (!old) yDinh.set(request.khoa, { fingerprint, nhap, da_xong: false,
            nguoi_dung_id: ctx.nguoi_dung_id ?? null, phap_nhan_id: phapNhan ?? null,
            module: maModule ?? null });
          headers['Idempotency-Key'] = request.khoa;
        }
      } else if (body !== undefined) {
        throw loi('DU_LIEU_KHONG_HOP_LE', 'Yêu cầu đọc không nhận nội dung ghi.');
      }
      kiem();
      // Trình duyệt tự gắn Origin. Redirect bị chặn trước khi chuyển cookie/header sang đích khác.
      const response = await tai(path, { method, headers, body, signal,
        credentials: 'same-origin', mode: 'same-origin', redirect: 'error', cache: 'no-store' });
      try {
        kiem();
        if (response.redirected || (response.status >= 300 && response.status < 400)) {
          throw loi('CHUYEN_HUONG_BI_CHAN', 'Core trả đường dẫn chuyển hướng không được hỗ trợ.');
        }
        const data = await docPhanHoi(response, method, nhiPhan);
        kiem();
        if (nhiPhan && response.ok) return { data, status: response.status };
        if (!response.ok) {
          // Shell tự khởi động nghe sự kiện này cho mọi instance SDK, kể cả
          // adapter hệ thống. kiem() phía trên đã loại phản hồi sai ngữ cảnh.
          if (response.status === 401 && typeof globalThis.dispatchEvent === 'function' &&
              typeof globalThis.CustomEvent === 'function') {
            globalThis.dispatchEvent(new globalThis.CustomEvent('ktt:het-phien', {
              detail: { nguoi_dung_id: ctx.nguoi_dung_id }
            }));
          }
          const cauMayChu = typeof data?.thong_diep === 'string' && data.thong_diep.trim() &&
            data.thong_diep.length <= 1000 ? data.thong_diep : undefined;
          const error = Object.assign(loi(data?.ma || 'YEU_CAU_THAT_BAI',
            cauMayChu || 'Chưa hoàn tất yêu cầu. Hãy thử tải lại hoặc kiểm tra phiên đăng nhập.'), {
            thong_diep: cauMayChu,
            status: response.status, request_id: data?.request_id || response.headers.get('X-Request-Id'),
            chi_tiet: data?.chi_tiet, retry_after: response.headers.get('Retry-After'),
            thu_lai_duoc: data?.thu_lai_duoc,
            nhap: ghi ? sao(nhap) : undefined, khoa: request.khoa
          });
          if (response.status === 409 && error.ma === 'XUNG_DOT_PHIEN_BAN' && !cauMayChu) {
            error.message = 'Dữ liệu đã thay đổi. Bản nháp được giữ; hãy tải bản mới để đối chiếu trước khi lưu.';
          }
          throw error;
        }
        if (path === '/api/v1/phien' && data?.csrf_token) csrf = data.csrf_token;
        const retry = response.headers.get('Retry-After');
        if (response.status === 202) {
          if (!data?.viec_id) throw loi('PHAN_HOI_KHONG_HOP_LE', 'Chưa nhận được mã theo dõi công việc.');
          const location = duongDan(response.headers.get('Location') || `/api/v1/viec/${encodeURIComponent(data.viec_id)}`);
          if (location !== `/api/v1/viec/${encodeURIComponent(data.viec_id)}`) {
            throw loi('PHAN_HOI_KHONG_HOP_LE', 'Đường dẫn theo dõi công việc không khớp.');
          }
          viecNhan.set(data.viec_id, { path: location, retry, phap_nhan_id: phapNhan, module: maModule });
        } else if (ghi && request.khoa) yDinh.get(request.khoa).da_xong = true;
        return { data, retry, status: response.status };
      } finally {
        // Headers chưa kết thúc request: mọi nhánh bỏ body phải chờ hủy xong
        // trước khi hàng đọc nhả lượt, kể cả transport bỏ qua abort.
        try {
          if (!response.bodyUsed) await response.body?.cancel();
        } catch (_) {
          // Hủy đã settle; giữ kết quả/lỗi ban đầu của yêu cầu.
        }
      }
    }

    async function theoDoi(id, options, ctx, signal, kiem) {
      if (typeof id !== 'string' || !/^[A-Za-z0-9_-]+$/.test(id)) {
        throw loi('VIEC_KHONG_HOP_LE', 'Mã theo dõi công việc không hợp lệ.');
      }
      const nhan = viecNhan.get(id);
      let retry = nhan?.retry, canCho = Boolean(nhan);
      for (;;) {
        kiem();
        if (canCho) { await cho(doiSau(retry, dong_ho()), signal); kiem(); }
        const result = await gui({ duong_dan: nhan?.path || `/api/v1/viec/${id}`,
          phap_nhan_id: nhan ? nhan.phap_nhan_id : ctx.phap_nhan_id,
          module: nhan ? nhan.module : ctx.module }, ctx, signal, kiem);
        kiem();
        const state = result.data?.trang_thai;
        if (!ketThuc.has(state) && !dangChay.has(state)) {
          throw loi('PHAN_HOI_KHONG_HOP_LE', 'Chưa xác định được trạng thái công việc. Hãy tải lại để kiểm tra.');
        }
        options.khi_doi?.(sao(result.data));
        kiem();
        if (ketThuc.has(state)) { viecNhan.delete(id); return result.data; }
        retry = result.retry;
        canCho = true;
      }
    }

    const api = {
      doi_ngu_canh,
      gan_csrf: token => { csrf = typeof token === 'string' ? token : ''; },
      // File/Blob; options: khoa, muc_dich (mặc định tai_lieu), tai_lieu_id,
      // signal, phap_nhan_id, module. Trả metadata 201, không tự đổi khóa khi lỗi.
      tai_len_tep(file, options = {}) {
        const frozen = { ...options };
        return trongContext(frozen.signal, async (ctx, signal, kiem) => {
          if (!(file instanceof Blob)) throw loi('DU_LIEU_KHONG_HOP_LE', 'Cần chọn tệp để tải lên.');
          if (file.size > 20 * 1024 * 1024) throw loi('TEP_QUA_LON', 'Tệp vượt quá 20 MiB.');
          const mucDich = frozen.muc_dich === undefined ? 'tai_lieu' : frozen.muc_dich;
          if (!['tai_lieu', 'goi_module'].includes(mucDich) ||
              (mucDich === 'goi_module' && frozen.tai_lieu_id !== undefined)) {
            throw loi('DU_LIEU_KHONG_HOP_LE', 'Mục đích hoặc tài liệu của tệp không hợp lệ.');
          }
          const target = frozen.tai_lieu_id === undefined ? undefined : maTaiNguyen(frozen.tai_lieu_id);
          const name = file.name || 'tep-tai-len';
          // Fingerprint có bytes: hai tệp cùng tên/kích thước vẫn không dùng nhầm khóa.
          // Chỉ giữ hash trong RAM; Core tự kiểm MIME/hash và quyền khi nhận tệp.
          const bytes = await file.arrayBuffer();
          kiem();
          const digest = await globalThis.crypto.subtle.digest('SHA-256', bytes);
          kiem();
          const hash = Array.from(new Uint8Array(digest), b => b.toString(16).padStart(2, '0')).join('');
          const body = new FormData();
          body.append('tep', file, name);
          body.append('muc_dich', mucDich);
          if (target !== undefined) body.append('tai_lieu_id', target);
          const result = await gui({ duong_dan: '/api/v1/tep', phuong_thuc: 'POST', khoa: frozen.khoa,
            phap_nhan_id: frozen.phap_nhan_id, module: frozen.module }, ctx, signal, kiem, false,
          { body, fingerprint: ['multipart', name, file.type, file.size, hash, mucDich, target] });
          // H2a trả metadata đồng bộ: không coi 200/202 là upload đã xác nhận.
          if (result.status !== 201) throw loi('PHAN_HOI_KHONG_HOP_LE', 'Chưa xác nhận được tệp tải lên.');
          return result.data;
        });
      },
      // GET dùng cookie cùng nguồn, không cần CSRF như các hàm đọc JSON.
      // Trả { blob, ten_tep }; caller quyết định cách lưu Blob xuống máy.
      tai_tep: (id, options = {}) => trongContext(options.signal,
        (ctx, signal, kiem) => gui({ duong_dan: `/api/v1/tep/${maTaiNguyen(id)}/noi-dung`,
          phap_nhan_id: options.phap_nhan_id, module: options.module }, ctx, signal, kiem, true)
          .then(result => result.data)),
      doc_nhap(khoa) {
        const intent = yDinh.get(khoa);
        if (!intent || intent.nguoi_dung_id !== (context.nguoi_dung_id ?? null) ||
            intent.phap_nhan_id !== (context.phap_nhan_id ?? null) ||
            intent.module !== (context.module ?? null)) return undefined;
        return sao(intent.nhap);
      },
      goi(request) {
        // Chụp ý định trước await: sửa form trong lúc chờ không đổi body/context retry.
        const frozen = { ...request, du_lieu: sao(request.du_lieu) };
        return trongContext(frozen.signal, async (ctx, signal, kiem) => {
          const pollContext = { ...ctx,
            phap_nhan_id: frozen.phap_nhan_id === undefined ? ctx.phap_nhan_id : frozen.phap_nhan_id,
            module: frozen.module === undefined ? ctx.module : frozen.module };
          for (;;) {
            let result;
            try { result = await gui(frozen, ctx, signal, kiem); }
            catch (error) {
              if (error.status !== 409 || error.ma !== 'YEU_CAU_DANG_XU_LY') throw error;
              await cho(doiSau(error.retry_after, dong_ho()), signal);
              kiem();
              continue;
            }
            return result.status === 202 && frozen.theo_doi === true
              ? theoDoi(result.data.viec_id, frozen, pollContext, signal, kiem) : result.data;
          }
        });
      }
    };
    const viec = {
      // Màn module: sau khi gửi, gọi hien_hang_cho(root, bienNhan.viec_id,
      // {signal}) và hủy signal khi rời màn. Chỉ đọc DTO 1.3 qua cổng Core.
      hien_hang_cho(root, id, options = {}) {
        const view = hienHangCho(root, maTaiNguyen(id), {
          ...options, doc: request => api.goi({ ...request,
            phap_nhan_id: options.phap_nhan_id, module: options.module })
        });
        const managed = { san_sang: view.san_sang, dung() {
          view.dung(); thongBaoMan.delete(managed);
          options.signal?.removeEventListener('abort', managed.dung);
        } };
        thongBaoMan.add(managed);
        if (options.signal?.aborted) managed.dung();
        else options.signal?.addEventListener('abort', managed.dung, { once: true });
        return managed;
      },
      // Màn gọi bằng SDK của đúng người dùng/pháp nhân đã đọc snapshot.
      // Mốc dùng chung cả trang, kể cả khi SDK màn không sở hữu chuông.
      cap_nhat_chuong(data, options = {}) {
        const doc = globalThis.document, key = khoaMocDaXem(context);
        if (!doc || !key) return;
        if (!laDuLieuGia(doc) && options.da_xem && Array.isArray(data?.danh_sach)) {
          danhDauDaXem(key, data.danh_sach, doc.defaultView || globalThis);
        }
        const nut = doc.getElementById?.('mo-viec-toi');
        // Chuông chỉ nhận snapshot khớp chủ; không đổi ngữ cảnh của Shell.
        if (nut) chuongTheoNut.get(nut)?.cap_nhat(key, data, options);
      },
      ket_qua: (id, options = {}) => api.goi({ duong_dan: `/api/v1/viec/${maTaiNguyen(id)}/ket-qua`,
        signal: options.signal, phap_nhan_id: options.phap_nhan_id, module: options.module }),
      theo_doi: (id, options = {}) => trongContext(options.signal,
        (ctx, signal, kiem) => theoDoi(id, options, ctx, signal, kiem)),
      huy: (id, khoa) => api.goi({ phuong_thuc: 'POST', duong_dan: `/api/v1/viec/${encodeURIComponent(id)}/huy`, khoa })
    };
    const ket_qua = {
      tai_tep: (id, options = {}) => trongContext(options.signal, async (ctx, signal, kiem) => {
        const request = { phap_nhan_id: options.phap_nhan_id, module: options.module };
        const meta = await gui({ ...request, duong_dan: `/api/v1/ket-qua/${maTaiNguyen(id)}` }, ctx, signal, kiem);
        return (await gui({ ...request, duong_dan: `/api/v1/tep/${maTaiNguyen(meta.data?.tep_id)}/noi-dung` },
          ctx, signal, kiem, true)).data;
      })
    };
    const phap_nhan = {
      danh_sach: ({ con_tro, signal } = {}) => api.goi({
        duong_dan: '/api/v1/phap-nhan?phien_ban_du_lieu=1.2' +
          (con_tro ? `&con_tro=${encodeURIComponent(con_tro)}` : ''), signal })
    };
    const tep = {
      tai_len: api.tai_len_tep,
      tham_chieu: (id, options = {}) => api.goi({ duong_dan: `/api/v1/tep/${maTaiNguyen(id)}`,
        signal: options.signal, phap_nhan_id: options.phap_nhan_id, module: options.module }),
      tai_tep: api.tai_tep
    };
    return { api, viec, ket_qua, phap_nhan, tep };
  }

  function node(doc, tag, text, className) {
    const element = doc.createElement(tag);
    if (text !== undefined) element.textContent = text;
    if (className) element.className = className;
    return element;
  }

  function laDuLieuGia(doc) {
    return /[?&]du_lieu_gia=1(?:&|$)/.test(String(doc.defaultView?.location?.search || ''));
  }
  function tenNghiepVu(value) {
    return typeof value === 'string' && value.trim() && value.length <= 255 &&
      !/[<>\u0000-\u001f\u007f]|:\/\/|[\\/]|\b(?:CORE:|row_version|capability)\b/i.test(value) &&
      !/[0-9a-f]{8}(?:-[0-9a-f]{4}){3}-[0-9a-f]{12}/i.test(value) &&
      !/^[A-Z0-9_.:-]+$/.test(value) && !/^[a-z0-9]+(?:[_.][a-z0-9]+)+$/.test(value)
      ? value.trim() : '';
  }
  function thongDiepHangCho(item) {
    const lines = [], hang = item?.van_hanh?.hang_cho, chuoi = item?.van_hanh?.chuoi;
    if (Number.isSafeInteger(chuoi?.buoc_thu_tu) && Number.isSafeInteger(chuoi?.tong_buoc) &&
        chuoi.buoc_thu_tu >= 1 && chuoi.buoc_thu_tu <= chuoi.tong_buoc) {
      const name = tenNghiepVu(chuoi.ten_hien_thi);
      lines.push(`${name ? name + ' · ' : ''}Bước ${chuoi.buoc_thu_tu}/${chuoi.tong_buoc}`);
    }
    // Không tiếp tục báo chờ bằng snapshot cũ khi việc đã bắt đầu/kết thúc.
    if (item?.trang_thai === 'queued' && Number.isSafeInteger(hang?.vi_tri) && hang.vi_tri >= 1) {
      const estimated = hang.la_uoc_tinh === true;
      lines.push(`Vị trí thứ ${hang.vi_tri}${estimated ? ' (ước tính)' : ''} trong hàng chờ`);
      if (Number.isSafeInteger(hang.truoc_con) && hang.truoc_con === hang.vi_tri - 1)
        lines.push(`Phía trước còn ${hang.truoc_con} việc`);
      if (Number.isSafeInteger(hang.uoc_tinh_phut) && hang.uoc_tinh_phut >= 0)
        lines.push(`${estimated ? 'Ước tính bắt đầu' : 'Bắt đầu'} sau khoảng ${hang.uoc_tinh_phut} phút`);
    }
    return lines.join(' · ');
  }
  function viecGia() {
    return [{ id: '00000000-0000-4000-8000-000000000081', ten_viec: 'Đọc hợp đồng mẫu',
      trang_thai: 'queued', tien_do: 0, tao_luc: '2026-11-06T01:00:00Z', cap_nhat_luc: '2026-11-06T01:00:00Z',
      van_hanh: { so_lan_thu: 0, duoc_huy: false,
        hang_cho: { vi_tri: 3, truoc_con: 2, uoc_tinh_phut: 3, la_uoc_tinh: true },
        chuoi: { lan_chay_id: '00000000-0000-4000-8000-000000000080', ten_hien_thi: 'Đọc hợp đồng', buoc_thu_tu: 1, tong_buoc: 2 } } },
    { id: '00000000-0000-4000-8000-000000000082', ten_viec: 'Đối chiếu chứng từ mẫu',
      trang_thai: 'running', tien_do: 40, tao_luc: '2026-11-06T01:00:00Z', cap_nhat_luc: '2026-11-06T01:02:00Z',
      van_hanh: { so_lan_thu: 1, duoc_huy: false, hang_cho: {},
        chuoi: { lan_chay_id: '00000000-0000-4000-8000-000000000083', ten_hien_thi: 'Đối chiếu chứng từ', buoc_thu_tu: 2, tong_buoc: 3 } } }];
  }

  // Một request tại một thời điểm, kể cả transport bỏ qua abort. Mỗi lượt mới
  // chỉ được hẹn sau khi lượt trước đã kết thúc; tab ẩn không đọc hoặc ghi DOM.
  function theoDoiThongBao(root, { doc: read, ve: draw, khi_loi, signal, tri_hoan = false, mot_lan = false, chu_ky = 5000 } = {}) {
    const doc = root.ownerDocument, clock = doc.defaultView || globalThis;
    let timer = null, flight = null, reading = null, stopped = false, finished = false, epoch = 0, retryAt = 0;
    const visible = () => !doc.hidden && doc.visibilityState !== 'hidden';
    const now = () => (clock.Date || Date).now();
    function clear() { if (timer !== null) clock.clearTimeout(timer); timer = null; }
    function stop() {
      if (stopped) return;
      stopped = true; ++epoch; clear(); reading?.abort();
      doc.removeEventListener?.('visibilitychange', visibility);
      signal?.removeEventListener('abort', stop); root.replaceChildren();
    }
    function schedule() {
      clear();
      if (!stopped && !finished && visible() && !mot_lan) timer = clock.setTimeout(load, Math.max(chu_ky, retryAt - now()));
    }
    async function load() {
      clear();
      if (stopped || finished || !visible() || flight) return;
      const current = ++epoch; reading = new AbortController();
      let again = true;
      const request = Promise.resolve().then(() => read(reading.signal)); flight = request;
      try {
        const data = await request;
        if (stopped || current !== epoch || !visible()) return;
        retryAt = 0; again = draw(data) !== false; finished = !again || mot_lan;
      } catch (error) {
        if (stopped || current !== epoch || !visible()) return;
        khi_loi?.();
        if (error?.status === 401 || ['NGU_CANH_DA_DOI', 'SAI_NGU_CANH'].includes(error?.ma)) { stop(); return; }
        root.replaceChildren(node(doc, 'span', 'Chưa cập nhật được thông tin công việc.'));
        again = ![403, 404, 501].includes(error?.status);
        finished = !again;
        retryAt = now() + Math.max(5000, doiSau(error?.retry_after, now()));
      } finally {
        flight = null; reading = null;
        if (!stopped && (again || current !== epoch)) schedule();
      }
    }
    function visibility() {
      clear(); ++epoch; reading?.abort();
      if (!visible() || stopped || finished || flight) return;
      if (retryAt > now()) schedule(); else return load();
    }
    doc.addEventListener?.('visibilitychange', visibility);
    signal?.addEventListener('abort', stop, { once: true });
    if (signal?.aborted) stop();
    const ready = stopped || !visible() ? Promise.resolve() : tri_hoan ? (schedule(), Promise.resolve()) : load();
    return { dung: stop, san_sang: ready };
  }

  function hienHangCho(root, id, options) {
    const doc = root.ownerDocument, fake = laDuLieuGia(doc);
    root.setAttribute('role', 'status');
    return theoDoiThongBao(root, { signal: options.signal, mot_lan: fake,
      doc: signal => fake ? viecGia()[0] : options.doc({
        duong_dan: `/api/v1/viec/${id}?phien_ban_du_lieu=1.3`, signal }),
      ve: item => {
        if (!item || (!fake && item.id !== id) || (!ketThuc.has(item.trang_thai) && !dangChay.has(item.trang_thai))) throw new Error();
        const status = { queued: 'Đã xếp hàng', running: 'Đang xử lý', waiting_input: 'Chờ bổ sung',
          cancel_requested: 'Đang chờ dừng', succeeded: 'Đã hoàn tất', failed: 'Có lỗi', cancelled: 'Đã hủy', interrupted: 'Bị gián đoạn' };
        root.replaceChildren(node(doc, 'p', `${fake ? 'Dữ liệu giả · ' : ''}${status[item.trang_thai]}`),
          node(doc, 'p', thongDiepHangCho(item)), node(doc, 'p', 'Có thể rời màn này; theo dõi kết quả trong “Việc của tôi”.'));
        return !ketThuc.has(item.trang_thai);
      }
    });
  }

  function khoaMocDaXem({ nguoi_dung_id, phap_nhan_id }) {
    return nguoi_dung_id && phap_nhan_id
      ? `ktt.viec.da-xem.v1:${encodeURIComponent(nguoi_dung_id)}:${encodeURIComponent(phap_nhan_id)}` : null;
  }

  function docMocDaXem(key, clock) {
    let viewedAt = mocDaXemChuong.get(key) || 0;
    try {
      const saved = Number(clock.localStorage?.getItem(key));
      if (Number.isSafeInteger(saved) && saved >= 0) viewedAt = Math.max(viewedAt, saved);
    } catch (_) { /* Storage bị chặn: dùng mốc chung trong bộ nhớ. */ }
    mocDaXemChuong.set(key, viewedAt);
    return viewedAt;
  }

  // DTO 1.3 chưa có cửa đánh dấu đã xem. Chỉ lưu mốc kết thúc đã hiển thị,
  // tách người dùng + pháp nhân; không lưu dữ liệu việc, phiên hay nháp.
  function danhDauDaXem(key, rows, clock) {
    const viewedAt = docMocDaXem(key, clock);
    let latest = viewedAt;
    for (const item of rows) {
      if (!ketThuc.has(item?.trang_thai) || typeof item.cap_nhat_luc !== 'string') continue;
      const endedAt = Date.parse(item.cap_nhat_luc);
      if (Number.isSafeInteger(endedAt)) latest = Math.max(latest, endedAt);
    }
    if (latest === viewedAt) return;
    mocDaXemChuong.set(key, latest);
    try { clock.localStorage?.setItem(key, String(latest)); }
    catch (_) { /* Không để lỗi storage ngăn mở danh sách. */ }
  }

  function taoChuong(button, { doc: read, nguoi_dung_id, phap_nhan_id, tam_dung = false, du_lieu_gia = false }) {
    const doc = button.ownerDocument, clock = doc.defaultView || globalThis, label = 'Việc của tôi / Chờ tôi duyệt';
    const box = node(doc, 'span'), countNode = node(doc, 'span', '', 'core-so-cho');
    const items = new Map(), key = khoaMocDaXem({ nguoi_dung_id, phap_nhan_id });
    if (!du_lieu_gia) docMocDaXem(key, clock);
    // Dùng lớp số đỏ đã có, không thêm tài nguyên tĩnh.
    const icon = node(doc, 'span', '🔔', 'core-chuong'); icon.setAttribute('aria-hidden', 'true');
    button.replaceChildren(icon, node(doc, 'span', label), box);
    if (du_lieu_gia) button.append(node(doc, 'span', ' · Dữ liệu giả'));
    if (button.style) button.style.position = 'relative';
    let complete = false, monitor = null;
    function render() {
      const viewedAt = du_lieu_gia ? 0 : mocDaXemChuong.get(key) || 0;
      // cap_nhat_luc là mốc trạng thái được DTO 1.3 công bố.
      const count = [...items.values()].filter(item => ketThuc.has(item.trang_thai) &&
        typeof item.cap_nhat_luc === 'string' && Date.parse(item.cap_nhat_luc) > viewedAt).length;
      countNode.textContent = String(count) + (complete ? '' : '+'); countNode.hidden = !count;
      box.replaceChildren(countNode);
      button.setAttribute('aria-label', `${label}${du_lieu_gia ? ', Dữ liệu giả' : ''}${count ? `, ${complete ? '' : 'ít nhất '}${count} việc đã kết thúc chưa xem` : ''}`);
    }
    function update(data, { con_tro = null, toan_bo = false } = {}) {
      if (Array.isArray(data?.danh_sach)) {
        if (toan_bo || (!con_tro && data.con_tiep === false)) {
          items.clear(); complete = data.con_tiep === false;
        } else if (!con_tro && !complete) items.clear();
        data.danh_sach.forEach(item => { if (item?.id) items.set(item.id, item); });
      } else if (data?.id && items.has(data.id)) items.set(data.id, data);
      render();
      // Trang việc thường đã đủ để đếm. Nếu còn trang, đọc đầy đủ ở nhịp
      // chuông; không lấy số dòng của riêng trang hiện tại làm tổng.
      if (data?.con_tiep === true && tam_dung && !du_lieu_gia && !monitor) monitor = startMonitor();
    }
    function startMonitor() { return theoDoiThongBao(box, { tri_hoan: true, chu_ky: 15000,
      doc: async signal => {
        const rows = [], cursors = new Set(); let cursor = null;
        for (let n = 0; n < 20; n++) {
          const data = await read({ duong_dan: '/api/v1/viec?phien_ban_du_lieu=1.3' +
            (cursor ? `&con_tro=${encodeURIComponent(cursor)}` : ''), signal });
          if (signal.aborted) throw new DOMException('Đã dừng theo dõi.', 'AbortError');
          if (!Array.isArray(data?.danh_sach) || data.danh_sach.some(item => !item?.id || !dangChay.has(item.trang_thai) && !ketThuc.has(item.trang_thai)) || typeof data.con_tiep !== 'boolean') throw new Error();
          rows.push(...data.danh_sach);
          if (!data.con_tiep) return { danh_sach: rows, con_tiep: false };
          cursor = data.con_tro_tiep;
          if (typeof cursor !== 'string' || !cursor || cursor.length > 4096 || cursors.has(cursor)) throw new Error();
          cursors.add(cursor);
        }
        return { danh_sach: rows, con_tiep: true };
      }, ve: data => { update(data, { toan_bo: true }); },
      khi_loi: () => button.setAttribute('aria-label', `${label}, Chưa cập nhật được số việc`)
    }); }
    if (!tam_dung && !du_lieu_gia) monitor = startMonitor();
    if (du_lieu_gia) update({ danh_sach: viecGia().map((item, index) => ({ ...item,
      trang_thai: index ? 'failed' : 'succeeded' })), con_tiep: false });
    else render();
    return { cap_nhat: update, dung() { monitor?.dung(); button.replaceChildren(node(doc, 'span', label)); button.setAttribute('aria-label', label); } };
  }

  function nhanDemo(root, phapNhan) {
    const nhan = phapNhan?.la_demo === true ? 'DEMO — dữ liệu thử'
      : phapNhan && phapNhan.la_demo !== false ? 'Chưa xác định DEMO' : '';
    root.textContent = nhan;
    root.hidden = !nhan;
    root.setAttribute('aria-label', nhan);
  }

  /* Nhận cấu trúc module/phan/the của UI-2. Caller chỉ truyền bản Core đã lọc.
     Cần lead: renderer UI-1 ở lat/ui-1 chưa có trong cây này; app.js của nhánh đó
     chỉ xuất dangKy/phanTich, gắn DOM/router/API cũ, chưa có renderer độc lập để gọi lại.
     Không tự suy quyền, đếm số hoặc nạp HTML/script từ đường dẫn module. */
  function dungKhung(root, khaiBao, { khi_mo = () => {}, khi_doi_man = () => {}, khi_ve_trang_chu = () => {} } = {}) {
    const doc = root.ownerDocument;
    const modules = sao(khaiBao?.khong_quyen ? [] : Array.isArray(khaiBao?.module) ? khaiBao.module
      : khaiBao?.module ? [{ ...khaiBao.module, phan: khaiBao.phan || [], the: khaiBao.the || [] }] : []);
    const hayDung = new Set();
    // bo_cap_goc: khai báo chỉ có một module (khung Quản trị) thì vào thẳng lưới ô chức năng,
    // đường dẫn đầu là Trang chủ thật; phần có hien_duoi hiện thành khối thông tin dưới lưới.
    const boCapGoc = khaiBao?.bo_cap_goc === true && modules.length === 1;
    let selected = null, tim = '', pageController, infoController;
    const shell = node(doc, 'div', undefined, 'core-khung');
    const rail = node(doc, 'nav', undefined, 'core-rail');
    rail.setAttribute('aria-label', 'Module nghiệp vụ');
    const main = node(doc, 'div', undefined, 'core-main');
    const breadcrumb = node(doc, 'nav', undefined, 'core-breadcrumb');
    breadcrumb.setAttribute('aria-label', 'Vị trí hiện tại');
    const search = node(doc, 'input'); search.type = 'search'; search.placeholder = 'Tìm nhanh nghiệp vụ…';
    search.setAttribute('aria-label', 'Tìm nhanh nghiệp vụ');
    const favorites = node(doc, 'div', undefined, 'core-hay-dung');
    const heading = node(doc, 'h1', 'Nghiệp vụ');
    const cards = node(doc, 'div', undefined, 'core-the');
    const grid = node(doc, 'div', undefined, 'core-luoi gk-luoi');
    const content = node(doc, 'section', undefined, 'core-noi-dung');
    content.setAttribute('aria-label', 'Nội dung trang module');
    const info = node(doc, 'section', undefined, 'core-thong-tin');
    info.setAttribute('aria-label', 'Tình trạng hệ thống');
    main.append(breadcrumb, search, favorites, heading, cards, grid, info, content);
    if (boCapGoc) rail.hidden = true;
    shell.append(rail, main); root.replaceChildren(shell);

    function badge(parent, item) {
      if (item.day_du === false) parent.append(node(doc, 'span', 'Chưa đủ số liệu', 'core-chua-du'));
      else if (Number.isSafeInteger(item.so) && item.so > 0) {
        parent.append(node(doc, 'span', `${item.so}${item.canh_bao ? ' quá hạn' : ''}`, 'core-badge'));
      }
    }
    function tile(item, action, compact = false) {
      // Không phản chiếu mã kỹ thuật khi chưa có tên nghiệp vụ.
      const title = item.ten || item.nhan;
      if (!title) return null;
      const button = node(doc, 'button', undefined, compact ? 'core-icon' : 'core-o'); button.type = 'button';
      button.setAttribute('title', title);
      const icon = node(doc, 'span', title.slice(0, 1), 'core-icon-hinh'); icon.setAttribute('aria-hidden', 'true');
      button.append(icon, node(doc, 'span', title)); badge(button, item);
      button.addEventListener('click', action); return button;
    }
    function dongThongTin() { infoController?.abort(); infoController = null; info.replaceChildren(); }
    function moThongTin() {
      dongThongTin();
      const item = boCapGoc && selected ? (selected.phan || []).find(p => p.hien_duoi) : null;
      if (!item) return;
      infoController = new AbortController();
      const signal = infoController.signal, maModule = selected.ma;
      info.append(node(doc, 'h2', item.ten || item.nhan));
      const page = node(doc, 'div'); info.append(page);
      Promise.resolve().then(() => {
        if (!signal.aborted) return khi_mo({ module: maModule, phan: sao(item), root: page, signal });
      }).catch(error => { if (!signal.aborted) thongBaoLoi(page, error); });
    }
    function doiMan(ma) {
      if (ma !== null) dongThongTin();
      pageController?.abort(); pageController = new AbortController();
      khi_doi_man({ module: selected?.ma || null, man: ma });
      content.replaceChildren();
    }
    function mo(item) {
      doiMan(item.ma);
      const signal = pageController.signal, maModule = selected.ma;
      hayDung.add(selected.ma);
      veHayDung();
      content.append(node(doc, 'h2', item.ten || item.nhan));
      if (item.loc) content.append(node(doc, 'p', item.giai_thich || 'Danh sách theo bộ lọc đã chọn.'));
      const page = node(doc, 'div'); content.append(page);
      Promise.resolve().then(() => {
        if (!signal.aborted) return khi_mo({ module: maModule, phan: sao(item), root: page, signal });
      }).catch(error => { if (!signal.aborted) thongBaoLoi(page, error); });
    }
    function veHayDung() {
      favorites.replaceChildren();
      if (!hayDung.size) return;
      favorites.append(node(doc, 'span', 'Hay dùng: '));
      for (const m of modules.filter(m => hayDung.has(m.ma))) {
        const button = tile(m, () => chon(m), true); if (button) favorites.append(button);
      }
    }
    function ve() {
      breadcrumb.replaceChildren();
      const home = node(doc, 'button', boCapGoc ? 'Trang chủ' : 'Nghiệp vụ'); home.type = 'button';
      home.addEventListener('click', () => boCapGoc ? khi_ve_trang_chu() : chon(null)); breadcrumb.append(home);
      if (boCapGoc && selected) {
        breadcrumb.append(node(doc, 'span', ' / '));
        const here = node(doc, 'button', selected.ten); here.type = 'button';
        here.addEventListener('click', () => chon(selected)); breadcrumb.append(here);
      } else if (selected) breadcrumb.append(node(doc, 'span', ` / ${selected.ten}`));
      heading.textContent = selected?.ten || 'Nghiệp vụ';
      grid.replaceChildren(); cards.replaceChildren();
      const items = selected?.phan || modules;
      for (const item of items) {
        if (item.hien_duoi || !(item.ten || '').toLocaleLowerCase('vi').includes(tim)) continue;
        const button = tile(item, () => selected ? mo(item) : chon(item)); if (button) grid.append(button);
      }
      if (!grid.children.length) grid.append(node(doc, 'p', 'Chưa có nghiệp vụ phù hợp trong phạm vi được cấp.'));
      for (const card of (selected?.the || []).slice(0, 4)) {
        const button = tile(card, () => mo(card)); if (button) cards.append(button);
      }
    }
    function chon(m) { selected = m; tim = ''; search.value = ''; doiMan(null); ve(); moThongTin(); }
    search.addEventListener('input', () => { tim = search.value.trim().toLocaleLowerCase('vi'); ve(); });
    if (!boCapGoc) for (const m of modules) { const button = tile(m, () => chon(m), true); if (button) rail.append(button); }
    if (boCapGoc) chon(modules[0]); else ve();
    return { noi_dung: content, dung: () => { pageController?.abort(); infoController?.abort(); } };
  }


  // SHELL-V2: dữ liệu trang chủ là DTO đã được máy chủ lọc MTQ, không dùng /module.
  // SVG tự vẽ nét, chỉ chọn path trong bộ nội tuyến; không nhận markup từ API.
  const bieuTuongShell = Object.freeze({
    grid: 'M3 3h7v7H3z M14 3h7v7h-7z M3 14h7v7H3z M14 14h7v7h-7z',
    briefcase: 'M3 7h18v13H3z M8 7V4h8v3 M3 12h18 M10 12v3h4v-3',
    file: 'M6 3h8l4 4v14H6z M14 3v5h4 M9 12h6 M9 16h6',
    wallet: 'M3 6h17v15H3z M3 6V3h15v3 M15 11h6v5h-6z',
    chart: 'M4 3v18h17 M8 17v-5 M13 17V8 M18 17V4',
    inbox: 'M6 3h12l3 12v6H3v-6z M3 15h5l2 3h4l2-3h5',
    check: 'M20 11v9H4V4h11 M9 10l4 4 8-10',
    settings: 'M12 3v3 M12 18v3 M3 12h3 M18 12h3 M5 5l2 2 M17 17l2 2 M5 19l2-2 M17 7l2-2 M17 12a5 5 0 1 1-10 0 5 5 0 0 1 10 0',
    shield: 'M12 3l8 3v6c0 5-8 9-8 9s-8-4-8-9V6z M8 12l3 3 5-6',
    users: 'M9 3a4 4 0 1 1 0 8 4 4 0 0 1 0-8 M2 21v-3a7 7 0 0 1 14 0v3 M17 4a4 4 0 0 1 0 8 M19 15a5 5 0 0 1 3 5',
    building: 'M5 21V3h14v18 M2 21h20 M9 7h1 M14 7h1 M9 11h1 M14 11h1 M10 21v-6h4v6',
    archive: 'M3 3h18v5H3z M5 8v13h14V8 M10 12h4'
  });
  function duongDanTrang(value) {
    // Chỉ điều hướng cùng nguồn; chặn protocol-relative, ký tự ẩn và traversal.
    return typeof value === 'string' && /^\/(?!\/)/.test(value) &&
      !/[\\\s\u0000-\u001f\u007f]/.test(value) && !/%(?:2f|5c|2e|0[0-9a-f]|1[0-9a-f]|7f)/i.test(value) &&
      !value.split(/[/?#]/).some(x => x === '.' || x === '..');
  }
  function dungTrangChu(root, duLieu, { khi_mo = () => {} } = {}) {
    const doc = root.ownerDocument, controller = new AbortController();
    const rows = duLieu.o.filter(o => o.ma !== 'quan_tri_core' || duLieu.nguoi_dung.la_admin === true);
    // Giữ thứ tự máy chủ cho nghiệp vụ; Quản trị Core luôn ở cuối.
    const items = [...rows.filter(o => o.ma !== 'quan_tri_core'), ...rows.filter(o => o.ma === 'quan_tri_core')];
    const main = node(doc, 'section', undefined, 'core-main core-trang-chu');
    const search = node(doc, 'input'); search.type = 'search'; search.placeholder = 'Tìm nhanh nghiệp vụ…';
    search.setAttribute('aria-label', 'Tìm nhanh nghiệp vụ');
    const favorites = node(doc, 'nav', undefined, 'core-hay-dung'); favorites.setAttribute('aria-label', 'Hay dùng');
    const grid = node(doc, 'div', undefined, 'core-luoi core-luoi-icon');
    const fold = text => text.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLocaleLowerCase('vi').replace(/đ/g, 'd');
    function tile(item) {
      const active = item.trang_thai === 'MO' && (duongDanTrang(item.duong_dan) || item.duong_dan === '#quan-tri-core');
      // CD060-C13 / SDK 1.4.1: chỉ bổ sung nhãn ô; giữ nguyên API và trạng thái cũ.
      const label = item.trang_thai === 'CHUA_BAT' ? 'Chưa bật' : item.trang_thai === 'DA_GO' ? 'Đã gỡ, giữ dữ liệu' : item.trang_thai === 'TAM_DUNG' ? 'Tạm dừng' : item.trang_thai === 'SAP_CO' ? 'Sắp có' : '';
      const button = node(doc, 'button', undefined, 'core-icon core-o-trang-chu'); button.type = 'button';
      button.disabled = !active; button.setAttribute('title', item.ten);
      const count = Number.isSafeInteger(item.so_cho) && item.so_cho > 0 ? item.so_cho : 0;
      button.setAttribute('aria-label', item.ten + (count ? `, ${count} việc chờ` : '') + (label ? `, ${label}` : ''));
      const icon = node(doc, 'span', undefined, 'core-icon-hinh'); icon.setAttribute('aria-hidden', 'true');
      icon.style.backgroundColor = /^#[0-9a-f]{6}$/i.test(item.mau) ? item.mau : '#475569';
      const svg = doc.createElementNS('http://www.w3.org/2000/svg', 'svg');
      for (const [key, value] of Object.entries({ viewBox: '0 0 24 24', fill: 'none', stroke: 'currentColor',
        'stroke-width': '1.7', 'stroke-linecap': 'round', 'stroke-linejoin': 'round', focusable: 'false' })) svg.setAttribute(key, value);
      const path = doc.createElementNS('http://www.w3.org/2000/svg', 'path');
      path.setAttribute('d', Object.hasOwn(bieuTuongShell, item.bieu_tuong) ? bieuTuongShell[item.bieu_tuong] : bieuTuongShell.grid); svg.append(path); icon.append(svg);
      if (count) icon.append(node(doc, 'span', String(count), 'core-so-cho'));
      button.append(icon, node(doc, 'span', item.ten, 'core-ten-icon'));
      if (label) button.append(node(doc, 'span', label, 'core-trang-thai-icon'));
      button.addEventListener('click', () => { if (active && !controller.signal.aborted) return khi_mo(item); });
      return button;
    }
    function draw() {
      grid.replaceChildren();
      for (const item of items) if (fold(item.ten).includes(fold(search.value.trim()))) grid.append(tile(item));
      if (!grid.children.length) grid.append(node(doc, 'p', 'Chưa có nghiệp vụ phù hợp trong phạm vi được cấp.'));
    }
    favorites.append(node(doc, 'strong', 'Hay dùng'));
    for (const ma of [...new Set(duLieu.hay_dung)].slice(0, 4)) {
      const item = items.find(o => o.ma === ma); if (item) favorites.append(tile(item));
    }
    favorites.hidden = favorites.children.length === 1;
    main.append(node(doc, 'h1', 'Nghiệp vụ'), search, favorites);
    if (duLieu.dang_noi) main.append(node(doc, 'p', 'Danh sách nghiệp vụ đang được nối', 'core-cho-noi'));
    main.append(grid); root.replaceChildren(main);
    search.addEventListener('input', draw); draw();
    return { dung: () => controller.abort() };
  }

  function thongBaoLoi(root, error) {
    if (error?.ma === 'NGU_CANH_DA_DOI' || error?.name === 'AbortError') return;
    const doc = root.ownerDocument;
    const box = node(doc, 'div', undefined, 'core-loi'); box.setAttribute('role', 'alert');
    // Câu máy chủ (phong bì lỗi phẳng) hiện nguyên; mã và mã tra cứu chỉ ở Chi tiết hỗ trợ.
    box.append(node(doc, 'p', typeof error?.thong_diep === 'string' && error.thong_diep
      ? error.thong_diep
      : error?.status === 409 && error?.ma === 'XUNG_DOT_PHIEN_BAN'
        ? 'Dữ liệu đã thay đổi. Bản nháp được giữ. Hãy tải bản mới để đối chiếu trước khi lưu.'
        : 'Chưa hoàn tất yêu cầu. Hãy tải lại dữ liệu hoặc kiểm tra phiên đăng nhập.'));
    if (error?.request_id || error?.ma) {
      const details = node(doc, 'details'); details.append(node(doc, 'summary', 'Chi tiết hỗ trợ'));
      if (error?.ma) details.append(node(doc, 'p', `Mã lỗi: ${error.ma}`));
      if (error?.request_id) details.append(node(doc, 'p', `Mã tra cứu: ${error.request_id}`));
      box.append(details);
    }
    root.replaceChildren(box);
  }

  return { tao, hang_cho: { thong_diep: thongDiepHangCho, du_lieu_gia: viecGia },
    khung: { dung: dungKhung, trang_chu: dungTrangChu, nhan_demo: nhanDemo }, thong_bao: { loi: thongBaoLoi } };
});
