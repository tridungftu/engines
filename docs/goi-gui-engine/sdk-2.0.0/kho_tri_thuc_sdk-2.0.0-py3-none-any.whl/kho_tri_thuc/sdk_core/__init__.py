"""Namespace tương thích của wheel SDK, giữ chung module và DTO."""
import importlib
import importlib.abc
import importlib.util
import sys

_GOC = 'kho_tri_thuc_sdk'
_CU = __name__
_MODULE = frozenset(('_core', '_core.mtq', '_core.phien', '_core.su_kien', '_core.tai_lieu', '_core.tiep_nhan', '_core.viec', 'bootstrap', 'cong_bo', 'danh_muc_tham_so', 'danh_tinh', 'dich_vu', 'du_lieu_rieng', 'engine', 'engine_http', 'engine_legacy', 'engine_module', 'giao_dich', 'ho_so_engine', 'kenh_core', 'kenh_khung', 'kiem_toan', 'ma_hoa', 'module_runtime', 'ngu_canh', 'nhan_su_kien', 'primitives', 'quy_trinh', 'tai_lieu', 'tep', 'thu', 'tien_trinh_phu', 'viec', 'xlsx_mini'))


class _Bridge(importlib.abc.MetaPathFinder, importlib.abc.Loader):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.startswith(_CU + '.') and fullname[len(_CU) + 1:] in _MODULE:
            ten = _GOC + fullname[len(_CU):]
            spec = importlib.util.find_spec(ten)
            return importlib.util.spec_from_loader(
                fullname, self, is_package=spec.submodule_search_locations is not None)
        return None

    def create_module(self, spec):
        return None

    def exec_module(self, module):
        ten = _GOC + module.__name__[len(_CU):]
        sys.modules[module.__name__] = importlib.import_module(ten)


_sdk = importlib.import_module(_GOC)
# Đăng ký các module đã nạp trước để giữ cả façade (vd dịch vụ viec).
for _ten in _MODULE:
    if _GOC + '.' + _ten in sys.modules:
        sys.modules[_CU + '.' + _ten] = sys.modules[_GOC + '.' + _ten]
sys.meta_path.insert(0, _Bridge())
sys.modules[_CU] = _sdk
