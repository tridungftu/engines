"""Core giả trong bộ nhớ để engine tự thử, không cần Core thật (lát L2.1).

    from kho_tri_thuc_sdk.thu import CoreGia
    kq = CoreGia().chay_thu(app, "<nhom>.<viec>@1", {"loai": "van_ban", "van_ban": "..."})
    kq["trang_thai"], kq["ket_qua"], kq["loi"]

CoreGia làm đúng bộ thao tác hợp đồng (c) c.2: nhận việc (engine chỉ thấy việc
của năng lực mình), đọc đầu vào, đọc tệp, tải tệp ra, gia hạn kèm cờ hủy, tiến
độ, nộp kết quả, kết thúc. Lệnh ghi phải có Idempotency-Key; cùng khóa thì trả
kết quả lần đầu, không ghi trùng. "Xong" chỉ nhận khi kết quả đã nộp.

MayChuGia bọc CoreGia thành máy chủ HTTP loopback cùng đường dẫn
/api/v1/engine/… để thử đường HTTP (kể cả chạy engine thành tiến trình riêng).

Chạy mọi ví dụ chay_thu_demo của một gói engine:
    python -m kho_tri_thuc_sdk.thu <thư mục gói>
Chỉ dùng dữ liệu DEMO.
"""

from __future__ import annotations

from collections import Counter
import copy
from datetime import date, datetime, timedelta, timezone
from decimal import Decimal, InvalidOperation
import http.server
import importlib
import itertools
import json
import mimetypes
from pathlib import Path
import re
import sys
import threading
import time
import urllib.parse
import uuid

from .engine import (DuongTruyen, Engine, LoiDuongTruyen, LoiPhieu, NganXungDot, TRANG_THAI_KET_THUC,
                     TEP_TOI_DA_MAC_DINH_MIB, doc_phieu)


__all__ = ('CoreGia', 'MayChuGia', 'main')

_GIO_VN = timezone(timedelta(hours=7))
_MIME_THEO_DUOI = {'.txt': 'text/plain', '.csv': 'text/csv', '.json': 'application/json',
                   '.pdf': 'application/pdf', '.png': 'image/png', '.jpg': 'image/jpeg',
                   '.jpeg': 'image/jpeg', '.xml': 'application/xml'}


def _loi(ma, thong_diep, status, thu_lai=False):
    if ma == 'NGAN_XUNG_DOT':
        return NganXungDot(thong_diep)
    return LoiDuongTruyen(ma, thong_diep, http_status=status, thu_lai_duoc=thu_lai)


def _mime(ten):
    return (_MIME_THEO_DUOI.get(Path(ten).suffix.lower())
            or mimetypes.guess_type(ten)[0] or 'application/octet-stream')


class CoreGia:
    """Core giả trong bộ nhớ, an toàn khi nhiều luồng gọi."""

    def __init__(self, phieu=None, *, thu_muc_goi=None):
        self._lock = threading.RLock()
        self._viec = {}
        self._hang = []
        self._tep = {}
        self._idem = {}
        self._engine = {}
        self._mat_xac_nhan = Counter()
        self._dem = itertools.count(1)
        self.so_lan_ghi = Counter()   # số lần Core thật sự ghi, theo thao tác
        self.nhat_ky = []             # (thao_tac, ma_engine, viec_id, khoa) mỗi lời gọi ghi
        self._phieu = {}
        self._ngan = {}
        self._cau_hinh = {}
        self._schema_cau_hinh = {}
        self._xung_dot_ngan = Counter()
        self._idem_ngan = {}
        self._giao_quy_trinh = {}
        if phieu is not None:
            self.nap_engine(phieu, thu_muc_goi=thu_muc_goi)

    def nap_engine(self, app, *, thu_muc_goi=None):
        """Nạp khai báo của gói thử; không suy cấu trúc từ dữ liệu gửi lên."""
        if isinstance(app, Engine):
            thu_muc_goi = app.thu_muc_goi
            app = app.phieu
        elif isinstance(app, (str, Path)):
            tep = Path(app)
            tep = tep / 'engine.json' if tep.is_dir() else tep
            thu_muc_goi = tep.parent
            app = doc_phieu(tep)
        with self._lock:
            ma = app['ma']
            self._phieu[ma] = copy.deepcopy(app)
            if app.get('cau_hinh'):
                tep = Path(thu_muc_goi or '.') / app['cau_hinh']['schema']
                self._schema_cau_hinh[ma] = json.loads(tep.read_text(encoding='utf-8-sig'))
            cu = self._cau_hinh.get(ma, dict(cau_hinh={}, phien_ban_cau_hinh=1))
            self._cau_hinh[ma] = dict(cau_hinh=self._kiem_cau_hinh(ma, cu['cau_hinh']),
                                      phien_ban_cau_hinh=cu['phien_ban_cau_hinh'])

    def _kiem_cau_hinh(self, ma, gia_tri):
        # Cùng bộ JSON Schema với Core; import trễ, gói cũ không cần phụ thuộc này.
        schema = self._schema_cau_hinh.get(ma)
        if not isinstance(gia_tri, dict):
            raise _loi('NGAN_DU_LIEU_SAI', 'Cấu hình chưa đúng định dạng.', 422)
        kq = copy.deepcopy(gia_tri)
        if schema is not None:
            def mac_dinh(s, v):
                if isinstance(v, dict):
                    for k, con in s.get('properties', {}).items():
                        if k not in v and 'default' in con:
                            v[k] = copy.deepcopy(con['default'])
                        if k in v:
                            mac_dinh(con, v[k])
                elif isinstance(v, list):
                    for con in v:
                        mac_dinh(s.get('items', {}), con)
            mac_dinh(schema, kq)
            try:
                import jsonschema
            except ImportError:
                # SDK chỉ dùng thư viện chuẩn: thiếu jsonschema thì kiểm tối giản
                # (kiểu, bắt buộc, khóa lạ khi additionalProperties=false). Core thật kiểm đủ.
                if not _kiem_toi_gian(kq, schema):
                    raise _loi('NGAN_DU_LIEU_SAI', 'Cấu hình chưa đúng khai báo.', 422) from None
                return kq
            try:
                jsonschema.validate(kq, schema)
            except jsonschema.ValidationError:
                raise _loi('NGAN_DU_LIEU_SAI', 'Cấu hình chưa đúng khai báo.', 422) from None
        return kq

    def dat_cau_hinh(self, ma_engine, gia_tri):
        with self._lock:
            kq = self._kiem_cau_hinh(ma_engine, gia_tri)
            pb = self._cau_hinh.get(ma_engine, {}).get('phien_ban_cau_hinh', 0) + 1
            self._cau_hinh[ma_engine] = dict(cau_hinh=kq, phien_ban_cau_hinh=pb)

    def gay_xung_dot_ngan(self, bang, so_lan=1):
        with self._lock:
            self._xung_dot_ngan[bang] += so_lan

    def xem_ngan(self, ma_engine, bang):
        with self._lock:
            return copy.deepcopy(self._ngan.get((ma_engine, bang), []))

    def _doc_cau_hinh(self, ma):
        with self._lock:
            return copy.deepcopy(self._cau_hinh.get(ma, dict(cau_hinh={}, phien_ban_cau_hinh=0)))

    def _hang_cho(self, ma):
        with self._lock:
            nl = self._engine.get(ma, {}).get('nang_luc', [])
            return dict(so_viec_cho=sum(v['trang_thai'] == 'CHO' and v['nang_luc'] in nl
                                       for v in self._viec.values()),
                        so_viec_dang_chay=sum(v['trang_thai'] == 'DANG_CHAY' and v['ma_engine'] == ma
                                               for v in self._viec.values()))

    @staticmethod
    def _sai_ngan():
        return _loi('NGAN_DU_LIEU_SAI', 'Dữ liệu ngăn chưa đúng khai báo.', 422)

    def _bang_ngan(self, ma, bang, viec_id, instance):
        kb = next((b for b in self._phieu.get(ma, {}).get('ngan_du_lieu', [])
                   if b['bang'] == bang), None)
        if kb is None:
            raise _loi('NGAN_KHONG_CO_BANG', 'Ngăn dữ liệu chưa được khai báo.', 404)
        pn = None
        if viec_id is not None:
            v = self._viec.get(viec_id)
            if (v is None or v['ma_engine'] != ma or v.get('instance') != instance
                    or v['trang_thai'] != 'DANG_CHAY'
                    or datetime.now(_GIO_VN) >= datetime.fromisoformat(v['han_giu'])):
                raise _loi('KHONG_DU_QUYEN', 'Không có quyền dùng dữ liệu của việc này.', 403)
            pn = v['phap_nhan_id']
        if kb['pham_vi'] == 'phap_nhan' and (viec_id is None or pn is None):
            raise _loi('NGAN_CAN_VIEC', 'Cần nhận việc trước khi dùng ngăn này.', 422)
        return kb, pn

    def _gia_tri_ngan(self, kb, data, *, tao=False, khoa=False):
        if not isinstance(data, dict) or (khoa and not data):
            raise self._sai_ngan()
        truong = {t['ma']: t for t in kb['truong']}
        chuan = {'id', 'phap_nhan_id'} if khoa else set()
        tien_te = {t['ma'] + '_tien_te' for t in kb['truong'] if t['kieu'] == 'so_tien'}
        if set(data) - truong.keys() - chuan - tien_te:
            raise self._sai_ngan()
        kq = copy.deepcopy(data)
        for ma, t in truong.items():
            if tao and t.get('bat_buoc') and data.get(ma) is None:
                raise self._sai_ngan()
            v = data.get(ma)
            if v is None:
                continue
            kieu = t['kieu']
            try:
                if kieu in ('so', 'so_tien'):
                    if isinstance(v, bool) or not isinstance(v, (str, int, float)):
                        raise ValueError
                    so = Decimal(str(v))
                    if not so.is_finite():
                        raise ValueError
                    if kieu == 'so_tien':
                        if so != so.quantize(Decimal('0.01')) or abs(so) >= Decimal('1e18'):
                            raise ValueError
                        so = so.quantize(Decimal('0.01'))
                    kq[ma] = format(so, 'f')
                elif kieu == 'van_ban' and not isinstance(v, str):
                    raise ValueError
                elif kieu == 'co_khong' and type(v) is not bool:
                    raise ValueError
                elif kieu == 'ngay':
                    if not isinstance(v, str) or not re.fullmatch(r'\d{4}-\d{2}-\d{2}', v):
                        raise ValueError
                    date.fromisoformat(v)
                elif kieu == 'thoi_diem':
                    if not isinstance(v, str) or datetime.fromisoformat(v).utcoffset() is None:
                        raise ValueError
            except (ValueError, TypeError, InvalidOperation, OverflowError):
                raise self._sai_ngan() from None
        for ma in tien_te & data.keys():
            if not isinstance(data[ma], str) or not re.fullmatch('[A-Z]{3}', data[ma]):
                raise self._sai_ngan()
        return kq

    def _khoa_ngan(self, kb, khoa, pn, *, lay_hoac_tao=False):
        khoa = self._gia_tri_ngan(kb, khoa, khoa=True)
        # Không tin pháp nhân do engine gửi; phạm vi luôn từ việc đang giữ.
        if kb['pham_vi'] == 'phap_nhan':
            khoa['phap_nhan_id'] = pn
        if lay_hoac_tao:
            truong = set(khoa) - {'phap_nhan_id'}
            cac = [kb.get('khoa') or ['id']] + kb.get('duy_nhat', [])
            if not any(truong == set(c) - {'phap_nhan_id'} for c in cac):
                raise self._sai_ngan()
        return khoa

    @staticmethod
    def _khop_ngan(kb, d, loc):
        truong = {t['ma']: t['kieu'] for t in kb['truong']}
        def chuan(k, v):
            if v is not None and truong.get(k) in ('so', 'so_tien'):
                return Decimal(str(v))
            if v is not None and truong.get(k) == 'thoi_diem':
                return datetime.fromisoformat(v)
            return v
        return all(chuan(k, d.get(k)) == chuan(k, v) for k, v in loc.items())

    @staticmethod
    def _con_han(d):
        return d.get('het_han_luc') is None or datetime.fromisoformat(d['het_han_luc']) > datetime.now(_GIO_VN)

    @staticmethod
    def _che_ngan(kb, d):
        kq = copy.deepcopy(d)
        kq.pop('viec_id', None)
        for t in kb['truong']:
            kq.setdefault(t['ma'], None)
            if t.get('bi_mat'):
                kq[t['ma']] = None
                kq[t['ma'] + '_da_ma_hoa'] = d.get(t['ma']) is not None
        return kq

    def _ngan_doc(self, ma, instance, bang, khoa, *, viec_id=None, gom_het_han=False):
        with self._lock:
            if type(gom_het_han) is not bool:
                raise self._sai_ngan()
            kb, pn = self._bang_ngan(ma, bang, viec_id, instance)
            khoa = self._khoa_ngan(kb, khoa, pn)
            d = next((d for d in self._ngan.get((ma, bang), []) if self._khop_ngan(kb, d, khoa)
                      and (gom_het_han or self._con_han(d))), None)
            return dict(ban_ghi=None if d is None else self._che_ngan(kb, d),
                        row_version=None if d is None else d['row_version'])

    def _ngan_tim(self, ma, instance, bang, *, loc=None, sap_xep=None, gioi_han=100,
                  tiep=None, gom_het_han=False, viec_id=None):
        with self._lock:
            kb, pn = self._bang_ngan(ma, bang, viec_id, instance)
            loc = self._gia_tri_ngan(kb, loc or {}, khoa=bool(loc))
            if type(gom_het_han) is not bool or (sap_xep is not None and (
                    not isinstance(sap_xep, list) or any(not isinstance(sx, dict)
                    or set(sx) - {'truong', 'giam'} for sx in sap_xep))):
                raise self._sai_ngan()
            if kb['pham_vi'] == 'phap_nhan':
                loc['phap_nhan_id'] = pn
            if type(gioi_han) is not int or not 1 <= gioi_han <= 500:
                raise self._sai_ngan()
            ds = [d for d in self._ngan.get((ma, bang), []) if self._khop_ngan(kb, d, loc)
                  and (gom_het_han or self._con_han(d))]
            ds.sort(key=lambda d: d['id'])
            for sx in reversed(sap_xep or []):
                t = next((t for t in kb['truong'] if t['ma'] == sx.get('truong')), None)
                if t is None or t.get('bi_mat') or type(sx.get('giam', False)) is not bool:
                    raise self._sai_ngan()
                k = t['ma']
                def thu_tu(d):
                    v = d.get(k)
                    if v is not None and t['kieu'] in ('so', 'so_tien'):
                        v = Decimal(v)
                    return (v is None, v)
                ds.sort(key=thu_tu, reverse=sx.get('giam', False))
            try:
                dau = 0 if tiep is None else int(tiep)
                if dau < 0:
                    raise ValueError
            except (ValueError, TypeError):
                raise self._sai_ngan() from None
            cuoi = dau + gioi_han
            return dict(danh_sach=[self._che_ngan(kb, d) for d in ds[dau:cuoi]],
                        tiep=str(cuoi) if cuoi < len(ds) else None)

    def _ngan_ghi_lo(self, ma, instance, lenh, khoa, *, viec_id=None):
        with self._lock:
            if not isinstance(lenh, list) or not lenh:
                raise self._sai_ngan()
            if len(lenh) > 100:
                raise _loi('NGAN_LO_QUA_LON', 'Mỗi lô chỉ nhận tối đa 100 lệnh.', 422)
            if not isinstance(khoa, str) or not 8 <= len(khoa) <= 200:
                raise self._sai_ngan()
            for l in lenh:
                if not isinstance(l, dict):
                    raise self._sai_ngan()
                self._bang_ngan(ma, l.get('bang'), viec_id, instance)
            try:
                than = json.dumps(lenh, sort_keys=True, ensure_ascii=False, allow_nan=False)
            except (ValueError, TypeError):
                raise self._sai_ngan() from None
            idem = (ma, khoa)
            self.nhat_ky.append(('ngan', ma, viec_id, khoa))
            if idem in self._idem_ngan:
                cu, kq = self._idem_ngan[idem]
                if cu != than:
                    raise _loi('KHOA_CHONG_TRUNG_KHAC_NOI_DUNG', 'Khóa đã dùng cho nội dung khác.', 409)
                return copy.deepcopy(kq)
            ds = copy.deepcopy(self._ngan)
            kq = []
            for l in lenh:
                bang, tt = l.get('bang'), l.get('thao_tac')
                kb, pn = self._bang_ngan(ma, bang, viec_id, instance)
                if tt not in ('them', 'sua', 'lay_hoac_tao'):
                    raise _loi('NGAN_KHONG_XOA', 'Không được xóa dữ liệu trong ngăn.', 422)
                if self._xung_dot_ngan[bang] > 0:
                    self._xung_dot_ngan[bang] -= 1
                    raise NganXungDot()
                dong = ds.setdefault((ma, bang), [])
                gt = self._gia_tri_ngan(kb, l.get('gia_tri', {}))
                d = None
                if tt != 'them':
                    loc = self._khoa_ngan(kb, l.get('khoa'), pn, lay_hoac_tao=tt == 'lay_hoac_tao')
                    d = next((d for d in dong if self._khop_ngan(kb, d, loc)), None)
                da_tao = d is None
                if tt == 'sua':
                    if d is None:
                        raise _loi('NGAN_KHONG_THAY', 'Không thấy bản ghi cần sửa.', 404)
                    if type(l.get('row_version')) is not int:
                        raise self._sai_ngan()
                    if l['row_version'] != d['row_version']:
                        raise NganXungDot()
                if tt == 'lay_hoac_tao' and d is not None:
                    kq.append(dict(id=d['id'], row_version=d['row_version'], da_tao=False))
                    continue
                moi = copy.deepcopy(d or {})
                if tt == 'lay_hoac_tao':
                    moi.update(loc)
                moi.update(gt)
                moi['phap_nhan_id'] = pn if kb['pham_vi'] == 'phap_nhan' else None
                self._gia_tri_ngan(kb, {k: v for k, v in moi.items()
                                      if k not in ('id', 'phap_nhan_id', 'row_version', 'tao_luc',
                                                   'sua_luc', 'het_han_luc', 'viec_id')}, tao=True)
                for unique in kb.get('duy_nhat', []):
                    if all(moi.get(k) is not None for k in unique) and any(
                            cu is not d and self._khop_ngan(kb, cu, {k: moi.get(k) for k in unique})
                            for cu in dong):
                        raise NganXungDot()
                now = datetime.now(_GIO_VN)
                moi.update(id=moi.get('id', str(uuid.uuid4())),
                           row_version=1 if da_tao else d['row_version'] + 1,
                           tao_luc=moi.get('tao_luc', now.isoformat()),
                           sua_luc=None if da_tao else now.isoformat(), viec_id=viec_id,
                           het_han_luc=(now + timedelta(days=kb['giu_toi_da_ngay'])).isoformat()
                           if kb.get('giu_toi_da_ngay') is not None else None)
                if d is not None:
                    d.clear()
                    d.update(moi)
                else:
                    dong.append(moi)
                kq.append(dict(id=moi['id'], row_version=moi['row_version'], da_tao=da_tao))
            self._ngan = ds
            result = {'ket_qua': kq}
            self._idem_ngan[idem] = (than, copy.deepcopy(result))
            self.so_lan_ghi['ngan'] += 1
            if self._mat_xac_nhan['ngan'] > 0:
                self._mat_xac_nhan['ngan'] -= 1
                raise _loi('MAT_PHAN_HOI', 'Mất phản hồi (giả lập).', 503, True)
            return result

    # -- phía "người dùng/Core" ------------------------------------------
    def them_tep(self, ten, du_lieu, mime=None):
        """Đưa một tệp DEMO vào kho; trả đối tượng tệp cho phong bì."""
        with self._lock:
            tep_id = f'tep-{next(self._dem)}'
            self._tep[tep_id] = (ten, mime or _mime(ten), bytes(du_lieu))
            return {'tep_id': tep_id, 'ten': ten, 'mime': mime or _mime(ten),
                    'kich_thuoc': len(du_lieu)}

    def doc_tep(self, tep_id):
        with self._lock:
            return self._tep[tep_id][2]

    def giao_viec(self, nang_luc, dau_vao, tham_so=None, *, buoc=1,
                  phap_nhan_id='pn-demo', gui_kem_dau_vao=True):
        """Xếp một việc vào hàng; trả mã việc."""
        with self._lock:
            viec_id = f'viec-{next(self._dem)}'
            self._viec[viec_id] = dict(
                id=viec_id, nang_luc=nang_luc, dau_vao=copy.deepcopy(dau_vao),
                tham_so=copy.deepcopy(tham_so or {}), buoc=buoc, phap_nhan_id=phap_nhan_id,
                gui_kem=gui_kem_dau_vao, trang_thai='CHO', ma_engine=None, co_huy=False,
                lan_thu=0, ket_qua=None, loi=None, ma_tuong_quan=None, tien_do=[])
            self._hang.append(viec_id)
            return viec_id

    def huy(self, viec_id):
        """Người dùng bấm Hủy: việc chờ thì hủy ngay, đang chạy thì báo cờ `huy`."""
        with self._lock:
            v = self._viec[viec_id]
            if v['trang_thai'] == 'CHO':
                v['trang_thai'] = 'HUY'
                self._hang.remove(viec_id)
            elif v['trang_thai'] == 'DANG_CHAY':
                v['co_huy'] = True

    def xem(self, viec_id):
        with self._lock:
            v = self._viec[viec_id]
            return copy.deepcopy({k: v[k] for k in (
                'id', 'nang_luc', 'trang_thai', 'ket_qua', 'loi', 'ma_tuong_quan',
                'tien_do', 'lan_thu', 'ma_engine')})

    def phat_su_kien_quy_trinh(self, viec_id, handlers, sdk, *, viec_quy_trinh_id=None,
                              tep_nut=None, ghep=None):
        """Phát xong/loi của việc thử tới hàm nhận module, không chạy lại việc.

        viec_quy_trinh_id là UUID module đã lưu; mặc định UUID ổn định từ mã việc giả.
        Thiếu hàm nhận vẫn ghi đã nhận; lỗi hàm nhận cho gọi lại tối đa 5 lần.
        Mỗi lời gọi thử giao một lần, không tự tạo vòng giao hay giãn cách thời gian thật.
        """
        from .chay_module import LoiChayModule, xu_ly_su_kien_quy_trinh
        with self._lock:
            v = self.xem(viec_id)
            if v['trang_thai'] not in ('XONG', 'LOI'):
                raise LoiChayModule('SDK_SU_KIEN_KHONG_HOP_LE')
            vid = str(uuid.UUID(str(viec_quy_trinh_id))) if viec_quy_trinh_id is not None else str(
                uuid.uuid5(uuid.NAMESPACE_URL, 'quy-trinh:' + viec_id))
            ten = 'loi' if v['trang_thai'] == 'LOI' else 'xong'
            khoa = 'quy-trinh-' + ten + ':' + vid
            dem, da_nhan = self._giao_quy_trinh.get(khoa, (0, False))
            if da_nhan or dem >= 5:
                return dict(da_nhan=da_nhan, viec_id=vid)
            self._giao_quy_trinh[khoa] = (dem + 1, False)
            sk = dict(su_kien='quy_trinh.' + ten, id=khoa, viec_id=vid)
            if ten == 'loi':
                ma = (v.get('loi') or {}).get('ma')
                sk.update(ma_loi=ma if isinstance(ma, str) and re.fullmatch(r'[A-Z][A-Z0-9_]{0,79}', ma)
                          else 'LOI_NOI_BO',
                          thong_diep='Không xử lý được yêu cầu. Hãy liên hệ người quản trị.')
            xu_ly_su_kien_quy_trinh(sk, handlers, sdk, doc_ket_qua=lambda _: dict(
                viec_id=vid, tep_nut=copy.deepcopy(tep_nut), ghep=copy.deepcopy(ghep or [])))
            self._giao_quy_trinh[khoa] = (dem + 1, True)
            return dict(da_nhan=True, viec_id=vid)

    def gay_mat_xac_nhan(self, thao_tac, so_lan=1):
        """Thử: `so_lan` lời gọi `thao_tac` kế tiếp (ket_qua, ket_thuc, tep) được
        Core ghi xong nhưng phản hồi mất trên đường về."""
        with self._lock:
            self._mat_xac_nhan[thao_tac] += so_lan

    def duong_truyen(self, ma_engine, instance=None):
        return _DuongGia(self, ma_engine, instance or f'gia-{uuid.uuid4().hex[:8]}')

    def chay(self, app, **tuy_chon):
        """Cho engine làm hết việc đang chờ của nó rồi dừng."""
        tuy_chon.setdefault('khoang_gia_han', 0.01)
        tuy_chon.setdefault('cho_gui_lai_giay', 0)
        app.chay(self.duong_truyen(app.ma), dung_khi_het_viec=True, **tuy_chon)

    def chay_thu(self, app, nang_luc, dau_vao, tham_so=None, **tuy_chon):
        """Giao một việc, cho engine chạy, trả trạng thái và kết quả."""
        viec_id = self.giao_viec(nang_luc, dau_vao, tham_so)
        self.chay(app, **tuy_chon)
        return self.xem(viec_id)

    def chay_thu_demo(self, app, thu_muc_goi=None):
        """Chạy mọi ví dụ `chay_thu_demo` trong phiếu; `tep_demo` đọc trong gói."""
        goc = Path(thu_muc_goi or app.thu_muc_goi or '.')
        ket_qua = []
        for vd in app.phieu.get('chay_thu_demo', []):
            dau_vao = copy.deepcopy(vd['dau_vao'])
            if dau_vao.get('loai') == 'tep' and 'tep_demo' in dau_vao:
                tep = goc / dau_vao['tep_demo']
                dau_vao = {'loai': 'tep', 'tep': self.them_tep(tep.name, tep.read_bytes())}
            kq = self.chay_thu(app, vd['nang_luc'], dau_vao, vd.get('tham_so'))
            ket_qua.append({'ten': vd['ten'], **kq})
        return ket_qua

    # -- phía engine (qua _DuongGia) --------------------------------------
    def _cua_engine(self, ma_engine, viec_id):
        v = self._viec.get(viec_id)
        if v is None or v['ma_engine'] != ma_engine:
            raise _loi('KHONG_TIM_THAY', 'Không thấy việc.', 404)
        return v

    def _dang_giu(self, ma_engine, viec_id):
        v = self._cua_engine(ma_engine, viec_id)
        if v['trang_thai'] != 'DANG_CHAY':
            raise _loi('MAT_LEASE', 'Việc không còn do engine này giữ.', 409)
        if datetime.now(_GIO_VN) >= datetime.fromisoformat(v['han_giu']):
            raise _loi('MAT_LEASE', 'Đã hết thời hạn giữ việc.', 409)
        return v

    def _ghi(self, thao_tac, ma_engine, viec_id, khoa, lam):
        """Lệnh ghi có Idempotency-Key: cùng khóa trả kết quả lần đầu."""
        with self._lock:
            self.nhat_ky.append((thao_tac, ma_engine, viec_id, khoa))
            if not isinstance(khoa, str) or not 8 <= len(khoa) <= 200:
                raise _loi('YEU_CAU_KHONG_HOP_LE', 'Lệnh ghi thiếu Idempotency-Key.', 400)
            k = (ma_engine, thao_tac, viec_id, khoa)
            if k in self._idem:
                kq = copy.deepcopy(self._idem[k])
            else:
                kq = lam()
                self.so_lan_ghi[thao_tac] += 1
                self._idem[k] = copy.deepcopy(kq)
            if self._mat_xac_nhan[thao_tac] > 0:
                self._mat_xac_nhan[thao_tac] -= 1
                raise _loi('MAT_PHAN_HOI', 'Mất phản hồi (giả lập).', 503, True)
            return kq

    def _san_sang(self, ma, instance, phien_ban, nang_luc):
        with self._lock:
            self._engine[ma] = dict(instance=instance, phien_ban=phien_ban,
                                    nang_luc=list(nang_luc))
            return self._doc_cau_hinh(ma)

    def _nhan_viec(self, ma, instance=None):
        with self._lock:
            dk = self._engine.get(ma)
            if dk is None:
                raise _loi('CHUA_SAN_SANG', 'Engine chưa báo sẵn sàng.', 409)
            for viec_id in self._hang:
                v = self._viec[viec_id]
                if v['nang_luc'] in dk['nang_luc']:
                    self._hang.remove(viec_id)
                    v.update(trang_thai='DANG_CHAY', ma_engine=ma, lan_thu=v['lan_thu'] + 1,
                             han_giu=self._han(60), instance=instance or dk['instance'])
                    viec = dict(id=viec_id, nang_luc=v['nang_luc'],
                                tham_so=copy.deepcopy(v['tham_so']),
                                ngu_canh={'viec_id': viec_id, 'buoc': v['buoc'],
                                          'phap_nhan_id': v['phap_nhan_id']},
                                han_giu=v['han_giu'], lan_thu=v['lan_thu'])
                    if ma in self._cau_hinh:
                        viec['phien_ban_cau_hinh'] = self._cau_hinh[ma]['phien_ban_cau_hinh']
                    if v['gui_kem']:
                        viec['dau_vao'] = copy.deepcopy(v['dau_vao'])
                    return viec
            return None

    @staticmethod
    def _han(giay):
        return (datetime.now(_GIO_VN) + timedelta(seconds=giay)).isoformat(timespec='seconds')

    def _doc_dau_vao(self, ma, viec_id):
        with self._lock:
            return copy.deepcopy(self._dang_giu(ma, viec_id)['dau_vao'])

    def _mo_tep(self, ma, viec_id, tep_id, toi_da_byte):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            # Engine chỉ đọc được tệp nằm trong đầu vào việc của mình.
            if tep_id not in self._tep or json.dumps(tep_id) not in json.dumps(v['dau_vao']):
                raise _loi('KHONG_TIM_THAY', 'Không thấy tệp.', 404)
            du_lieu = self._tep[tep_id][2]
            if len(du_lieu) > min(toi_da_byte, TEP_TOI_DA_MAC_DINH_MIB * 1048576):
                raise _loi('VUOT_GIOI_HAN_KICH_THUOC', 'Tệp lớn quá giới hạn.', 413)
            return du_lieu

    def _tai_tep_ra(self, ma, viec_id, ten, du_lieu, mime, khoa):
        with self._lock:
            self._dang_giu(ma, viec_id)

            def lam():
                return {'tep_id': self.them_tep(ten, du_lieu, mime)['tep_id']}
            return self._ghi('tep', ma, viec_id, khoa, lam)

    def _gia_han(self, ma, viec_id, han_giu_giay):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            v['han_giu'] = self._han(han_giu_giay)
            return {'han_giu': v['han_giu'], 'huy': v['co_huy']}

    def _tien_do(self, ma, viec_id, phan_tram, cau):
        with self._lock:
            v = self._dang_giu(ma, viec_id)
            v['tien_do'].append((phan_tram, cau))
            return {'huy': v['co_huy']}

    def _nop_ket_qua(self, ma, viec_id, phong_bi, khoa):
        with self._lock:
            k = (ma, 'ket_qua', viec_id, khoa)
            if k not in self._idem:
                self._dang_giu(ma, viec_id)

            def lam():
                self._viec[viec_id]['ket_qua'] = copy.deepcopy(phong_bi)
                return {'da_luu': True}
            return self._ghi('ket_qua', ma, viec_id, khoa, lam)

    def _ket_thuc(self, ma, viec_id, than, khoa):
        with self._lock:
            k = (ma, 'ket_thuc', viec_id, khoa)
            if k not in self._idem:
                v = self._dang_giu(ma, viec_id)
                tt = than.get('trang_thai') if isinstance(than, dict) else None
                if tt not in TRANG_THAI_KET_THUC:
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Trạng thái kết thúc không hợp lệ.', 400)
                if tt == 'XONG' and v['ket_qua'] is None:
                    raise _loi('XUNG_DOT', 'Chưa nộp kết quả thì chưa được báo xong.', 409)
                loi = than.get('loi')
                if tt == 'LOI' and not (isinstance(loi, dict)
                                        and {'ma', 'thong_diep', 'thu_lai_duoc'} <= set(loi)):
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Báo lỗi thiếu phong bì lỗi.', 400)
                if tt == 'CHUA_RO' and not than.get('ma_tuong_quan'):
                    raise _loi('YEU_CAU_KHONG_HOP_LE', 'Báo "chưa rõ" thiếu mã tương quan.', 400)

            def lam():
                v = self._viec[viec_id]
                v.update(trang_thai=than['trang_thai'], loi=copy.deepcopy(than.get('loi')),
                         ma_tuong_quan=than.get('ma_tuong_quan'))
                if than['trang_thai'] != 'XONG':
                    v['ket_qua'] = None
                return {}
            return self._ghi('ket_thuc', ma, viec_id, khoa, lam)


class _DuongGia(DuongTruyen):
    """Đường truyền của một engine tới CoreGia (không qua mạng)."""

    def __init__(self, core, ma_engine, instance):
        self._core, self.ma_engine, self.instance = core, ma_engine, instance

    def san_sang(self, phien_ban, nang_luc):
        kq = self._core._san_sang(self.ma_engine, self.instance, phien_ban, nang_luc)
        self.phien_ban_cau_hinh = kq['phien_ban_cau_hinh']
        return kq['cau_hinh']

    def chuan_bi(self, phieu, thu_muc_goi=None):
        self._core.nap_engine(phieu, thu_muc_goi=thu_muc_goi)

    def ngan_doc(self, bang, khoa, **kw):
        return self._core._ngan_doc(self.ma_engine, self.instance, bang, khoa, **kw)

    def ngan_tim(self, bang, **kw):
        return self._core._ngan_tim(self.ma_engine, self.instance, bang, **kw)

    def ngan_ghi_lo(self, lenh, khoa, **kw):
        return self._core._ngan_ghi_lo(self.ma_engine, self.instance, lenh, khoa, **kw)

    def doc_cau_hinh(self):
        return self._core._doc_cau_hinh(self.ma_engine)

    def hang_cho(self):
        return self._core._hang_cho(self.ma_engine)

    def nhan_viec(self, cho_toi_da_giay):
        # Core giả chờ tối đa 1 giây để engine dừng (app.dung) nhanh khi thử.
        han = time.monotonic() + max(0, min(cho_toi_da_giay, 1))
        while True:
            viec = self._core._nhan_viec(self.ma_engine, self.instance)
            if viec is not None or time.monotonic() >= han:
                return viec
            time.sleep(0.02)

    def doc_dau_vao(self, viec_id):
        return self._core._doc_dau_vao(self.ma_engine, viec_id)

    def mo_tep(self, viec_id, tep_id, toi_da_byte):
        return self._core._mo_tep(self.ma_engine, viec_id, tep_id, toi_da_byte)

    def tai_tep_ra(self, viec_id, ten, du_lieu, mime, khoa):
        return self._core._tai_tep_ra(self.ma_engine, viec_id, ten, du_lieu, mime, khoa)

    def gia_han(self, viec_id, han_giu_giay):
        return self._core._gia_han(self.ma_engine, viec_id, han_giu_giay)

    def tien_do(self, viec_id, phan_tram, cau):
        return self._core._tien_do(self.ma_engine, viec_id, phan_tram, cau)

    def nop_ket_qua(self, viec_id, phong_bi, khoa):
        return self._core._nop_ket_qua(self.ma_engine, viec_id, phong_bi, khoa)

    def ket_thuc(self, viec_id, than, khoa):
        return self._core._ket_thuc(self.ma_engine, viec_id, than, khoa)


# ---------------------------------------------------------------------------
# Máy chủ HTTP giả: cùng đường dẫn và xác thực như hợp đồng (c), chỉ loopback.

_DUONG_ENGINE = re.compile(r'/api/v1/engine/([a-z0-9_]+)/(san-sang|viec/nhan)')
_DUONG_NGAN = re.compile(r'/api/v1/engine/([a-z0-9_]+)/(ngan/ghi-lo|ngan/[^/]+/(?:doc|tim)|cau-hinh|hang-cho)')
_DUONG_VIEC = re.compile(r'/api/v1/engine/viec/([^/]+)/(dau-vao|tep|tep/[^/]+|gia-han|'
                         r'tien-do|ket-qua|ket-thuc)')


class MayChuGia:
    """`with MayChuGia(core, {"<ma engine>": "<khóa>"}) as may: may.url`.

    Ghi lại header mỗi lời gọi ở `cac_loi_goi` để test kiểm xác thực, khóa chống trùng.
    """

    def __init__(self, core, khoa_engine=None, *, xac_thuc=None, khi_san_sang=None):
        """khoa_engine: {ma: khóa} cố định; hoặc xac_thuc(ma, khoa, instance) -> bool
        do bên ngoài cấp (vd bộ khởi động engine của Core). khi_san_sang(ma, khoa,
        instance, phien_ban, nang_luc) được gọi khi engine báo `san-sang`."""
        self.core = core
        self._khoa = dict(khoa_engine or {})
        self._xac_thuc = xac_thuc
        self._khi_san_sang = khi_san_sang
        self.cac_loi_goi = []
        self._may = None
        self._luong = None

    @property
    def url(self):
        return f'http://127.0.0.1:{self._may.server_address[1]}'

    def __enter__(self):
        cha = self

        class XuLy(http.server.BaseHTTPRequestHandler):
            protocol_version = 'HTTP/1.1'

            def log_message(self, *a):
                pass

            def do_GET(self):
                cha._xu_ly(self, 'GET')

            def do_POST(self):
                cha._xu_ly(self, 'POST')

            def do_PUT(self):
                cha._xu_ly(self, 'PUT')

        class MayChu(http.server.ThreadingHTTPServer):
            daemon_threads = True

            def handle_error(self, request, client_address):
                if not isinstance(sys.exc_info()[1], ConnectionError):
                    super().handle_error(request, client_address)

        self._may = MayChu(('127.0.0.1', 0), XuLy)
        self._luong = threading.Thread(target=self._may.serve_forever, daemon=True)
        self._luong.start()
        return self

    def __exit__(self, *exc):
        self._may.shutdown()
        self._may.server_close()

    def _tra(self, h, status, du_lieu=None, *, nhi_phan=None, loai='application/json'):
        raw = nhi_phan if nhi_phan is not None else (
            b'' if du_lieu is None else json.dumps(du_lieu, ensure_ascii=False).encode('utf-8'))
        h.send_response(status)
        if status != 204:
            h.send_header('Content-Type', loai)
        h.send_header('Content-Length', str(len(raw) if status != 204 else 0))
        h.end_headers()
        if status != 204:
            h.wfile.write(raw)

    def _xu_ly(self, h, phuong_thuc):
        duong = urllib.parse.urlsplit(h.path).path
        do_dai = int(h.headers.get('Content-Length') or 0)
        than = h.rfile.read(do_dai) if do_dai else b''
        ma = h.headers.get('X-KTT-Engine', '')
        instance = h.headers.get('X-KTT-Instance', '')
        khoa = h.headers.get('Idempotency-Key')
        self.cac_loi_goi.append(dict(phuong_thuc=phuong_thuc, duong=duong, ma_engine=ma,
                                     instance=instance, idempotency_key=khoa,
                                     viec_id=h.headers.get('X-KTT-Viec'),
                                     co_bearer=h.headers.get('Authorization', '').startswith('Bearer ')))
        try:
            auth = h.headers.get('Authorization', '')
            khoa_gui = auth[7:] if auth.startswith('Bearer ') else ''
            if self._xac_thuc is not None:
                dung = bool(instance) and self._xac_thuc(ma, khoa_gui, instance)
            else:
                dung = bool(instance) and ma in self._khoa and khoa_gui == self._khoa[ma]
            if not dung:
                raise _loi('KENH_XAC_THUC_KHONG_HOP_LE', 'Khóa engine không đúng.', 401)
            c = self.core
            m = _DUONG_NGAN.fullmatch(duong)
            if m:
                if m[1] != ma:
                    raise _loi('KHONG_DU_QUYEN', 'Engine chỉ gọi đường của mình.', 403)
                duoi = m[2]
                if duoi == 'cau-hinh' and phuong_thuc == 'GET':
                    return self._tra(h, 200, c._doc_cau_hinh(ma))
                if duoi == 'hang-cho' and phuong_thuc == 'GET':
                    return self._tra(h, 200, c._hang_cho(ma))
                if phuong_thuc == 'POST':
                    du = json.loads(than or b'{}')
                    viec_id = h.headers.get('X-KTT-Viec')
                    if duoi == 'ngan/ghi-lo':
                        kq = c._ngan_ghi_lo(ma, instance, du.get('lenh'), khoa, viec_id=viec_id)
                    else:
                        _, bang, tt = duoi.split('/')
                        bang = urllib.parse.unquote(bang)
                        if tt == 'doc':
                            kq = c._ngan_doc(ma, instance, bang, du.get('khoa'),
                                             viec_id=viec_id, gom_het_han=du.get('gom_het_han', False))
                        else:
                            kq = c._ngan_tim(ma, instance, bang, viec_id=viec_id,
                                             **{k: du[k] for k in ('loc', 'sap_xep', 'gioi_han', 'tiep',
                                                                   'gom_het_han') if k in du})
                    return self._tra(h, 200, kq)
            m = _DUONG_ENGINE.fullmatch(duong)
            if m:
                if m[1] != ma:
                    raise _loi('KENH_KHONG_DU_QUYEN', 'Engine chỉ gọi đường của mình.', 403)
                du = json.loads(than or b'{}')
                if m[2] == 'san-sang' and phuong_thuc == 'POST':
                    if self._khi_san_sang is not None:
                        try:
                            self._khi_san_sang(ma, khoa_gui, instance, du.get('phien_ban'),
                                               du.get('nang_luc') or [])
                        except Exception as exc:  # Core từ chối báo sẵn sàng
                            raise _loi(getattr(exc, 'ma', 'KHONG_NHAN_SAN_SANG'),
                                       getattr(exc, 'thong_diep', 'Core không nhận báo sẵn sàng.'),
                                       getattr(exc, 'http_status', 409)) from None
                    return self._tra(h, 200, c._san_sang(ma, instance, du.get('phien_ban'),
                                                         du.get('nang_luc') or []))
                if m[2] == 'viec/nhan' and phuong_thuc == 'POST':
                    viec = _DuongGia(c, ma, instance).nhan_viec(
                        min(float(du.get('cho_toi_da_giay', 0)), 2))
                    return self._tra(h, 204) if viec is None else self._tra(h, 200, {'viec': viec})
            m = _DUONG_VIEC.fullmatch(duong)
            if m:
                viec_id, viec_duoi = urllib.parse.unquote(m[1]), m[2]
                if viec_duoi == 'dau-vao' and phuong_thuc == 'GET':
                    return self._tra(h, 200, c._doc_dau_vao(ma, viec_id))
                if viec_duoi.startswith('tep/') and phuong_thuc == 'GET':
                    tep_id = urllib.parse.unquote(viec_duoi[4:])
                    return self._tra(h, 200, nhi_phan=c._mo_tep(
                        ma, viec_id, tep_id, TEP_TOI_DA_MAC_DINH_MIB * 1048576),
                                     loai='application/octet-stream')
                if viec_duoi == 'tep' and phuong_thuc == 'POST':
                    ten = urllib.parse.unquote(h.headers.get('X-KTT-Ten-Tep', ''))
                    return self._tra(h, 200, c._tai_tep_ra(
                        ma, viec_id, ten, than, h.headers.get('Content-Type'), khoa))
                du = json.loads(than or b'{}')
                if viec_duoi == 'gia-han' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._gia_han(ma, viec_id, du.get('han_giu_giay', 60)))
                if viec_duoi == 'tien-do' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._tien_do(ma, viec_id, du.get('phan_tram'),
                                                        du.get('cau', '')))
                if viec_duoi == 'ket-qua' and phuong_thuc == 'PUT':
                    return self._tra(h, 200, c._nop_ket_qua(ma, viec_id, du, khoa))
                if viec_duoi == 'ket-thuc' and phuong_thuc == 'POST':
                    return self._tra(h, 200, c._ket_thuc(ma, viec_id, du, khoa))
            raise _loi('KHONG_TIM_THAY', 'Không có đường này.', 404)
        except ConnectionError:  # engine đã đóng kết nối (bị dừng giữa lúc chờ)
            raise
        except (LoiDuongTruyen, NganXungDot) as exc:
            # Phong bì lỗi dạng phẳng như máy chủ Core (hợp đồng bản 1.3).
            self._tra(h, exc.http_status or 400, {
                'ma': exc.ma, 'thong_diep': exc.thong_diep, 'request_id': uuid.uuid4().hex,
                'thu_lai_duoc': exc.thu_lai_duoc})
        except Exception:
            self._tra(h, 500, {'ma': 'LOI_NOI_BO', 'thong_diep': 'Core giả gặp lỗi.',
                               'request_id': uuid.uuid4().hex, 'thu_lai_duoc': False})


# ---------------------------------------------------------------------------
# Lệnh: python -m kho_tri_thuc_sdk.thu <thư mục gói>

def _module_diem_vao(phieu):
    lenh = phieu.get('diem_vao', {}).get('lenh', [])
    for i, x in enumerate(lenh[:-1]):
        if x == '-m':
            return lenh[i + 1]
    return phieu['ma'] + '.chay'


def nap_engine_tu_goi(thu_muc_goi):
    """Nạp đối tượng Engine của một gói (module ở diem_vao, sau "-m")."""
    goc = Path(thu_muc_goi).resolve()
    phieu = doc_phieu(goc / 'engine.json')
    thu_muc = goc / phieu.get('diem_vao', {}).get('thu_muc', '.')
    if str(thu_muc) not in sys.path:
        sys.path.insert(0, str(thu_muc))
    module = importlib.import_module(_module_diem_vao(phieu))
    for gia_tri in vars(module).values():
        if isinstance(gia_tri, Engine) and gia_tri.ma == phieu['ma']:
            return gia_tri
    raise LoiPhieu([f'Không thấy đối tượng Engine trong module "{module.__name__}".'])


def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) != 1:
        print('Cách dùng: python -m kho_tri_thuc_sdk.thu <thư mục gói engine>')
        return 2
    try:
        app = nap_engine_tu_goi(argv[0])
    except LoiPhieu as exc:
        print(str(exc))
        return 2
    ket_qua = CoreGia().chay_thu_demo(app)
    if not ket_qua:
        print('Phiếu chưa có ví dụ chay_thu_demo.')
        return 1
    dat = True
    for kq in ket_qua:
        ok = kq['trang_thai'] == 'XONG'
        dat = dat and ok
        chi_tiet = kq['ket_qua'] if ok else (kq['loi'] or {}).get('thong_diep', kq['trang_thai'])
        s = json.dumps(chi_tiet, ensure_ascii=False)
        print(f'[{"ĐẠT" if ok else "LỖI"}] {kq["ten"]}: {s[:300]}')
    print(f'Engine {app.ma} {app.phien_ban}: '
          + ('mọi ví dụ chạy thử DEMO đều đạt.' if dat else 'có ví dụ chạy thử DEMO chưa đạt.'))
    return 0 if dat else 1


_KIEU_JSON = {'string': str, 'boolean': bool, 'object': dict, 'array': list}


def _kiem_toi_gian(v, s):
    """Kiểm JSON Schema tối giản khi không có jsonschema (chỉ dùng cho Core giả)."""
    if not isinstance(s, dict):
        return True
    t = s.get('type')
    if t in ('integer', 'number'):
        if isinstance(v, bool) or not isinstance(v, int if t == 'integer' else (int, float)):
            return False
    elif t in _KIEU_JSON and not isinstance(v, _KIEU_JSON[t]):
        return False
    if 'enum' in s and v not in s['enum']:
        return False
    if isinstance(v, dict):
        props = s.get('properties', {})
        if any(k not in v for k in s.get('required', ())):
            return False
        if s.get('additionalProperties') is False and any(k not in props for k in v):
            return False
        return all(_kiem_toi_gian(v[k], props[k]) for k in v if k in props)
    if isinstance(v, list):
        return all(_kiem_toi_gian(x, s.get('items', {})) for x in v)
    return True


if __name__ == '__main__':
    raise SystemExit(main())
