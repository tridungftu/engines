"""SDK module 2.1: đọc/ghi ngăn của chính module (HOP-DONG-CONG a.6, a.9, a.10.6).

``sdk.ngan(ma).doc(loc, gioi_han, con_tro)`` trả ``{danh_sach, con_tro_tiep}``;
``.them(dong)`` và ``.sua(id, dong)`` trả dòng sau khi ghi. Chạy trong giao
dịch của chính module (login module, RLS theo pháp nhân); Core không ghi vào
khối module (G6). Chỉ ngăn/cột đã khai ở ``du_lieu.ngan`` của phiếu đã băm;
luôn lọc và gán ``phap_nhan_id`` của phiên, module không chọn pháp nhân.
"""

from __future__ import annotations

import json
import re
from uuid import UUID, uuid4

from .dich_vu import LoiDichVu, _ctx

_TEN = re.compile(r'[a-z][a-z0-9_]{0,62}')
# Cột chuẩn Core tự thêm cho mọi ngăn (a.6); module chỉ đọc, không ghi trực tiếp.
COT_CHUAN = ('id', 'phap_nhan_id', 'nguoi_tao', 'tao_luc', 'sua_luc',
             'ban_ghi_goc_id', 'da_luu_tru')
# Cột chuẩn module được phép lọc/đặt khi ghi (lưu trữ mềm).
_COT_CHUAN_GHI = ('da_luu_tru',)
GIOI_HAN_TOI_DA = 200


def _loi(ma='NGAN_DU_LIEU_KHONG_HOP_LE', status=400):
    return LoiDichVu(ma, status)


def doc_khai_bao(manifest):
    """{ma_ngan: (cot khai báo,...)} từ phiếu bản 2; phiếu khác trả rỗng."""
    if not isinstance(manifest, dict) or manifest.get('phien_ban_manifest') != 2:
        return {}
    result = {}
    for ngan in (manifest.get('du_lieu') or {}).get('ngan', []):
        cot = tuple(c['ma'] for c in ngan['cot'])
        if (not _TEN.fullmatch(ngan['ma']) or any(not _TEN.fullmatch(c) for c in cot)
                or set(cot) & set(COT_CHUAN)):
            raise _loi('NGAN_KHAI_BAO_KHONG_HOP_LE', 500)
        result[ngan['ma']] = cot
    return result


def _gia_tri(value):
    # Chỉ giá trị JSON vô hướng; tệp/khóa nối là chuỗi mã, tiền là số/chuỗi.
    if value is None or type(value) in (str, int, float, bool):
        if type(value) is float and value != value:
            raise _loi()
        if type(value) is str and len(value) > 1_000_000:
            raise _loi()
        return value
    raise _loi()


def _dong(row):
    if isinstance(row, dict):
        data = row
    elif isinstance(row, (list, tuple)) and len(row) == 1:
        data = row[0]
    else:
        raise _loi('NGAN_PHAN_HOI_SAI', 500)
    if isinstance(data, str):
        data = json.loads(data)
    if not isinstance(data, dict):
        raise _loi('NGAN_PHAN_HOI_SAI', 500)
    return {k: (str(v) if isinstance(v, UUID) else v) for k, v in data.items()}


class Ngan:
    """Một ngăn của module trong một giao dịch module đang mở."""

    __slots__ = ('_tx', '_bang', '_cot', '_module')

    def __init__(self, tx, module, ma, cot):
        if (not isinstance(module, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', module)
                or not isinstance(ma, str) or not _TEN.fullmatch(ma)
                or not isinstance(cot, tuple) or not cot):
            raise _loi('NGAN_CHUA_KHAI', 404)
        ctx = _ctx(tx)
        if ctx.module != module:
            raise _loi('SDK_MODULE', 403)
        # Tên quan hệ chỉ ghép từ mã đã khai và đã kiểm mẫu, không từ request.
        self._tx, self._bang, self._cot, self._module = tx, f'mod_{module}.{ma}', cot, module

    def __repr__(self):
        return 'Ngan(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize ngăn SDK')

    def _pn(self):
        return _ctx(self._tx).phap_nhan_id

    def _cot_ghi(self, dong):
        if not isinstance(dong, dict) or not dong:
            raise _loi()
        allowed = set(self._cot) | set(_COT_CHUAN_GHI)
        if any(not isinstance(k, str) or k not in allowed for k in dong):
            raise _loi('NGAN_COT_CHUA_KHAI')
        return [(k, _gia_tri(v)) for k, v in sorted(dong.items())]

    def _mot(self, cau, ts):
        row = self._tx.execute(cau, ts).fetchone()
        return None if row is None else _dong(row)

    def doc(self, loc=None, gioi_han=50, con_tro=None):
        loc = {} if loc is None else loc
        if (not isinstance(loc, dict) or type(gioi_han) is not int
                or not 1 <= gioi_han <= GIOI_HAN_TOI_DA):
            raise _loi()
        allowed = set(self._cot) | set(COT_CHUAN)
        if any(not isinstance(k, str) or k not in allowed or k == 'phap_nhan_id' for k in loc):
            raise _loi('NGAN_COT_CHUA_KHAI')
        sau = None
        if con_tro is not None:
            try:
                sau = str(UUID(con_tro)) if isinstance(con_tro, str) else None
            except ValueError:
                sau = None
            if sau is None:
                raise _loi()
        if 'id' in loc:
            try:
                loc = dict(loc, id=str(UUID(loc['id'])))
            except (TypeError, ValueError, AttributeError):
                # Mã không phải UUID thì không dòng nào khớp; không lộ lỗi CSDL.
                return dict(danh_sach=[], con_tro_tiep=None)
        dieu_kien, ts = ['phap_nhan_id = %(phap_nhan_id)s'], dict(phap_nhan_id=self._pn())
        for i, (k, v) in enumerate(sorted(loc.items())):
            ts[f'l{i}'] = _gia_tri(v)
            dieu_kien.append(f'{k} IS NOT DISTINCT FROM %(l{i})s')
        if sau is not None:
            dieu_kien.append('id > %(sau)s::uuid')
            ts['sau'] = sau
        ts['gioi_han'] = gioi_han + 1
        rows = self._tx.execute(
            "SELECT coalesce(jsonb_agg(to_jsonb(_d) ORDER BY _d.id), '[]'::jsonb) FROM ("
            f'SELECT * FROM {self._bang} WHERE ' + ' AND '.join(dieu_kien)
            + ' ORDER BY id LIMIT %(gioi_han)s) AS _d', ts).fetchone()
        data = rows[0] if isinstance(rows, (list, tuple)) else next(iter(rows.values()))
        data = json.loads(data) if isinstance(data, str) else data
        if not isinstance(data, list) or len(data) > gioi_han + 1:
            raise _loi('NGAN_PHAN_HOI_SAI', 500)
        con = len(data) > gioi_han
        data = [_dong(r) for r in data[:gioi_han]]
        return dict(danh_sach=data, con_tro_tiep=data[-1]['id'] if con else None)

    def them(self, dong):
        cot = self._cot_ghi(dong)
        ctx = _ctx(self._tx)
        ts = dict(id=str(uuid4()), phap_nhan_id=ctx.phap_nhan_id,
                  nguoi_tao=None if ctx.nguoi_dung_id is None else str(ctx.nguoi_dung_id))
        ts.update({f'c{i}': v for i, (_, v) in enumerate(cot)})
        ten = ', '.join(['id', 'phap_nhan_id', 'nguoi_tao', *(k for k, _ in cot)])
        gia = ', '.join(['%(id)s::uuid', '%(phap_nhan_id)s', '%(nguoi_tao)s::uuid',
                         *(f'%(c{i})s' for i in range(len(cot)))])
        row = self._mot(f'INSERT INTO {self._bang} AS _n ({ten}) VALUES ({gia}) '
                        'RETURNING to_jsonb(_n.*)', ts)
        if row is None or row.get('id') != ts['id']:
            raise _loi('NGAN_PHAN_HOI_SAI', 500)
        return row

    def sua(self, id, dong):
        try:
            ident = str(UUID(id)) if isinstance(id, str) else None
        except ValueError:
            ident = None
        if ident is None:
            raise _loi()
        cot = self._cot_ghi(dong)
        ts = dict(id=ident, phap_nhan_id=self._pn())
        ts.update({f'c{i}': v for i, (_, v) in enumerate(cot)})
        dat = ', '.join([*(f'{k} = %(c{i})s' for i, (k, _) in enumerate(cot)),
                         'sua_luc = clock_timestamp()'])
        row = self._mot(f'UPDATE {self._bang} AS _n SET {dat} WHERE _n.id = %(id)s::uuid '
                        'AND _n.phap_nhan_id = %(phap_nhan_id)s RETURNING to_jsonb(_n.*)', ts)
        if row is None:
            raise _loi('NGAN_KHONG_TIM_THAY', 404)
        return row


class BoNgan:
    """``sdk.ngan(ma)`` cho một giao dịch; chỉ các ngăn đã khai của module."""

    __slots__ = ('_tx', '_module', '_khai_bao')

    def __init__(self, tx, module, khai_bao):
        self._tx, self._module, self._khai_bao = tx, module, dict(khai_bao)

    def __call__(self, ma):
        if ma not in self._khai_bao:
            raise _loi('NGAN_CHUA_KHAI', 404)
        return Ngan(self._tx, self._module, ma, self._khai_bao[ma])
