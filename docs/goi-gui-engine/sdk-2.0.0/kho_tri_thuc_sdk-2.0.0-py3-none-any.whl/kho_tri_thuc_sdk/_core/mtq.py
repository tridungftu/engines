"""Cổng MTQ Core dùng mã phiên G2-03 và transaction do caller quản lý.

Nâng cổng hỏi/đọc/ghi từ chối M0057–58; không quyết định quyền trong Python,
không nhận actor, số tiền hay pháp nhân đối tượng do client khai. Resolver
module lấy căn cứ CSDL qua binding đã kiểm. ``cac_ma`` cung cấp mã riêng cho
từng pháp nhân của cùng người dùng. CHO luôn có ``cho_phep=False``.
Mọi pháp nhân dùng cùng số tiền từ resolver; ``hop_le=False`` trả TU_CHOI
với mã MTQ_DOI_TUONG và lý do module, ghi qua ``ghi_tu_choi_phien``.

Sau rollback nghiệp vụ, caller mở transaction mới để ghi từ chối rồi commit.
Hàm đọc/hỏi không tự ghi audit. Lỗi driver không giữ thông báo hoặc tham số.
Các hàm ghi trực tiếp cũ của danh_tinh.py không còn ACL sau 006; dùng cửa
tao_danh_tinh có kiểm MTQ. Bootstrap workspace đầu tiên do lead provisioning.
"""

from __future__ import annotations

import json
import re
from uuid import UUID

from .phien import MaBiMat


class LoiMTQ(RuntimeError):
    def __init__(self, ma: str):
        self.ma = ma
        super().__init__('Thao tác thẩm quyền thất bại (' + ma + ')')


def _goi(ket_noi, cau_sql, tham_so):
    ma_loi = 'MTQ_THAT_BAI'
    try:
        return ket_noi.execute(cau_sql, tham_so).fetchone()[0]
    except Exception as exc:
        trang_thai = getattr(exc, 'sqlstate', None)
        if isinstance(trang_thai, str) and re.fullmatch(r'[0-9A-Z]{5}', trang_thai):
            ma_loi = trang_thai
    tham_so = None
    raise LoiMTQ(ma_loi)


def _ma(ma):
    if not isinstance(ma, MaBiMat):
        raise ValueError('Cần mã phiên bí mật')
    return ma.lay_de_truyen()


def _viec(viec_id, the_he):
    if (viec_id is None) != (the_he is None) or (
        the_he is not None and (type(the_he) is not int or not 0 < the_he <= 9223372036854775807)
    ):
        raise ValueError('Việc và thế hệ không hợp lệ')
    return None if viec_id is None else UUID(str(viec_id)), the_he


def _pham_vi(module, phap_nhan_id, hanh_dong):
    if not isinstance(module, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', module):
        raise ValueError('Module không hợp lệ')
    if (not isinstance(hanh_dong, str) or not re.fullmatch(r'[A-Z0-9_]+:[A-Z0-9_]+:[A-Z_]+', hanh_dong)
            or hanh_dong.split(':')[0] != module.upper()):
        raise ValueError('Hành động không thuộc module')
    return module, UUID(str(phap_nhan_id)), hanh_dong


def _tham_so(*, ma, module, phap_nhan_id, hanh_dong, doi_tuong,
             phien_ban_contract='1', cac_ma=(), viec_id=None, the_he=None):
    _pham_vi(module, phap_nhan_id, hanh_dong)
    if (not isinstance(doi_tuong, dict) or set(doi_tuong) - {'bang', 'id', 'phong_id'}
            or not {'bang', 'id'} <= set(doi_tuong)
            or not isinstance(doi_tuong['bang'], str) or not doi_tuong['bang'].strip()):
        raise ValueError('Chỉ nhận tham chiếu đối tượng máy chủ')
    doi_tuong = dict(doi_tuong)
    doi_tuong['id'] = str(UUID(str(doi_tuong['id'])))
    if doi_tuong.get('phong_id') is not None:
        doi_tuong['phong_id'] = str(UUID(str(doi_tuong['phong_id'])))
    if not isinstance(phien_ban_contract, str) or not phien_ban_contract.strip():
        raise ValueError('Cần phiên bản contract đã ghim')
    if not isinstance(cac_ma, (list, tuple)):
        raise ValueError('Cần danh sách mã phiên')
    viec_id, the_he = _viec(viec_id, the_he)
    return (_ma(ma), module, UUID(str(phap_nhan_id)), hanh_dong,
            json.dumps(doi_tuong, ensure_ascii=False, allow_nan=False), phien_ban_contract,
            [_ma(m) for m in cac_ma], viec_id, the_he)


def quyet_dinh_phien(ket_noi, **tham_so) -> dict:
    """Chỉ DAT và cho_phep=True mới cho phép; không tự xử lý CHO thành fallback."""
    return _goi(ket_noi, '''SELECT loi.mtq_quyet_dinh_phien(
        %s,%s,%s,%s,%s::jsonb,%s,%s::text[],%s,%s)''', _tham_so(**tham_so))


def duoc_doc(ket_noi, **tham_so) -> bool:
    return _goi(ket_noi, '''SELECT loi.mtq_duoc_doc(
        %s,%s,%s,%s,%s::jsonb,%s,%s::text[],%s,%s)''', _tham_so(**tham_so))


def ghi_tu_choi_phien(ket_noi, *, request_id: UUID, **tham_so) -> UUID:
    return _goi(ket_noi, '''SELECT loi.mtq_ghi_tu_choi_phien(
        %s,%s,%s,%s,%s,%s::jsonb,%s,%s::text[],%s,%s)''',
        (UUID(str(request_id)), *_tham_so(**tham_so)))


def dat_ngu_canh(ket_noi, *, ma: MaBiMat, module: str, phap_nhan_id: UUID,
                 hanh_dong: str, viec_id: UUID | None = None, the_he: int | None = None) -> None:
    """Gọi bên trong transaction. SET LOCAL không phải cache kết quả xác minh."""
    module, phap_nhan_id, hanh_dong = _pham_vi(module, phap_nhan_id, hanh_dong)
    viec_id, the_he = _viec(viec_id, the_he)
    hop_le = _goi(ket_noi, '''SELECT EXISTS (SELECT FROM loi.xac_minh_phien(
        %s,%s,%s,%s,%s,%s))''', (_ma(ma), module, phap_nhan_id, hanh_dong, viec_id, the_he))
    if not hop_le:
        raise LoiMTQ('42501')
    _goi(ket_noi, '''SELECT set_config('ktt.ma_phien',%s,true),
        set_config('ktt.module',%s,true), set_config('ktt.phap_nhan_id',%s,true),
        set_config('ktt.hanh_dong',%s,true), set_config('ktt.viec_id',%s,true),
        set_config('ktt.the_he',%s,true)''',
        (_ma(ma), module, str(phap_nhan_id), hanh_dong,
         '' if viec_id is None else str(viec_id), '' if the_he is None else str(the_he)))


def tao_danh_tinh(ket_noi, *, ma: MaBiMat, phap_nhan_id: UUID, loai: str,
                  du_lieu: dict, viec_id: UUID | None = None, the_he: int | None = None) -> UUID:
    """MTQ kiểm CORE:DANH_TINH:LAP ở workspace hiện hành. Người nhận là target.

    Tạo workspace mới tự thêm người thao tác làm thành viên Core và thu hồi
    phiên cũ theo G2-03; caller phải cấp phiên mới trước thao tác tiếp theo.
    """
    cac_khoa = {
        'nguoi_dung': {'dang_nhap', 'ten', 'vai_tro', 'mo_phong'},
        'phap_nhan': {'ma', 'ten', 'mst'},
        'thanh_vien': {'nguoi_dung_id', 'module', 'duyet_loai_viec'},
    }
    if not isinstance(loai, str) or loai not in cac_khoa or not isinstance(du_lieu, dict):
        raise ValueError('Loại hoặc dữ liệu danh tính không hợp lệ')
    if set(du_lieu) - cac_khoa[loai]:
        raise ValueError('Dữ liệu có trường ngoài phạm vi')
    du_lieu = dict(du_lieu)
    if 'nguoi_dung_id' in du_lieu:
        du_lieu['nguoi_dung_id'] = str(UUID(str(du_lieu['nguoi_dung_id'])))
    for ten in ('module', 'duyet_loai_viec'):
        if ten in du_lieu and (not isinstance(du_lieu[ten], (list, tuple)) or any(
            not isinstance(v, str) or not v.strip() for v in du_lieu[ten]
        )):
            raise ValueError('Danh sách quyền không hợp lệ')
    viec_id, the_he = _viec(viec_id, the_he)
    return _goi(ket_noi, 'SELECT loi.mtq_tao_danh_tinh(%s,%s,%s,%s::jsonb,%s,%s)',
                (_ma(ma), UUID(str(phap_nhan_id)), loai,
                 json.dumps(du_lieu, ensure_ascii=False, allow_nan=False), viec_id, the_he))


# M1: caller giữ transaction khi đạt; từ chối phải commit audit trước khi báo lỗi.
_VAI_MTQ = frozenset(('THUC_HIEN_1', 'THUC_HIEN_2', 'TRUONG_PHONG', 'CFO', 'NGUOI_XEM'))
_LOI_GHI_MTQ = {
    'MTQ_DAU_VAO': 'Dữ liệu ma trận thẩm quyền không hợp lệ.',
    'MTQ_KHONG_QUYEN': 'Không đủ quyền quản trị ma trận thẩm quyền.',
    'MTQ_XUNG_DOT': 'Ma trận đã thay đổi. Cần tải lại trước khi lưu.',
    'MTQ_NHAP_MOI_HON': 'Đã có bản nháp mới hơn. Cần tải lại trước khi công bố hoặc kích hoạt.',
    'MTQ_CHUA_SAN_SANG': 'Module, vai hoặc phạm vi chưa sẵn sàng.',
    'MTQ_GHI_THAT_BAI': 'Chưa thể ghi ma trận thẩm quyền.',
}


def _loi_ghi_mtq(ma):
    loi = LoiMTQ(ma)
    loi.args = (_LOI_GHI_MTQ[ma],)
    return loi


def _ghi_mtq(ket_noi, *, ma, phap_nhan_id, module, thao_tac, phien_ban_id,
             phien_ban_dong, kich_hoat_phien_ban_dong, cac_o, ly_do, request_id):
    """Dùng transaction riêng cho cửa ghi: từ chối tự commit audit rồi ném LoiMTQ.

    Khi đạt caller commit; chỉ kích hoạt trả can_dang_nhap_lai=True.
    Nháp/công bố nằm trong mtq_thay_doi.sau, chưa nằm trong bảng quyền 006.
    """
    try:
        if not isinstance(module, str) or not re.fullmatch(r'[a-z][a-z0-9_]{0,30}', module) or module == 'core':
            raise ValueError
        pn = UUID(str(phap_nhan_id))
        pb = None if phien_ban_id is None else UUID(str(phien_ban_id))
        request = UUID(str(request_id))
        for so in (phien_ban_dong, kich_hoat_phien_ban_dong):
            if type(so) is not int or not 0 <= so < 9223372036854775807:
                raise ValueError
        if (pb is None) != (phien_ban_dong == 0):
            raise ValueError
        if not isinstance(ly_do, str) or not 1 <= len(ly_do.strip()) <= 1000:
            raise ValueError
        if not isinstance(cac_o, (list, tuple)) or len(cac_o) > 1000:
            raise ValueError
        o_da_kiem, khoa = [], set()
        for o in cac_o:
            if (not isinstance(o, dict) or set(o) - {'phong_id', 'vai', 'man', 'hanh_dong', 'cho_phep', 'nguoi_dung_id'}
                    or not {'phong_id', 'vai', 'man', 'hanh_dong', 'cho_phep'} <= set(o)):
                raise ValueError
            o = dict(o)
            o['phong_id'] = str(UUID(str(o['phong_id'])))
            if (not isinstance(o['vai'], str) or o['vai'] not in _VAI_MTQ
                    or not isinstance(o['man'], str) or not re.fullmatch(r'[A-Z0-9_]{1,100}', o['man'])
                    or not isinstance(o['hanh_dong'], str)
                    or o['hanh_dong'] not in {'XEM', 'XEM_DU', 'XEM_DU_LIEU', 'LAP', 'SUA', 'KIEM', 'DUYET', 'HUY'}
                    or type(o['cho_phep']) is not bool):
                raise ValueError
            if 'nguoi_dung_id' in o:
                o['nguoi_dung_id'] = str(UUID(str(o['nguoi_dung_id'])))
            key = tuple(o[k] for k in ('phong_id', 'vai', 'man', 'hanh_dong'))
            if key in khoa:
                raise ValueError
            khoa.add(key)
            o_da_kiem.append(o)
        token = _ma(ma)
        du_lieu = json.dumps(o_da_kiem, ensure_ascii=False, allow_nan=False)
    except (ValueError, TypeError, AttributeError):
        raise _loi_ghi_mtq('MTQ_DAU_VAO') from None
    ma_loi = None
    try:
        ket_qua = ket_noi.execute('SELECT loi.cd060_ghi_mtq(%s,%s,%s,%s,%s,%s,%s,%s::jsonb,%s,%s)',
            (token, pn, module, thao_tac, pb, phien_ban_dong,
             kich_hoat_phien_ban_dong, du_lieu, ly_do, request)).fetchone()[0]
        if ket_qua.get('duoc_phep') is False:
            # SQL trả từ chối thay vì RAISE: giữ audit trước khi caller xử lý lỗi.
            ket_noi.commit()
            ma_loi = ket_qua.get('ma')
            if ma_loi not in _LOI_GHI_MTQ:
                ma_loi = 'MTQ_GHI_THAT_BAI'
        else:
            return ket_qua
    except Exception as exc:
        ma_loi = {'42501': 'MTQ_KHONG_QUYEN', '40001': 'MTQ_XUNG_DOT',
                  '23505': 'MTQ_XUNG_DOT', '22023': 'MTQ_DAU_VAO',
                  '22P02': 'MTQ_DAU_VAO', '23514': 'MTQ_CHUA_SAN_SANG',
                  '23503': 'MTQ_CHUA_SAN_SANG', 'P0002': 'MTQ_CHUA_SAN_SANG'}.get(
                      getattr(exc, 'sqlstate', None), 'MTQ_GHI_THAT_BAI')
    # Ném ngoài except để không giữ exception driver có SQL/DSN/tham số.
    token = du_lieu = ma = None
    raise _loi_ghi_mtq(ma_loi)


def luu_nhap_mtq(ket_noi, *, ma, phap_nhan_id, module, phien_ban_id,
                 phien_ban_dong, cac_o, ly_do, request_id):
    """Append snapshot từ bản mới nhất (None/0 khi chưa có bản nào).

    Ô theo phòng/vai; người tùy chọn chỉ đối chiếu gán vai/phạm vi đã có,
    không tạo quyền cá nhân khác với những người cùng vai. Giữ hạn mức cũ.
    """
    return _ghi_mtq(ket_noi, ma=ma, phap_nhan_id=phap_nhan_id, module=module,
        thao_tac='NHAP', phien_ban_id=phien_ban_id, phien_ban_dong=phien_ban_dong,
        kich_hoat_phien_ban_dong=0, cac_o=cac_o, ly_do=ly_do, request_id=request_id)


def cong_bo_mtq(ket_noi, *, ma, phap_nhan_id, module, phien_ban_id,
                phien_ban_dong, ly_do, request_id):
    """Công bố nháp qua CAS; chưa thay con trỏ hiệu lực."""
    return _ghi_mtq(ket_noi, ma=ma, phap_nhan_id=phap_nhan_id, module=module,
        thao_tac='CONG_BO', phien_ban_id=phien_ban_id, phien_ban_dong=phien_ban_dong,
        kich_hoat_phien_ban_dong=0, cac_o=[], ly_do=ly_do, request_id=request_id)


def kich_hoat_mtq(ket_noi, *, ma, phap_nhan_id, module, phien_ban_id,
                  phien_ban_dong, kich_hoat_phien_ban_dong, ly_do, request_id):
    """CAS cả snapshot và con trỏ (0 nếu chưa có); giữ bản cũ để tra lịch sử."""
    return _ghi_mtq(ket_noi, ma=ma, phap_nhan_id=phap_nhan_id, module=module,
        thao_tac='KICH_HOAT', phien_ban_id=phien_ban_id, phien_ban_dong=phien_ban_dong,
        kich_hoat_phien_ban_dong=kich_hoat_phien_ban_dong, cac_o=[], ly_do=ly_do, request_id=request_id)
