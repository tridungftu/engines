"""Façade việc qua kênh module → Core; K ghi chạy ngoài tx module.

Bootstrap cấp binding wire cho từng operation, không lấy binding từ payload.
Thiếu kênh/binding hoặc cửa SQL được cấp thì từ chối, không mở kết nối riêng.
"""

from collections.abc import Mapping
import hashlib
import re
import time
from uuid import UUID

from . import kenh_khung as k
from .kenh_core import KenhCore
from .dich_vu import LoiDichVu, _Viec, _ctx
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi
from ._core import viec as _core


TRANG_THAI = frozenset({'queued', 'running', 'waiting_input', 'cancel_requested',
    'cancelled', 'succeeded', 'failed', 'interrupted'})
TRUONG_VIEC = frozenset({'id', 'phap_nhan_id', 'ma_module', 'trang_thai', 'tien_do',
    'ket_qua_ids', 'loi', 'tao_luc', 'cap_nhat_luc'})
TRUONG_KET_QUA = frozenset({'id', 'tai_lieu_id', 'bien_the', 'goc_id', 'revision',
    'tep_id', 'trang_thai', 'trang_thai_duyet', 'row_version', 'cong_bo'})


class LoiViecSDK(LoiDichVu):
    def __init__(self, ma='LOI_NOI_BO', http_status=500):
        super().__init__(ma, http_status)
        self.args = ({404: 'Không tìm thấy công việc.',
            409: 'Công việc đã thay đổi. Anh hãy tải lại để kiểm tra.',
            401: 'Phiên làm việc đã hết hiệu lực. Anh hãy đăng nhập lại.',
            403: 'Anh chưa có quyền thực hiện thao tác này.',
            422: 'Thông tin công việc chưa hợp lệ.',
            502: 'Không đọc được phản hồi công việc.',
            503: 'Dịch vụ công việc chưa sẵn sàng.'}.get(http_status,
                'Chưa thực hiện được thao tác công việc.'),)


def _id(value):
    try:
        if not isinstance(value, (str, UUID)):
            raise ValueError()
        return str(UUID(str(value)))
    except (ValueError, TypeError, AttributeError):
        raise LoiViecSDK('KENH_DU_LIEU_KHONG_HOP_LE', 422) from None


class Viec(_Viec):
    """Giữ cửa tạo việc cũ; ba K dùng đúng KenhCore đã xác thực của runtime.

    ngu_canh(ctx, operation) trả kwargs {ngu_canh, parent?, thu_tu_con?} cho
    KenhCore.goi. Runtime giữ thứ tự con ổn định qua replay, không đếm tại đây.
    """
    __slots__ = ('__kenh', '__binding')

    def __init__(self, kenh_core=None, *, ngu_canh=None):
        if kenh_core is not None and not isinstance(kenh_core, KenhCore):
            raise TypeError('Cần kênh Core do bootstrap cấp')
        if ngu_canh is not None and not callable(ngu_canh):
            raise TypeError('Cần bộ cấp ngữ cảnh do bootstrap cung cấp')
        self.__kenh, self.__binding = kenh_core, ngu_canh

    def _goi(self, ctx, operation, viec_id, khoa=None, *, du_lieu=None):
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den):
            raise LoiViecSDK('KENH_XAC_THUC_KHONG_HOP_LE', 401)
        if ctx.module == 'core' or not ctx.hanh_dong.startswith(ctx.module.upper() + ':'):
            raise LoiViecSDK('KENH_KHONG_DU_QUYEN', 403)
        id_ = _id(viec_id)
        if self.__kenh is None or self.__binding is None:
            raise LoiViecSDK('CHUA_SAN_SANG', 503)
        ma, status = 'LOI_NOI_BO', 500
        try:
            binding = self.__binding(ctx, operation)
            k._can(isinstance(binding, dict) and 'ngu_canh' in binding
                   and not (binding.keys() - {'ngu_canh', 'parent', 'thu_tu_con'}))
            h = binding['ngu_canh']
            k._can(isinstance(h, Mapping) and all(h.get(key) == value for key, value in {
                'module': ctx.module, 'module_nguon': ctx.module,
                'nguoi_dung_id': str(ctx.nguoi_dung_id),
                'phap_nhan_id': str(ctx.phap_nhan_id), 'instance_id': str(ctx.instance_id),
                'hanh_dong': ctx.hanh_dong}.items()), 'KENH_KHONG_DU_QUYEN')
            response = self.__kenh.goi(operation,
                {'viec_id': id_} if du_lieu is None else du_lieu, khoa=khoa, **binding)
            if operation in {'viec.huy', 'viec.bao_tien_do'}:
                k._can(response.header.get('da_commit') is True, 'PHAN_HOI_SAI_CONTRACT')
            return response.json()
        except Exception as exc:
            if isinstance(exc, k.LoiKenh):
                ma, status = exc.ma, exc.http_status
            _xoa_loi(exc)
        raise LoiViecSDK(ma, status) from None

    def lay(self, ctx, viec_id):
        result = self._goi(ctx, 'viec.lay', viec_id)
        if (not isinstance(result, dict) or result.keys() != TRUONG_VIEC
                or result.get('id') != _id(viec_id)
                or result.get('ma_module') != ctx.module
                or result.get('phap_nhan_id') != str(ctx.phap_nhan_id)
                or result.get('trang_thai') not in TRANG_THAI
                or (result.get('tien_do') is not None and
                    (type(result['tien_do']) is not int or not 0 <= result['tien_do'] <= 100))
                or not isinstance(result.get('ket_qua_ids'), list)):
            raise LoiViecSDK('PHAN_HOI_SAI_CONTRACT', 502)
        return result

    def ket_qua(self, ctx, viec_id):
        envelope = self._goi(ctx, 'viec.ket_qua', viec_id)
        if not isinstance(envelope, dict) or envelope.keys() != {'danh_sach'}:
            raise LoiViecSDK('PHAN_HOI_SAI_CONTRACT', 502)
        result = envelope['danh_sach']
        if (not isinstance(result, list) or any(not isinstance(r, dict)
                or r.keys() != TRUONG_KET_QUA for r in result)):
            raise LoiViecSDK('PHAN_HOI_SAI_CONTRACT', 502)
        return result

    def huy(self, ctx, viec_id, khoa):
        if not isinstance(khoa, str) or not re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa):
            raise LoiViecSDK('KENH_DU_LIEU_KHONG_HOP_LE', 422)
        result = self._goi(ctx, 'viec.huy', viec_id, khoa)
        if (not isinstance(result, dict) or result.keys() != {'viec_id', 'trang_thai', 'request_id'}
                or result.get('viec_id') != _id(viec_id)
                or result.get('trang_thai') not in TRANG_THAI):
            raise LoiViecSDK('PHAN_HOI_SAI_CONTRACT', 502)
        return result

    def bao_tien_do(self, tx, giu_viec, muc):
        """K ghi nhận NguCanh ngoài tx; giữ tên tham số cũ để báo lỗi rõ.

        Không cam kết tiến độ nguyên tử với tx module. Core tra mã lease từ
        sổ tin cậy; chỉ gửi định danh lần thử/thế hệ, không gửi handle hay mã.
        """
        if not isinstance(tx, NguCanh):
            _ctx(tx)
            raise LoiViecSDK('XUNG_DOT', 409)
        ctx = tx
        if (not isinstance(giu_viec, _core.GiuViec)
                or (giu_viec.module, giu_viec.phap_nhan_id, giu_viec.hanh_dong,
                    giu_viec.instance_id) != (ctx.module, ctx.phap_nhan_id,
                    ctx.hanh_dong, ctx.instance_id)):
            raise LoiViecSDK('KENH_KHONG_DU_QUYEN', 403)
        if (type(muc) is not int or not 0 <= muc <= 100
                or type(giu_viec.the_he) is not int or not 1 <= giu_viec.the_he <= 2**63-1):
            raise LoiViecSDK('KENH_DU_LIEU_KHONG_HOP_LE', 422)
        data = dict(viec_id=_id(giu_viec.viec_id),
            lan_thu_id=_id(giu_viec.lan_thu_id), the_he=giu_viec.the_he, muc=muc)
        khoa = hashlib.sha256(k._json(data)).hexdigest()
        result = self._goi(ctx, 'viec.bao_tien_do', giu_viec.viec_id, khoa,
                          du_lieu=data)
        if (not isinstance(result, dict) or result.keys() != {'da_cap_nhat'}
                or result['da_cap_nhat'] is not True):
            raise LoiViecSDK('PHAN_HOI_SAI_CONTRACT', 502)
        return True


_mac_dinh = Viec()
lay = _mac_dinh.lay
ket_qua = _mac_dinh.ket_qua
huy = _mac_dinh.huy
bao_tien_do = _mac_dinh.bao_tien_do
