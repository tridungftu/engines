"""Đường truyền HTTP của SDK engine 2.0 (HOP-DONG-CONG.md phần c, bản 1.2).

Mọi engine, `cuc_bo` lẫn `tu_xa`, dùng một đường: API `/api/v1/engine/…` với
`Authorization: Bearer <khóa engine>`, `X-KTT-Engine`, `X-KTT-Instance`, và
`Idempotency-Key` cho lệnh ghi. Engine `cuc_bo` gọi Core qua loopback.

Khởi động (Core → engine): ngay sau khi chạy lệnh `diem_vao`, Core ghi MỘT dòng
JSON (UTF-8, kết thúc bằng "\\n") vào stdin của tiến trình engine:

    {"core_url": "http://127.0.0.1:<cổng>", "khoa": "<khóa engine>", "instance": "<mã phiên chạy>"}

SDK đọc đúng một dòng rồi gọi `san-sang`. Chạy tay (stdin là màn hình hoặc
trống) thì dùng biến môi trường `KTT_CORE_URL`, `KTT_ENGINE_KHOA`,
`KTT_ENGINE_INSTANCE` (không bắt buộc). `http://` chỉ cho máy cục bộ
(127.0.0.1, localhost, ::1); máy khác phải `https://`.

Chỉ dùng thư viện chuẩn. Không ghi khóa ra nhật ký hay chuỗi lỗi.
"""

from __future__ import annotations

from dataclasses import dataclass
import http.client
import ipaddress
import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request
import uuid

from .engine import DuongTruyen, LoiDuongTruyen


__all__ = ('DuongHttp', 'ThongTinKhoiDong', 'LoiKhoiDong', 'doc_khoi_dong',
           'BIEN_CORE_URL', 'BIEN_KHOA', 'BIEN_INSTANCE')

BIEN_CORE_URL = 'KTT_CORE_URL'
BIEN_KHOA = 'KTT_ENGINE_KHOA'
BIEN_INSTANCE = 'KTT_ENGINE_INSTANCE'
DONG_KHOI_DONG_TOI_DA = 65536
JSON_TOI_DA_BYTE = 64 * 1048576
_KHOA = re.compile(r'[!-~]{16,512}')
_INSTANCE = re.compile(r'[A-Za-z0-9_.:-]{1,100}')
_MAY_CUC_BO = frozenset({'localhost'})
_KHONG = object()


class LoiKhoiDong(LoiDuongTruyen):
    """Thiếu hoặc sai thông tin khởi động (địa chỉ Core, khóa, mã phiên chạy)."""

    def __init__(self, thong_diep):
        super().__init__('KHOI_DONG_KHONG_HOP_LE', thong_diep, thu_lai_duoc=False)


@dataclass(frozen=True, repr=False)
class ThongTinKhoiDong:
    core_url: str
    khoa: str
    instance: str

    def __repr__(self):
        return f'ThongTinKhoiDong(core_url={self.core_url!r}, khoa=<an>, instance={self.instance!r})'

    def __reduce__(self):
        raise TypeError('Không serialize thông tin khởi động')


def _la_may_cuc_bo(host):
    if host.lower() in _MAY_CUC_BO:
        return True
    try:
        return ipaddress.ip_address(host).is_loopback
    except ValueError:
        return False


def chuan_hoa_core_url(url):
    """Kiểm và bỏ dấu "/" cuối; http chỉ cho máy cục bộ."""
    if not isinstance(url, str) or not 1 <= len(url) <= 500:
        raise LoiKhoiDong('Địa chỉ Core không hợp lệ.')
    try:
        p = urllib.parse.urlsplit(url)
        host = p.hostname
        _ = p.port
    except ValueError:
        raise LoiKhoiDong('Địa chỉ Core không hợp lệ.') from None
    if p.scheme not in ('http', 'https') or not host or p.username or p.password \
            or p.query or p.fragment:
        raise LoiKhoiDong('Địa chỉ Core phải có dạng http(s)://máy:cổng, không kèm tài khoản.')
    if p.scheme == 'http' and not _la_may_cuc_bo(host):
        raise LoiKhoiDong('Core ở máy khác phải dùng https://.')
    return url.rstrip('/')


def _la_man_hinh(stdin):
    try:
        return stdin.isatty()
    except (AttributeError, ValueError, OSError):
        return False


def doc_khoi_dong(stdin=None, env=None):
    """Đọc địa chỉ Core, khóa engine, mã phiên chạy: dòng JSON trên stdin trước,
    biến môi trường sau. Trả ThongTinKhoiDong; thiếu/sai thì LoiKhoiDong."""
    stdin = sys.stdin if stdin is None else stdin
    env = os.environ if env is None else env
    du_lieu = None
    if stdin is not None and not _la_man_hinh(stdin):
        try:
            dong = stdin.readline(DONG_KHOI_DONG_TOI_DA + 1)
        except (OSError, ValueError):
            dong = ''
        if isinstance(dong, bytes):
            dong = dong.decode('utf-8', 'replace')
        if len(dong) > DONG_KHOI_DONG_TOI_DA:
            raise LoiKhoiDong('Dòng khởi động trên stdin quá dài.')
        if dong.strip():
            try:
                du_lieu = json.loads(dong)
            except ValueError:
                raise LoiKhoiDong('Dòng khởi động trên stdin không phải JSON.') from None
            if not isinstance(du_lieu, dict):
                raise LoiKhoiDong('Dòng khởi động phải là {"core_url", "khoa", "instance"}.')
    if du_lieu is None:
        if not env.get(BIEN_CORE_URL) or not env.get(BIEN_KHOA):
            raise LoiKhoiDong('Engine chưa nhận được địa chỉ Core và khóa engine. Core tự cấp '
                              'khi khởi động engine; chạy tay thì đặt biến môi trường '
                              f'{BIEN_CORE_URL} và {BIEN_KHOA}.')
        du_lieu = {'core_url': env.get(BIEN_CORE_URL), 'khoa': env.get(BIEN_KHOA),
                   'instance': env.get(BIEN_INSTANCE) or 'tay-' + uuid.uuid4().hex[:12]}
    core_url = chuan_hoa_core_url(du_lieu.get('core_url'))
    khoa = du_lieu.get('khoa')
    if not isinstance(khoa, str) or not _KHOA.fullmatch(khoa):
        raise LoiKhoiDong('Khóa engine không hợp lệ (16–512 ký tự ASCII, không khoảng trắng).')
    instance = du_lieu.get('instance')
    if not isinstance(instance, str) or not _INSTANCE.fullmatch(instance):
        raise LoiKhoiDong('Mã phiên chạy không hợp lệ.')
    du_lieu.clear()
    return ThongTinKhoiDong(core_url, khoa, instance)


class _KhongChuyenHuong(urllib.request.HTTPRedirectHandler):
    """Không theo chuyển hướng để khóa engine không bị gửi sang nơi khác."""

    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def _loi_tu_phan_hoi(status, raw):
    """Phong bì lỗi dạng phẳng {ma, thong_diep, request_id, thu_lai_duoc} (hợp đồng
    bản 1.3); vẫn đọc được dạng cũ {"loi": {...}}."""
    ma, thong_diep, thu_lai = 'LOI_HTTP', f'Core trả lỗi {status}.', False
    try:
        than = json.loads(raw.decode('utf-8'))
        loi = than.get('loi') if isinstance(than.get('loi'), dict) else than
        if isinstance(loi, dict):
            ma = loi.get('ma') if isinstance(loi.get('ma'), str) else ma
            thong_diep = loi.get('thong_diep') if isinstance(loi.get('thong_diep'), str) else thong_diep
            thu_lai = loi.get('thu_lai_duoc') is True
    except (ValueError, AttributeError, UnicodeDecodeError):
        pass
    thu_lai = thu_lai or status in (429, 500, 502, 503, 504)
    return LoiDuongTruyen(ma, thong_diep, http_status=status, thu_lai_duoc=thu_lai)


def _q(x):
    return urllib.parse.quote(str(x), safe='')


class DuongHttp(DuongTruyen):
    """Gọi API engine của Core qua HTTP (hợp đồng c.2)."""

    def __init__(self, core_url, ma_engine, khoa, instance, *, thoi_gian_cho=15, mo=None):
        if not isinstance(khoa, str) or not _KHOA.fullmatch(khoa):
            raise LoiKhoiDong('Khóa engine không hợp lệ.')
        if not isinstance(instance, str) or not _INSTANCE.fullmatch(instance):
            raise LoiKhoiDong('Mã phiên chạy không hợp lệ.')
        self._goc = chuan_hoa_core_url(core_url)
        self.ma_engine = ma_engine
        self.instance = instance
        self.__khoa = khoa
        self._cho = thoi_gian_cho
        self._mo = mo or urllib.request.build_opener(_KhongChuyenHuong())

    @classmethod
    def tu_khoi_dong(cls, ma_engine, *, stdin=None, env=None):
        tt = doc_khoi_dong(stdin, env)
        return cls(tt.core_url, ma_engine, tt.khoa, tt.instance)

    def __repr__(self):
        return f'DuongHttp(core_url={self._goc!r}, ma_engine={self.ma_engine!r}, khoa=<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize DuongHttp')

    def _goi(self, phuong_thuc, duong, *, json_body=_KHONG, du_lieu=None, loai=None,
             khoa=None, them=None, cho_them=0, nhi_phan=False, toi_da=JSON_TOI_DA_BYTE):
        headers = {'Authorization': 'Bearer ' + self.__khoa, 'X-KTT-Engine': self.ma_engine,
                   'X-KTT-Instance': self.instance, 'Accept': 'application/json'}
        if khoa is not None:
            headers['Idempotency-Key'] = khoa
        body = None
        if json_body is not _KHONG:
            body = json.dumps(json_body, ensure_ascii=False).encode('utf-8')
            headers['Content-Type'] = 'application/json; charset=utf-8'
        elif du_lieu is not None:
            body = du_lieu
            headers['Content-Type'] = loai
        if them:
            headers.update(them)
        req = urllib.request.Request(self._goc + duong, data=body, method=phuong_thuc,
                                     headers=headers)
        try:
            with self._mo.open(req, timeout=self._cho + cho_them) as r:
                status = r.status
                raw = r.read(toi_da + 1)
        except urllib.error.HTTPError as exc:
            try:
                raw = exc.read(65536)
            except Exception:
                raw = b''
            finally:
                exc.close()
            raise _loi_tu_phan_hoi(exc.code, raw) from None
        except (urllib.error.URLError, OSError, http.client.HTTPException):
            raise LoiDuongTruyen('KHONG_KET_NOI_CORE', 'Không kết nối được tới Core.',
                                 thu_lai_duoc=True) from None
        if len(raw) > toi_da:
            raise LoiDuongTruyen('VUOT_GIOI_HAN_KICH_THUOC', 'Core trả dữ liệu lớn quá giới hạn.',
                                 http_status=status)
        if status == 204:
            return None
        if nhi_phan:
            return raw
        if not raw:
            return {}
        try:
            return json.loads(raw.decode('utf-8'))
        except (ValueError, UnicodeDecodeError):
            raise LoiDuongTruyen('PHAN_HOI_SAI_CONTRACT', 'Core trả dữ liệu không đọc được.',
                                 http_status=status) from None

    def _engine(self, duoi):
        return f'/api/v1/engine/{_q(self.ma_engine)}/{duoi}'

    @staticmethod
    def _viec(viec_id, duoi):
        return f'/api/v1/engine/viec/{_q(viec_id)}/{duoi}'

    def san_sang(self, phien_ban, nang_luc):
        kq = self._goi('POST', self._engine('san-sang'), json_body={
            'instance': self.instance, 'phien_ban': phien_ban, 'nang_luc': list(nang_luc)})
        cau_hinh = kq.get('cau_hinh') if isinstance(kq, dict) else None
        return cau_hinh if isinstance(cau_hinh, dict) else {}

    def nhan_viec(self, cho_toi_da_giay):
        cho = max(0, min(int(cho_toi_da_giay), 30))
        kq = self._goi('POST', self._engine('viec/nhan'),
                       json_body={'cho_toi_da_giay': cho}, cho_them=cho)
        if kq is None:
            return None
        viec = kq.get('viec') if isinstance(kq, dict) else None
        if not isinstance(viec, dict):
            raise LoiDuongTruyen('PHAN_HOI_SAI_CONTRACT', 'Core trả việc không đọc được.')
        return viec

    def doc_dau_vao(self, viec_id):
        return self._goi('GET', self._viec(viec_id, 'dau-vao'))

    def mo_tep(self, viec_id, tep_id, toi_da_byte):
        return self._goi('GET', self._viec(viec_id, f'tep/{_q(tep_id)}'), nhi_phan=True,
                         toi_da=toi_da_byte)

    def tai_tep_ra(self, viec_id, ten, du_lieu, mime, khoa):
        # Tên tệp có thể có dấu: gửi dạng percent-encoding UTF-8.
        return self._goi('POST', self._viec(viec_id, 'tep'), du_lieu=du_lieu, loai=mime,
                         khoa=khoa, them={'X-KTT-Ten-Tep': urllib.parse.quote(ten, safe='')})

    def gia_han(self, viec_id, han_giu_giay):
        return self._goi('POST', self._viec(viec_id, 'gia-han'),
                         json_body={'han_giu_giay': int(han_giu_giay)})

    def tien_do(self, viec_id, phan_tram, cau):
        return self._goi('POST', self._viec(viec_id, 'tien-do'),
                         json_body={'phan_tram': phan_tram, 'cau': cau})

    def nop_ket_qua(self, viec_id, phong_bi, khoa):
        return self._goi('PUT', self._viec(viec_id, 'ket-qua'), json_body=phong_bi, khoa=khoa)

    def ket_thuc(self, viec_id, than, khoa):
        return self._goi('POST', self._viec(viec_id, 'ket-thuc'), json_body=than, khoa=khoa)
