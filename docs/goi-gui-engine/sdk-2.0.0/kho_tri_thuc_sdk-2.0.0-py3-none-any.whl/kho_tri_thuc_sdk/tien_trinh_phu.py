"""Helper kỹ thuật cho tiến trình phụ; không nạp host, cấu hình hoặc nguồn."""

import threading


# Chỉ runtime/guard và biến kỹ thuật; không giữ DSN, API key hay env nghiệp vụ.
ENV_GIU = frozenset(k.upper() for k in ("SYSTEMROOT", "WINDIR", "SYSTEMDRIVE", "TEMP", "TMP", "PATH", "PATHEXT", "COMSPEC", "NUMBER_OF_PROCESSORS",
                                        "PROCESSOR_ARCHITECTURE", "PYTHONPATH", "PYTHONHOME", "PYTHONUSERBASE", "CODEX_NO_DELETE_FILES"))


def _bat(v) -> bool:
    return str(v or "").strip().lower() in ("1", "true", "yes", "on")


def _doc_dong(stream, han: float):
    """Đọc MỘT dòng bắt tay trong hạn (luồng phụ, không chặn vô hạn)."""
    kq = []
    t = threading.Thread(target=lambda: kq.append(stream.readline(64 * 1024)), daemon=True)
    t.start()
    t.join(han)
    return kq[0] if kq else None
