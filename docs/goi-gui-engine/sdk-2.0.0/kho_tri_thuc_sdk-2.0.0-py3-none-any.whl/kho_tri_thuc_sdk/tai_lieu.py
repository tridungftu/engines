"""Façade tài liệu §3.3 qua kênh N2, không truy cập kho hoặc CSDL.

Bootstrap cấp ``ngu_canh_kenh(ctx, operation)`` trả binding kênh đã ghim.
``thong_tin`` khi tạo gồm loai, ten, doi_tuong, phien_ban_contract và
sha256 từ tham chiếu upload (CAS hash); không nhận ID tài liệu hay actor.
Tạo trả metadata định danh; gọi lay bằng quyền XEM để đọc phiên bản hiện tại.
Runtime N3 cấp kênh gắn request; N2 trực tiếp dùng binding và parent đã kiểm.
Nghiệp vụ chọn thu_tu_con dương, ổn định qua replay cho từng call con.
"""

from __future__ import annotations

from datetime import datetime, timezone
import re
import time
from typing import NotRequired, TypedDict
from uuid import UUID

from .dich_vu import LoiDichVu, _DichVu
from .du_lieu_rieng import Trang
from .kenh_core import KenhCore, PhanHoiCore
from .kenh_khung import LoiKenh
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


class TaiLieu(TypedDict):
    id: str
    phap_nhan_id: str
    module: str
    loai: str
    ten: str
    row_version: NotRequired[str]
    tao_luc: NotRequired[str]
    tep: NotRequired[list]
    ket_qua: NotRequired[list]


def _uuid(value):
    try:
        return str(UUID(str(value)))
    except (ValueError, TypeError, AttributeError):
        raise LoiDichVu('KENH_DU_LIEU_KHONG_HOP_LE', 422) from None


class DichVuTaiLieu(_DichVu):
    __slots__ = ('__kenh', '__ngu_canh', '__parent')

    def __init__(self, kenh_core=None, *, ngu_canh_kenh=None, parent=None):
        if kenh_core is not None and not callable(getattr(kenh_core, 'goi', None)):
            raise TypeError('Cần kênh Core N2 do bootstrap cấp')
        if ngu_canh_kenh is not None and not callable(ngu_canh_kenh):
            raise TypeError('Cần binding kênh do bootstrap cấp')
        self.__kenh, self.__ngu_canh, self.__parent = kenh_core, ngu_canh_kenh, parent

    def _goi(self, ctx, operation, data, khoa=None, *, thu_tu_con=None):
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den):
            raise LoiDichVu('KENH_XAC_THUC_KHONG_HOP_LE', 401)
        if self.__kenh is None or (isinstance(self.__kenh, KenhCore)
                and self.__ngu_canh is None):
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        loi = None
        try:
            call_con = self.__parent is not None or self.__ngu_canh is None
            if ((call_con and (type(thu_tu_con) is not int or thu_tu_con <= 0))
                    or (not call_con and thu_tu_con is not None)):
                raise LoiKenh('KENH_DU_LIEU_KHONG_HOP_LE')
            binding = ctx
            if self.__ngu_canh is not None:
                binding = dict(self.__ngu_canh(ctx, operation))
                if (any(binding.get(key) != str(getattr(ctx, key)) for key in
                        ('nguoi_dung_id', 'phap_nhan_id', 'instance_id', 'module'))
                        or binding.get('hanh_dong') != ctx.hanh_dong):
                    raise LoiKenh('KENH_KHONG_DU_QUYEN')
                # Không kéo dài hạn của request đã xác minh.
                deadline = datetime.fromisoformat(binding['deadline'].replace('Z', '+00:00'))
                binding['deadline'] = min(deadline,
                    datetime.fromtimestamp(ctx.hieu_luc_den, timezone.utc)).isoformat()
            args = dict(ngu_canh=binding, khoa=khoa)
            if call_con:
                args['thu_tu_con'] = thu_tu_con
            if self.__parent is not None:
                args['parent'] = self.__parent
            response = self.__kenh.goi(operation, data, **args)
            if not isinstance(response, PhanHoiCore):
                raise LoiKenh('PHAN_HOI_SAI_CONTRACT')
            if operation == 'tai_lieu.tao' and response.header.get('da_commit') is not True:
                raise LoiKenh('PHAN_HOI_SAI_CONTRACT')
            try:
                result = response.json()
            except Exception as exc:
                _xoa_loi(exc)
                raise LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
        except Exception as exc:
            loi = (exc.ma, exc.http_status) if isinstance(exc, LoiKenh) else ('LOI_NOI_BO', 500)
            _xoa_loi(exc)
        if loi is not None:
            raise LoiDichVu(*loi) from None
        return result

    @staticmethod
    def _tai_lieu(row, ctx):
        can = {'id', 'phap_nhan_id', 'module', 'loai', 'ten'}
        if (not isinstance(row, dict) or not can <= row.keys()
                or row.keys() - can - {'row_version', 'tao_luc', 'tep', 'ket_qua'}
                or row['module'] != ctx.module
                or row['phap_nhan_id'] != str(ctx.phap_nhan_id)):
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
        try:
            UUID(row['id'])
            if any(not isinstance(row[key], str) or not row[key] for key in ('loai', 'ten')):
                raise ValueError()
            if 'row_version' in row and not re.fullmatch('[1-9][0-9]{0,18}', row['row_version']):
                raise ValueError()
        except (ValueError, TypeError, AttributeError):
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502) from None
        return row

    def liet_ke(self, ctx, loc, con_tro=None, *, thu_tu_con=None) -> Trang[TaiLieu]:
        if (not isinstance(loc, dict) or loc.keys() - {'bien_the', 'gioi_han'}
                or type(loc.get('gioi_han', 25)) is not int
                or not 1 <= loc.get('gioi_han', 25) <= 100
                or loc.get('bien_the', 'goc') not in
                    ('goc', 'ocr', 'da_che', 'noi_dung', 'phan_hoi_nguon')
                or (con_tro is not None and (not isinstance(con_tro, str)
                    or not re.fullmatch('[A-Za-z0-9_-]{1,4096}', con_tro)))):
            raise LoiDichVu('KENH_DU_LIEU_KHONG_HOP_LE', 422)
        result = self._goi(ctx, 'tai_lieu.liet_ke', dict(loc=dict(loc), con_tro=con_tro),
                           thu_tu_con=thu_tu_con)
        if (not isinstance(result, dict) or result.keys() !=
                {'danh_sach', 'con_tiep', 'con_tro_tiep'}
                or not isinstance(result['danh_sach'], list)
                or len(result['danh_sach']) > loc.get('gioi_han', 25)
                or type(result['con_tiep']) is not bool
                or (result['con_tiep'] and (not isinstance(result['con_tro_tiep'], str)
                    or not re.fullmatch('[A-Za-z0-9_-]{1,4096}', result['con_tro_tiep'])
                    or not result['danh_sach']))
                or (not result['con_tiep'] and result['con_tro_tiep'] is not None)):
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
        return Trang([self._tai_lieu(row, ctx) for row in result['danh_sach']],
                     result['con_tiep'], result['con_tro_tiep'])

    def lay(self, ctx, tai_lieu_id, *, thu_tu_con=None) -> TaiLieu:
        id_ = _uuid(tai_lieu_id)
        result = self._tai_lieu(self._goi(ctx, 'tai_lieu.lay', dict(tai_lieu_id=id_),
                                       thu_tu_con=thu_tu_con), ctx)
        if result['id'] != id_:
            raise LoiDichVu('PHAN_HOI_SAI_CONTRACT', 502)
        return result

    def tao(self, ctx, tep_id, thong_tin, khoa, *, thu_tu_con=None) -> TaiLieu:
        if (not isinstance(khoa, str) or not re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa)
                or not isinstance(thong_tin, dict) or thong_tin.keys() !=
                    {'loai', 'ten', 'doi_tuong', 'phien_ban_contract', 'sha256'}
                or not isinstance(thong_tin['sha256'], str)
                or not re.fullmatch('[0-9a-f]{64}', thong_tin['sha256'])):
            raise LoiDichVu('KENH_DU_LIEU_KHONG_HOP_LE', 422)
        if (any(not isinstance(thong_tin[key], str) or not thong_tin[key].strip()
                for key in ('loai', 'ten', 'phien_ban_contract'))
                or not isinstance(thong_tin['doi_tuong'], dict)
                or thong_tin['doi_tuong'].keys() != {'bang', 'id'}
                or not isinstance(thong_tin['doi_tuong']['bang'], str)
                or not thong_tin['doi_tuong']['bang'].strip()):
            raise LoiDichVu('KENH_DU_LIEU_KHONG_HOP_LE', 422)
        thong_tin = dict(thong_tin, doi_tuong=dict(thong_tin['doi_tuong'],
                           id=_uuid(thong_tin['doi_tuong']['id'])))
        return self._tai_lieu(self._goi(ctx, 'tai_lieu.tao',
            dict(tep_id=_uuid(tep_id), thong_tin=dict(thong_tin)), khoa,
            thu_tu_con=thu_tu_con), ctx)
