"""Consumer module: nhận, nghiệp vụ và ACK trên cùng transaction module.

Composition root truyền manifest đã cài, registry callable tin cậy và ctx đã
được NhanRequest kiểm, có quyền <MODULE>:SU_KIEN:SUA. Không import handler
theo chuỗi, tự đăng ký subscription hay tự dựng danh tính. Không cần RPC mới:
ba method bus là cửa T, phải giữ nguyên kết nối module tới commit/rollback.
Tác động ngoài PostgreSQL cần cơ chế đối chiếu riêng, không hứa exactly-once.
"""

from copy import deepcopy
import math
import re
from threading import Condition, Event
import time

from .dich_vu import LoiDichVu, _ctx, su_kien
from .giao_dich import CuaGiaoDich


# Thông báo Core phát cho module (HOP-DONG-CONG.md c.4). Module khai loại muốn
# nhận trong `su_kien.nhan` của module.json (bản 1) như mọi sự kiện bus; phong
# bì chỉ mang tham chiếu (mã việc, mã kết quả, bảng ghép), không nội dung.
SU_KIEN_CORE_CHO_MODULE = ('viec.da_nhan', 'viec.tien_do', 'viec.buoc_xong',
                           'quy_trinh.xong', 'quy_trinh.loi', 'viec.huy')


def la_thong_bao_core(sk):
    """Sự kiện bus `sk` có phải thông báo việc/quy trình do Core phát không."""
    return isinstance(sk, dict) and sk.get('loai_su_kien') in SU_KIEN_CORE_CHO_MODULE


class NhanSuKien:
    """Một lượt hữu hạn qua xu_ly(ctx); chay(cap_ngu_canh) chạy trên thread caller.

    cap_ngu_canh phải cấp ctx mới đã xác minh cho từng lượt/pháp nhân; không
    giữ hoặc tự gia hạn ctx. Bootstrap ngừng consumer trước khi đóng pool và
    chỉ báo drain thành công sau khi drain() trả True. Lỗi thoát transaction;
    chay không nuốt lỗi, ModuleRuntime gọi lại có backoff để nhận lại từ inbox
    bền vững, luôn xin ctx mới do Core cấp và NhanRequest kiểm chứng.
    """

    def __init__(self, *, khai_bao, cua_giao_dich, handlers, gioi_han=100):
        if (not isinstance(cua_giao_dich, CuaGiaoDich)
                or type(gioi_han) is not int or not 1 <= gioi_han <= 1000
                or not isinstance(khai_bao, dict) or not isinstance(handlers, dict)):
            raise LoiDichVu('SDK_BUS_CAU_HINH', 422)
        m = deepcopy(khai_bao)
        if m.get('ma') != cua_giao_dich.module:
            raise LoiDichVu('SDK_MODULE', 403)
        try:
            pins = {(v['ma'], v['phien_ban']) for v in m['contract']['su_kien_nhan']}
            ds = m['su_kien']['nhan']
            if not isinstance(ds, list):
                raise ValueError()
            registry = {}
            for v in ds:
                loai, ban, ten = v['loai'], v['phien_ban'], v['xu_ly']
                if (not isinstance(loai, str) or not re.fullmatch('[a-z][a-z0-9_.]{0,95}', loai)
                        or type(ban) is not int or not 1 <= ban < 2**31
                        or (loai, str(ban)) not in pins or (loai, ban) in registry
                        or not callable(handlers[ten])):
                    raise ValueError()
                registry[loai, ban] = handlers[ten]
        except (KeyError, TypeError, ValueError):
            raise LoiDichVu('SDK_BUS_CAU_HINH', 422) from None
        self._module = m['ma']
        self._cua, self._handlers, self._gioi_han = cua_giao_dich, registry, gioi_han
        self._dieu_kien, self._dung = Condition(), Event()
        self._dang_chay = 0

    def __repr__(self):
        return 'NhanSuKien(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize consumer bus')

    def xu_ly(self, ctx):
        """Trả số đã commit; lỗi cả batch rollback và được giao lại lần sau."""
        with self._dieu_kien:
            if self._dung.is_set():
                return 0
            self._dang_chay += 1
        try:
            if not self._handlers:
                return 0
            so = 0
            with self._cua.giao_dich(ctx) as tx:
                ctx = _ctx(tx)
                if ctx.module != self._module or ctx.hanh_dong != self._module.upper() + ':SU_KIEN:SUA':
                    raise LoiDichVu('BUS_HANH_DONG', 403)
                # Lọc theo loại đã ghim; SQL kiểm subscription/gói/công tắc/quyền
                # hiện tại. Kiểm phiên bản trước handler, không chọn bản mới nhất.
                for loai in dict.fromkeys(k[0] for k in self._handlers):
                    for sk in su_kien.nhan(tx, loai=loai, gioi_han=self._gioi_han - so):
                        ban = sk['phien_ban']
                        handler = self._handlers.get((sk['loai_su_kien'], ban)) if type(ban) is int else None
                        if (sk['loai_su_kien'] != loai or handler is None
                                or sk['phien_ban_contract'] != str(ban)):
                            raise LoiDichVu('BUS_CONTRACT', 422)
                        # Handler không thể đổi ID đích ACK qua dict sự kiện.
                        event_id = sk['id']
                        handler(tx, sk)
                        if su_kien.xac_nhan(tx, event_id) is not True:
                            raise LoiDichVu('BUS_CHUA_NHAN', 409)
                        so += 1
                    if so == self._gioi_han:
                        break
            return so
        finally:
            with self._dieu_kien:
                self._dang_chay -= 1
                self._dieu_kien.notify_all()

    def chay(self, cap_ngu_canh, *, nhip=1):
        """Polling hữu hạn nhịp; lỗi truyền về supervisor sau rollback."""
        if (not callable(cap_ngu_canh) or isinstance(nhip, bool)
                or not isinstance(nhip, (int, float)) or not math.isfinite(nhip)
                or not 0 < nhip <= 5):
            raise ValueError('Nhịp consumer phải trong (0, 5] giây')
        while True:
            # Tính cả thời gian xin ctx: drain không được trả về trong khi
            # provider còn dùng kênh/credential mà bootstrap sắp đóng.
            with self._dieu_kien:
                if self._dung.is_set():
                    return
                self._dang_chay += 1
            try:
                self.xu_ly(cap_ngu_canh())
            finally:
                with self._dieu_kien:
                    self._dang_chay -= 1
                    self._dieu_kien.notify_all()
            self._dung.wait(nhip)

    def ngung_nhan(self):
        with self._dieu_kien:
            self._dung.set()

    def drain(self, timeout=30):
        if (isinstance(timeout, bool) or not isinstance(timeout, (int, float))
                or not math.isfinite(timeout) or not 0 <= timeout <= 300):
            raise ValueError('Hạn drain không hợp lệ')
        self.ngung_nhan()
        han = time.monotonic() + timeout
        with self._dieu_kien:
            while self._dang_chay:
                con = han - time.monotonic()
                if con <= 0:
                    return False
                self._dieu_kien.wait(con)
            return True
