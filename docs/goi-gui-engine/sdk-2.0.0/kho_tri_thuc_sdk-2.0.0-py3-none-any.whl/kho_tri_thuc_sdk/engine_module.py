"""Module gọi engine qua N2/N3; SDKEngine dành riêng cho tiến trình engine.

Bootstrap cấp binding theo (operation, hành động cha). dau_vao là tham chiếu
việc gồm loai/phien_ban/bang_tham_chieu/tham_chieu_id, không chứa pins hay
credential. K ghi chạy ngoài transaction module; không tự retry/fallback.
"""
from datetime import datetime, timezone
import re
import time

from .dich_vu import LoiDichVu, _DichVu
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi
from .quy_trinh import BienNhanViec


def _capability(value):
    from . import kenh_khung as k
    k._can(type(value) is str and re.fullmatch(r'[a-z][a-z0-9_.]*@[1-9][0-9]*', value))
    return value


def _dau_vao(data):
    from . import kenh_khung as k
    k._dong(data, {'loai', 'phien_ban', 'bang_tham_chieu', 'tham_chieu_id'},
        {'co_tac_dong_ngoai', 'thu_lai_an_toan', 'toi_da_lan_thu', 'thu_lai_giay', 'giu_ngay'})
    k._can(type(data['loai']) is str and re.fullmatch('[A-Z][A-Z0-9_-]{0,79}', data['loai'])
        and type(data['phien_ban']) is int and 1 <= data['phien_ban'] < 2**31
        and type(data['bang_tham_chieu']) is str
        and 1 <= len(data['bang_tham_chieu']) <= 200
        and data['bang_tham_chieu'] == data['bang_tham_chieu'].strip()
        and k._uuid(data['tham_chieu_id']))
    for key in ('co_tac_dong_ngoai', 'thu_lai_an_toan'):
        k._can(key not in data or type(data[key]) is bool)
    for key, limit in (('toi_da_lan_thu', 100), ('thu_lai_giay', 86400), ('giu_ngay', 36500)):
        if key in data and not (key == 'giu_ngay' and data[key] is None):
            k._can(type(data[key]) is int and 1 <= data[key] <= limit)
    return dict(data)


def _kha_nang(row):
    from . import kenh_khung as k
    ma = 'PHAN_HOI_SAI_CONTRACT'
    k._dong(row, {'capability', 'engine_id', 'ma_engine', 'phien_ban_engine',
                  'adapter', 'dau_vao', 'dau_ra'}, ma=ma)
    k._can(type(row['capability']) is str
        and re.fullmatch(r'[a-z][a-z0-9_.]*@[1-9][0-9]*', row['capability'])
        and k._uuid(row['engine_id']) and type(row['ma_engine']) is str
        and re.fullmatch('[a-z][a-z0-9_]{0,30}', row['ma_engine']), ma)
    versions = [row['phien_ban_engine']]
    for field in ('adapter', 'dau_vao', 'dau_ra'):
        k._dong(row[field], {'ma', 'phien_ban'}, ma=ma)
        k._can(type(row[field]['ma']) is str
            and re.fullmatch('[a-z][a-z0-9_.]{0,95}', row[field]['ma']), ma)
        versions.append(row[field]['phien_ban'])
    k._can(all(type(v) is str and re.fullmatch(r'[0-9][0-9A-Za-z_.+\-]{0,63}', v)
               for v in versions), ma)
    return row


class EngineModule(_DichVu):
    __slots__ = ('__kenh', '__binding', '__parent')

    def __init__(self, kenh_core=None, *, ngu_canh_kenh=None, parent=None):
        if kenh_core is not None:
            from .kenh_core import KenhCore
            from .module_runtime import _KenhRequest
        if kenh_core is not None and not isinstance(kenh_core, (KenhCore, _KenhRequest)):
            raise TypeError('Cần kênh module → Core do bootstrap cấp')
        if ngu_canh_kenh is not None and not callable(ngu_canh_kenh):
            raise TypeError('Cần binding kênh do bootstrap cấp')
        self.__kenh, self.__binding, self.__parent = kenh_core, ngu_canh_kenh, parent

    def _goi(self, ctx, operation, data, khoa=None, *, thu_tu_con=None):
        from . import kenh_khung as k
        from .kenh_core import KenhCore, PhanHoiCore
        if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
                or time.time() >= ctx.hieu_luc_den):
            raise LoiDichVu('KENH_XAC_THUC_KHONG_HOP_LE', 401)
        if ctx.module == 'core' or not ctx.hanh_dong.startswith(ctx.module.upper() + ':'):
            raise LoiDichVu('KENH_KHONG_DU_QUYEN', 403)
        if self.__kenh is None or (isinstance(self.__kenh, KenhCore) and self.__binding is None):
            raise LoiDichVu('CHUA_SAN_SANG', 503)
        error = None
        try:
            child = self.__parent is not None or self.__binding is None
            k._can((type(thu_tu_con) is int and thu_tu_con > 0) if child else thu_tu_con is None)
            h = ctx
            if self.__binding is not None:
                h = dict(self.__binding(ctx, operation))
                k._can(all(h.get(key) == str(getattr(ctx, key)) for key in
                    ('module', 'nguoi_dung_id', 'phap_nhan_id', 'instance_id'))
                    and h.get('hanh_dong') == ctx.hanh_dong, 'KENH_KHONG_DU_QUYEN')
                deadline = datetime.fromisoformat(h['deadline'].replace('Z', '+00:00'))
                h['deadline'] = min(deadline,
                    datetime.fromtimestamp(ctx.hieu_luc_den, timezone.utc)).isoformat()
            args = dict(ngu_canh=h, khoa=khoa)
            if child:
                args['thu_tu_con'] = thu_tu_con
            if self.__parent is not None:
                args['parent'] = self.__parent
            response = self.__kenh.goi(operation, data, **args)
            k._can(isinstance(response, PhanHoiCore)
                and response.header.get('stream') is None, 'PHAN_HOI_SAI_CONTRACT')
            ghi = operation == 'engine.gui_viec'
            k._can(response.header.get('status') == (202 if ghi else 200)
                and (not ghi or response.header.get('da_commit') is True), 'PHAN_HOI_SAI_CONTRACT')
            try:
                result = response.json()
            except Exception as exc:
                _xoa_loi(exc)
                raise k.LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
            if operation == 'engine.liet_ke':
                k._dong(result, {'danh_sach'}, ma='PHAN_HOI_SAI_CONTRACT')
                result = result['danh_sach']
                k._can(type(result) is list, 'PHAN_HOI_SAI_CONTRACT')
                for row in result:
                    _kha_nang(row)
                k._can(len({r['capability'] for r in result}) == len(result), 'PHAN_HOI_SAI_CONTRACT')
            elif ghi:
                k._dong(result, {'viec_id', 'trang_thai', 'request_id'}, ma='PHAN_HOI_SAI_CONTRACT')
                k._can(k._uuid(result['viec_id']) and result['trang_thai'] == 'queued'
                    and k._uuid(result['request_id'])
                    and result['request_id'] == response.header.get('request_id'), 'PHAN_HOI_SAI_CONTRACT')
            else:
                _kha_nang(result)
                k._can(result['capability'] == data['capability'], 'PHAN_HOI_SAI_CONTRACT')
        except Exception as exc:
            error = (exc.ma, exc.http_status) if isinstance(exc, k.LoiKenh) else ('LOI_NOI_BO', 500)
            _xoa_loi(exc)
        if error is not None:
            raise LoiDichVu(*error) from None
        return result

    def liet_ke(self, ctx, *, thu_tu_con=None):
        return self._goi(ctx, 'engine.liet_ke', {}, thu_tu_con=thu_tu_con)

    def kha_nang(self, ctx, capability, *, thu_tu_con=None):
        return self._goi(ctx, 'engine.kha_nang', dict(capability=_capability(capability)),
                         thu_tu_con=thu_tu_con)

    def gui_viec(self, ctx, capability, dau_vao, khoa, *, thu_tu_con=None) -> BienNhanViec:
        from . import kenh_khung as k
        k._can(type(khoa) is str and re.fullmatch('[A-Za-z0-9._:-]{16,128}', khoa))
        return self._goi(ctx, 'engine.gui_viec',
            dict(capability=_capability(capability), dau_vao=_dau_vao(dau_vao)),
            khoa, thu_tu_con=thu_tu_con)


DichVuEngineModule = EngineModule
engine = EngineModule()
