"""Listener module trên socket bootstrap; không import server Core.

Composition root cấp registry ``tra(method, path) -> (route, params)`` đã nạp
gói kiểm G2-24, validator offline ``kiem(schema, value)`` và binding(route)
trả (contract_id, sha256_schema). Route có giao diện Route của Dispatcher;
handler nhận (GiaoDich, NguCanhHTTP), trả PhanHoi hoặc ViecMoi bên dưới.
NguCanhHTTP.ctx là NguCanh đã kiểm; .dich_vu có danh_tinh/V1, .kenh_core
gọi con với ngu_canh=ctx và thu_tu_con ổn định do nghiệp vụ chọn. binding_core
do composition root ghim theo (operation, hanh_dong của cha), gồm hanh_dong/contract_id/
phien_ban_contract/ma_bam_schema. Không lấy các binding này từ HTTP body.
HandlerCoChuanBi cho phép gọi Core GHI trước transaction module; thân handler
vẫn ghi/CAS và lưu biên nhận module trong transaction như handler thông thường.
Không tải gói/schema, import handler theo chuỗi, tự bind hay kết nối về Core.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from collections.abc import Mapping
from copy import deepcopy
from contextlib import contextmanager
from contextvars import ContextVar
from datetime import datetime
import hashlib
import json
import re
import select
import socket
import struct
import threading
import time
from types import SimpleNamespace
from urllib.parse import parse_qsl, unquote
from uuid import UUID

from ._core import tiep_nhan, viec
from ._core.phien import MaBiMat
from . import kenh_khung as k
from .giao_dich import CuaGiaoDich
from .dich_vu import DichVu
from .nhan_su_kien import NhanSuKien
from .kenh_core import KenhCore, GHI
from .danh_tinh import nhan_request
from .ngu_canh import NhanRequest, LoiNguCanh, _json_cac_cap, _xoa_loi


_NGU_CANH_CALLBACK = ContextVar('ngu_canh_callback_module', default=None)


def ngu_canh_callback(tx):
    """Chỉ cấp context của handler đang chạy trên chính transaction này."""
    current = _NGU_CANH_CALLBACK.get()
    if current is not None and current[0] is tx and current[1].ctx is tx.ngu_canh:
        return current[1]
    return None


@dataclass(frozen=True, repr=False)
class PhanHoi:
    status: int
    body: object = None
    headers: dict = field(default_factory=dict)
    da_commit: bool = False  # Runtime không tin giá trị handler tự đặt.


@dataclass(frozen=True, repr=False)
class ViecMoi:
    loai: str
    tham_chieu_id: UUID
    bang_tham_chieu: str
    phien_ban: int = 1
    tuy_chon: dict = field(default_factory=dict)


@dataclass(frozen=True, repr=False)
class HandlerCoChuanBi:
    """Handler hai bước, chỉ dùng cho route GHI có chống trùng.

    Composition root dựng ``Route(..., handler=HandlerCoChuanBi(chuan_bi, xu_ly))``
    hoặc dùng ``dataclasses.replace`` với route đã có.
    ``chuan_bi(context) -> ket_qua`` chạy sau xác thực/schema/CAS đầu vào và
    khóa request, trước khi mở transaction module. Bước này có ``context.ctx``,
    ``context.kenh_core`` và ``context.dich_vu.danh_tinh`` đã ghim quyền; không
    có transaction hay repository module. Không tự mở transaction trong bước này.
    ``xu_ly(tx, context, ket_qua)`` nhận nguyên kết quả chuẩn bị, trả PhanHoi
    hoặc ViecMoi như handler cũ; ghi module vẫn phải dùng CAS trong ``tx``.

    Ví dụ chuan_bi gọi ``context.kenh_core.goi('tep.tham_chieu', dto,
    ngu_canh=context.ctx, thu_tu_con=1)`` rồi trả phản hồi cho xu_ly.
    Callback phải kiểm ``response.header['da_commit'] is True`` (với lệnh ghi)
    và đầu ra đúng contract trước khi trả kết quả.
    Dùng DTO, ID đích và thu_tu_con cố định cho cùng khóa request; không sinh
    ID/thời điểm mới mỗi lần thử. Kênh cũ dẫn khóa con từ khóa cha, operation,
    thu_tu_con và Core kiểm quyền/biên nhận; không cấp khóa hay binding từ body.

    Chuẩn bị chạy lại cả khi replay module. Nếu Core đã commit nhưng module
    rollback (kể cả CAS/commit lỗi), gửi lại cùng khóa VÀ cùng nội dung để Core
    trả kết quả cũ theo biên nhận, không gắn trùng. Runtime không cache kết quả,
    tự retry hay hoàn tác Core. Biên nhận module vẫn được tra trước thân xu_ly
    và CAS ghi; lỗi chuẩn bị không mở transaction module.
    """

    chuan_bi: object
    xu_ly: object

    def __post_init__(self):
        if not callable(self.chuan_bi) or not callable(self.xu_ly):
            raise TypeError('Hai bước handler phải là callable')

    def __call__(self, tx, context):
        return self.xu_ly(tx, context, context.ket_qua_chuan_bi)


class _NguCanhHTTP(SimpleNamespace):
    def __repr__(self):
        return 'NguCanhHTTP(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize ngữ cảnh HTTP module')


class _HeaderCha(Mapping):
    def __init__(self, header):
        self._header = deepcopy(header)

    def __getitem__(self, key):
        return deepcopy(self._header[key])

    def __iter__(self):
        return iter(self._header)

    def __len__(self):
        return len(self._header)

    def __repr__(self):
        return 'HeaderCha(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize header cha')


class _KenhRequest:
    """Gắn call con vào đúng ctx/cha; binding chỉ do composition root cấp."""

    def __init__(self, kenh, ctx, parent, binding):
        self._kenh, self._ctx = kenh, ctx
        self._parent, self._binding = deepcopy(parent), binding
        self._tx = None
        self._song = True

    def __repr__(self):
        return 'KenhRequest(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize kênh request')

    def tx_dang_mo(self):
        return self._tx is not None

    @contextmanager
    def giao_dich(self, cua):
        k._can(not self.tx_dang_mo(), 'XUNG_DOT')
        try:
            with cua.giao_dich(self._ctx) as tx:
                self._tx = tx
                yield tx
        finally:
            self._tx = None

    def goi(self, operation, du_lieu, *, ngu_canh, thu_tu_con, khoa=None, tep=None):
        k._can(self._song and ngu_canh is self._ctx, 'KENH_KHONG_DU_QUYEN')
        key = (operation, self._parent['hanh_dong'])
        k._can(key in self._binding, 'CHUA_SAN_SANG')
        pin = self._binding[key]
        k._can(type(pin) is dict and pin.keys() == {
            'hanh_dong', 'contract_id', 'phien_ban_contract', 'ma_bam_schema'})
        k._can(pin['hanh_dong'] == self._parent['hanh_dong'] == self._ctx.hanh_dong,
               'KENH_KHONG_DU_QUYEN')
        header = dict(self._parent, **{name: pin[name] for name in (
            'contract_id', 'phien_ban_contract', 'ma_bam_schema')})
        # Kiểm tx trên thread handler; reader không giữ hoặc suy từ payload.
        k._can(not (operation in GHI and self.tx_dang_mo()), 'XUNG_DOT')
        return self._kenh.goi(operation, du_lieu, ngu_canh=header,
            parent=self._parent, thu_tu_con=thu_tu_con, khoa=khoa, tep=tep)


class _KiemTheKetQua(k.BoKiemThe):
    """Một bộ mỗi reader: phân biệt lỗi thẻ với lỗi proof/header của decoder.

    Chỉ sau khi decoder trả frame đầy đủ mới được dùng hop_le để trả 401.
    Không bắt lỗi proof/header rồi parse lại hoặc suy từ bộ đếm proof.
    """

    def __init__(self, bo_kiem):
        self._bo_kiem = bo_kiem
        self.hop_le = False

    def kiem(self, header):
        self.hop_le = False
        try:
            self._bo_kiem.kiem(header)
        except k.LoiKenh as exc:
            _xoa_loi(exc)
        else:
            self.hop_le = True


def _json(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')


def _doc_du(sock, n, *, han=None):
    raw = bytearray()
    while len(raw) < n:
        if han is not None:
            con = han - time.monotonic()
            if con <= 0 or not select.select([sock], [], [], con)[0]:
                raise TimeoutError('Đọc frame quá hạn')
        part = sock.recv(n - len(raw))
        if not part:
            raise EOFError()
        raw.extend(part)
    return bytes(raw)


def doc_frame(sock, *, timeout=None):
    """Kiểm length trước cấp phát; timeout chỉ tính từ byte đầu của frame.

    Deadline đọc riêng, không đổi timeout socket dùng chung với luồng ghi.
    """
    parts = []
    dau = _doc_du(sock, 1) if timeout is not None else b''
    han = time.monotonic() + timeout if timeout is not None else None
    for limit in (k.GIOI_HAN_HEADER, k.GIOI_HAN_JSON, k.GIOI_HAN_PROOF):
        size = dau + _doc_du(sock, 4 - len(dau), han=han)
        dau = b''
        n = struct.unpack('!I', size)[0]
        if n > limit:
            raise k.LoiKenh('VUOT_GIOI_HAN_KICH_THUOC')
        parts.extend((size, _doc_du(sock, n, han=han)))
    return b''.join(parts)


def _cac_phan(wire):
    pos, parts = 0, []
    for _ in range(3):
        n = struct.unpack_from('!I', wire, pos)[0]
        pos += 4
        parts.append(wire[pos:pos + n])
        pos += n
    return parts


def _loi(exc, *, route=None):
    """Chỉ gửi mã đã khai và hai chi tiết dự án hữu hạn; bỏ text/metadata thô."""
    ma = getattr(exc, 'ma', None)
    status = getattr(exc, 'http_status', getattr(exc, 'status', 500))
    chi_tiet = k._chi_tiet_loi(ma, status, getattr(exc, 'chi_tiet', None))
    thu_lai_duoc = getattr(exc, 'thu_lai_duoc', None)
    if (route is not None and isinstance(ma, str) and type(status) is int
            and (status, ma) in route.ma_loi):
        if (not re.fullmatch('[A-Z][A-Z0-9_]{0,79}', ma) or not 400 <= status <= 599
                or k.MA_LOI_HTTP.get(ma, status) != status):
            return k.LoiKenh('PHAN_HOI_SAI_CONTRACT')
        loi = k.LoiKenh(ma, retry_after=getattr(exc, 'retry_after', None),
                       chi_tiet=chi_tiet, thu_lai_duoc=thu_lai_duoc)
        loi.ma, loi.http_status = ma, status
        return loi
    aliases = {'SDK_NGU_CANH': 'KENH_XAC_THUC_KHONG_HOP_LE',
               'SDK_UY_NHIEM': 'KENH_XAC_THUC_KHONG_HOP_LE',
               'VIEC_KHOA_KHAC_NOI_DUNG': 'KHOA_CHONG_TRUNG_KHAC_NOI_DUNG',
               'VIEC_CAS': 'XUNG_DOT', 'XUNG_DOT_PHIEN_BAN': 'XUNG_DOT',
               'VIEC_MAT_LEASE': 'MAT_LEASE'}
    ma = aliases.get(ma, ma) if isinstance(ma, str) else None
    status = status if type(status) is int else 500
    if ma not in k.MA_LOI_HTTP:
        ma = {400: 'YEU_CAU_KHONG_HOP_LE', 401: 'KENH_XAC_THUC_KHONG_HOP_LE',
              403: 'KENH_KHONG_DU_QUYEN', 404: 'KHONG_TIM_THAY', 405: 'KHONG_TIM_THAY', 409: 'XUNG_DOT',
              413: 'VUOT_GIOI_HAN_KICH_THUOC', 422: 'KENH_DU_LIEU_KHONG_HOP_LE',
              429: 'VUOT_HAN_MUC', 502: 'PHAN_HOI_SAI_CONTRACT',
              503: 'CHUA_SAN_SANG', 504: 'PHAN_HOI_QUA_HAN'}.get(status, 'LOI_NOI_BO')
    return k.LoiKenh(ma, retry_after=getattr(exc, 'retry_after', None),
                     chi_tiet=chi_tiet, thu_lai_duoc=thu_lai_duoc)


def _can(value, ma='KENH_DU_LIEU_KHONG_HOP_LE'):
    if not value:
        raise k.LoiKenh(ma)


class ModuleRuntime:
    """Dựng không mở socket/DB; chỉ nhận BM-KENH một lần trong RAM.

    ``core_epoch`` và public key do composition root ghim, không lấy từ frame.
    ``chay`` gọi Bootstrap.accept sau bao_san_sang/nhan_accept; composition root
    ghép cho_thu_hoi(ngung_accept=runtime.ngung_accept, drain=runtime.drain).
    Consumer tùy chọn nhận manifest/handlers và provider ctx đã xác minh riêng;
    cap_ngu_canh_su_kien=None hoặc kenh_su_kien_bat=False giữ consumer tắt.
    chay khởi chạy consumer sau nhan_accept; drain chờ cả provider/transaction
    và thread consumer trước khi bỏ credential/đóng kênh. loi_su_kien là mã
    lỗi hữu hạn gần nhất; consumer thử lại sau rollback với backoff có trần.
    phuc_vu(sock) cũng dùng được với socketpair để kiểm thử không mở server.
    """

    def __init__(self, *, bootstrap, khoa_cong_khai, core_epoch, registry,
                 binding, kiem, cua_giao_dich, dong_ho=time.time,
                 binding_core=None, khai_bao=None, truy_van=None, lenh=None,
                 khai_bao_su_kien=None, handlers_su_kien=None,
                 cap_ngu_canh_su_kien=None, kenh_su_kien_bat=True):
        cfg = bootstrap._cfg
        _can(isinstance(cua_giao_dich, CuaGiaoDich)
             and cua_giao_dich.module == cfg['module']
             and callable(registry.tra) and callable(binding) and callable(kiem.kiem)
             and isinstance(core_epoch, str) and bool(core_epoch))
        self._bootstrap, self._registry = bootstrap, registry
        self._binding, self._kiem, self._cua = binding, kiem, cua_giao_dich
        self._gio = dong_ho
        self._module, self._phien_ban = cfg['module'], cfg['phien_ban']
        self._the = k.BoKiemThe(khoa_cong_khai, issuer=cfg['issuer'],
            core_epoch=core_epoch, instance_id=str(cfg['instance_id']),
            the_he=cfg['the_he'], nonce_khoi_dong=cfg['nonce_khoi_dong'],
            module=cfg['module'], dong_ho=dong_ho)
        self._nhan = NhanRequest(issuer=cfg['issuer'], module=cfg['module'],
            instance_id=cfg['instance_id'], nonce_khoi_dong=cfg['nonce_khoi_dong'],
            kiem_chu_ky=khoa_cong_khai.verify, dong_ho=dong_ho)
        self._credential = bootstrap.bi_mat.lay_mot_lan()
        _can(len(self._credential) >= 32, 'KENH_XAC_THUC_KHONG_HOP_LE')
        self._dieu_kien = threading.Condition()
        self._dung = False
        self._dang_chay = 0
        self._clients, self._call, self._ket_noi, self._khoa = set(), {}, {}, set()
        _can(binding_core is None or type(binding_core) is dict)
        self._binding_core = deepcopy(binding_core or {})
        self.du_lieu_rieng = None
        if any(v is not None for v in (khai_bao, truy_van, lenh)):
            self.du_lieu_rieng = DichVu(None, khai_bao=khai_bao,
                cua_giao_dich=cua_giao_dich, truy_van=truy_van, lenh=lenh).du_lieu_rieng
        self._tx_local = threading.local()
        # Provider chỉ do composition root cấp khi kênh đã được cấu hình.
        # Không lấy ctx từ HTTP, không tự đăng ký handler hoặc bật module TAT.
        self._consumer, self._luong_consumer = None, None
        self._cap_ngu_canh_su_kien = cap_ngu_canh_su_kien
        self.loi_su_kien = None
        if kenh_su_kien_bat and cap_ngu_canh_su_kien is not None and handlers_su_kien:
            _can(callable(cap_ngu_canh_su_kien))
            self._consumer = NhanSuKien(khai_bao=khai_bao_su_kien,
                cua_giao_dich=cua_giao_dich, handlers=handlers_su_kien)

    def __repr__(self):
        return 'ModuleRuntime(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize runtime module')

    def ngung_accept(self):
        # Không đóng bản listener: bootstrap giữ đến khi drain xong.
        with self._dieu_kien:
            self._dung = True
            self._dieu_kien.notify_all()
            if self._consumer is not None:
                self._consumer.ngung_nhan()

    def _chay_consumer(self):
        cho = .1
        while True:
            with self._dieu_kien:
                if self._dung:
                    return
            try:
                self._consumer.chay(self._cap_ngu_canh_su_kien)
                return
            except Exception as exc:
                # Transaction đã rollback; lượt sau xin ctx mới rồi đọc inbox.
                # Chỉ giữ mã hữu hạn, bỏ exception/ctx/credential của lượt lỗi.
                self.loi_su_kien = 'CONSUMER_THAT_BAI'
                _xoa_loi(exc)
            with self._dieu_kien:
                if self._dung:
                    return
                self._dieu_kien.wait(cho)
            cho = min(5, cho * 2)

    def drain(self, timeout=30):
        self.ngung_accept()
        han = time.monotonic() + timeout
        if self._consumer is not None:
            if not self._consumer.drain(timeout=max(0, han - time.monotonic())):
                return False
            if self._luong_consumer is not None:
                self._luong_consumer.join(max(0, han - time.monotonic()))
                if self._luong_consumer.is_alive():
                    return False
        with self._dieu_kien:
            while self._dang_chay:
                con = han - time.monotonic()
                if con <= 0:
                    return False
                self._dieu_kien.wait(con)
            clients = list(self._clients)
            self._credential = None
        for sock in clients:
            self._dong(sock)
        return True

    @staticmethod
    def _dong(sock):
        try:
            sock.shutdown(socket.SHUT_RDWR)
        except OSError:
            pass
        sock.close()

    def chay(self):
        """Accept chỉ trên listener Core chuyển qua bootstrap, không tự bind."""
        # Chỉ chạy consumer sau khi bootstrap nhận quyền accept của Core.
        _can(self._bootstrap._duoc_accept, 'CHUA_SAN_SANG')
        self._bootstrap.socket.settimeout(.2)
        while True:
            with self._dieu_kien:
                if self._dung:
                    return
                if self._consumer is not None and (self._luong_consumer is None
                        or not self._luong_consumer.is_alive()):
                    self._luong_consumer = threading.Thread(target=self._chay_consumer, daemon=True)
                    self._luong_consumer.start()
            try:
                sock, _ = self._bootstrap.accept()
            except socket.timeout:
                continue
            threading.Thread(target=self.phuc_vu, args=(sock,), daemon=True).start()

    def phuc_vu(self, sock):
        """Một reader cho mỗi socket; handler không chặn reader hoặc khóa ghi."""
        ghi = threading.Lock()
        kid = None
        kenh = None
        with self._dieu_kien:
            if self._dung or len(self._clients) >= 4:
                self._dong(sock)
                return
            self._clients.add(sock)
        try:
            wire = doc_frame(sock, timeout=30)
            # ID/challenge chỉ để chọn miền MAC; chưa tin bất kỳ header nào.
            trailer = k._doc_json(_cac_phan(wire)[2])
            proof = k.BoProof(self._credential, trailer.get('ket_noi_id'), vai='con')
            challenge = k.giai_ma_frame(wire, proof)
            _can(challenge.header['kieu'] == 'challenge' and challenge.than == b'')
            with self._dieu_kien:
                now = time.monotonic()
                self._ket_noi = {cid: den for cid, den in self._ket_noi.items() if den > now}
                candidate = trailer['ket_noi_id']
                _can(candidate not in self._ket_noi and len(self._ket_noi) < 100000,
                     'KENH_XAC_THUC_KHONG_HOP_LE')
                kid = candidate
                # Giữ ID suốt kết nối; sau đóng giữ thêm cửa sổ replay 30s.
                self._ket_noi[kid] = float('inf')
            def gui_frame(header, raw, han):
                # Một khóa bao cả cấp proof lẫn gửi bytes ở mọi chiều.
                with ghi:
                    wire = memoryview(k.ma_hoa_frame(header, raw, proof))
                    while wire:
                        con = han - time.monotonic()
                        if con <= 0 or not select.select([], [sock], [], con)[1]:
                            raise TimeoutError()
                        wire = wire[sock.send(wire):]

            gui_frame(dict(challenge.header, kieu='xac_thuc', chieu='con_den_core'),
                      b'', time.monotonic() + 30)
            kenh = KenhCore(gui_frame=gui_frame, kiem_the=self._the,
                tx_dang_mo=lambda: getattr(self._tx_local, 'mo', False))
            kiem_the = _KiemTheKetQua(self._the)
            while True:
                # Mọi lỗi proof/header/hash đều kết thúc kết nối; không dùng
                # bộ đếm proof để suy rằng header đã đủ an toàn dựng response.
                frame = k.giai_ma_frame(doc_frame(sock, timeout=30), proof, kiem_the=kiem_the)
                if frame.header['kieu'] != 'request':
                    kenh.nhan_frame(frame)
                    continue
                _can(frame.header['kieu'] == 'request'
                     and frame.header['operation'] == 'module.thuc_thi')
                if not kiem_the.hop_le:
                    self._gui(sock, proof, ghi, frame,
                              loi=k.LoiKenh('KENH_XAC_THUC_KHONG_HOP_LE'))
                    continue
                with self._dieu_kien:
                    now = self._gio()
                    self._call = {cid: den for cid, den in self._call.items() if den > now}
                    cid = frame.header['call_id']
                    _can(cid not in self._call and len(self._call) < 100000,
                         'KENH_XAC_THUC_KHONG_HOP_LE')
                    # Thẻ sống <=30s; giữ call qua toàn bộ cửa sổ replay chữ ký.
                    self._call[cid] = now + 30
                    loi = (k.LoiKenh('TIEN_TRINH_DANG_DUNG', retry_after=2) if self._dung
                           else k.LoiKenh('VUOT_HAN_MUC') if self._dang_chay >= 4 else None)
                    if loi is None:
                        self._dang_chay += 1
                if loi is not None:
                    self._gui(sock, proof, ghi, frame, loi=loi)
                else:
                    threading.Thread(target=self._xu_ly,
                        args=(sock, proof, ghi, frame, kenh), daemon=True).start()
        except Exception as exc:
            _xoa_loi(exc)
        finally:
            if kenh is not None:
                kenh.dong()
            with self._dieu_kien:
                self._clients.discard(sock)
                if kid is not None:
                    self._ket_noi[kid] = time.monotonic() + 30
            self._dong(sock)

    def _gui(self, sock, proof, ghi, frame, *, body=None, status=200,
             bien_nhan=None, loi=None, da_commit=False):
        h = frame.header
        raw = _json(body) if body is not None else b''
        header = dict(protocol=k.PROTOCOL, phien_ban=k.PHIEN_BAN, kieu='response',
            chieu='con_den_core', request_id=h['request_id'], call_id=h['call_id'],
            operation='module.thuc_thi', status=loi.http_status if loi else status,
            da_commit=da_commit, bien_nhan=bien_nhan, hash_than=hashlib.sha256(raw).hexdigest(),
            stream=None, loi=None)
        if loi:
            header['loi'] = dict(ma=loi.ma, thong_diep='Yêu cầu không xử lý được.',
                request_id=h['request_id'], thu_lai_duoc=loi.thu_lai_duoc,
                http_status=loi.http_status)
            chi_tiet = k._chi_tiet_loi(loi.ma, loi.http_status,
                                     getattr(loi, 'chi_tiet', None))
            if chi_tiet is not None:
                header['loi']['chi_tiet'] = chi_tiet
            if loi.retry_after is not None:
                header['retry_after'] = loi.retry_after
        with ghi:
            sock.sendall(k.ma_hoa_frame(header, raw, proof))

    def _context(self, frame):
        h, raw = frame.header, frame.than
        http = h['http']
        target = http['path_query']
        path, _, query = target.partition('?')
        _can(not target.startswith('//') and '#' not in target
             and not re.search(r'%(?![0-9A-Fa-f]{2})', target), 'YEU_CAU_KHONG_HOP_LE')
        try:
            path = unquote(path, errors='strict')
            pairs = parse_qsl(query, keep_blank_values=True, encoding='utf-8',
                              errors='strict', max_num_fields=100)
        except (ValueError, UnicodeError):
            raise k.LoiKenh('YEU_CAU_KHONG_HOP_LE') from None
        query = dict(pairs)
        _can(len(query) == len(pairs), 'YEU_CAU_KHONG_HOP_LE')
        route, params = self._registry.tra(http['method'], path)
        contract, schema_hash = self._binding(route)
        _can(route.chu_so_huu == 'module' and route.module == self._module
             and route.pham_vi == h['pham_vi'] == 'phap_nhan'
             and route.phien == 'bat_buoc' and route.phien_ban_goi == self._phien_ban
             and isinstance(route.ma_bam_goi, str)
             and re.fullmatch('[0-9a-f]{64}', route.ma_bam_goi)
             and route.hanh_dong == h['hanh_dong']
             and (contract, route.phien_ban_contract, schema_hash) == (
                 h['contract_id'], h['phien_ban_contract'], h['ma_bam_schema'])
             and h['parent_call_id'] is None and h['thu_tu_con'] is None,
             'KENH_KHONG_DU_QUYEN')
        _can(datetime.fromisoformat(h['deadline'].replace('Z', '+00:00')).timestamp()
             > self._gio(), 'PHAN_HOI_QUA_HAN')
        ctx = nhan_request(dict(the=MaBiMat(http['the_ngu_canh']),
            method=http['method'], duong_dan=target, body=raw,
            operation=route.operation, hanh_dong=route.hanh_dong, khoa=h['khoa']), self._nhan)
        _can((str(ctx.request_id), str(ctx.nguoi_dung_id), str(ctx.phap_nhan_id),
              ctx.module_nguon, ctx.ma.lay_de_truyen()) == (h['request_id'],
              h['nguoi_dung_id'], h['phap_nhan_id'], h['module_nguon'], h['uy_nhiem']['ma'])
             and h['uy_nhiem']['loai'] == 'UY_NHIEM_PHIEN'
             and h['uy_nhiem']['viec_id'] is None and h['uy_nhiem']['the_he_lease'] is None,
             'KENH_XAC_THUC_KHONG_HOP_LE')
        try:
            body = json.loads(raw, object_pairs_hook=_json_cac_cap,
                              parse_constant=k._khong_hang) if raw else None
            _json(body)  # Chặn cả số mũ float tràn thành Infinity.
        except (ValueError, UnicodeError, RecursionError):
            raise k.LoiKenh() from None
        trang = None
        if route.thu_tu is not None:
            # Decoder đã kiểm schema và proof MAC của extension. Chỉ dùng
            # ngữ cảnh Core đã kiểm; query gốc vẫn giữ để kiểm hash HTTP.
            ct = h.get('con_tro')
            _can(ct is not None, 'KENH_XAC_THUC_KHONG_HOP_LE')
            query.pop('con_tro', None)
            query.pop('kich_thuoc_trang', None)
            trang = _NguCanhHTTP(kich_thuoc=ct['kich_thuoc'], khoa_sau=ct['khoa_sau'])
        else:
            _can('con_tro' not in h, 'KENH_KHONG_DU_QUYEN')
        _can(self._kiem.kiem(route.dau_vao, body)
             and self._kiem.kiem(route.query_schema, query)
             and (route.path_schema is None or self._kiem.kiem(route.path_schema, params)))
        for name in route.truong_cas:
            value = body.get(name) if isinstance(body, dict) else None
            if name == 'row_version':
                try:
                    viec._cas(value)
                except ValueError:
                    raise k.LoiKenh() from None
            else:
                _can(value is not None)
        context = _NguCanhHTTP(request_id=h['request_id'], nguoi_dung_id=ctx.nguoi_dung_id,
            phap_nhan_id=ctx.phap_nhan_id, module=ctx.module, operation=route.operation,
            hanh_dong=ctx.hanh_dong,
            doi_tuong={} if route.loai == 'danh_sach' else route.doi_tuong(params, body),
            body=body, path=params, query=query, khoa=ctx.khoa, trang=trang,
            than_goc=raw, path_query=target)
        context.ctx = ctx
        context.header_cha = _HeaderCha(h)
        return route, ctx, context

    def _kiem_phan_hoi(self, route, result, context):
        status = getattr(result, 'status', None)
        if route.thu_tu is not None and type(status) is int and status < 400:
            # Payload nội bộ; Core kiểm lại keyset, ký con trỏ rồi mới kiểm
            # schema public. Module không giữ khóa ký con trỏ của Core.
            data = getattr(result, 'body', None)
            _can(status == 200 and status in route.dau_ra
                 and not route.ghi and context.trang is not None
                 and type(data) is dict and set(data) == {'danh_sach', 'cac_khoa'}
                 and type(data['danh_sach']) is list and type(data['cac_khoa']) is list,
                 'PHAN_HOI_SAI_CONTRACT')
            keys = data['cac_khoa']
            try:
                _can(len(data['danh_sach']) == len(keys) <= context.trang.kich_thuoc + 1
                     and all(type(key) is list and key for key in keys),
                     'PHAN_HOI_SAI_CONTRACT')
                for key in keys:
                    UUID(key[-1])
                _can(not any(a >= b for a, b in zip(keys, keys[1:]))
                     and (not keys or context.trang.khoa_sau is None
                          or keys[0] > context.trang.khoa_sau), 'PHAN_HOI_SAI_CONTRACT')
                raw = _json(data)
            except (TypeError, ValueError, AttributeError, RecursionError):
                raise k.LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
            _can(len(raw) <= k.GIOI_HAN_JSON, 'VUOT_GIOI_HAN_KICH_THUOC')
            return PhanHoi(200, data)
        _can(type(getattr(result, 'status', None)) is int and hasattr(result, 'body')
             and result.status in route.dau_ra
             and self._kiem.kiem(route.dau_ra[result.status], result.body),
             'PHAN_HOI_SAI_CONTRACT')
        if result.status >= 400:
            ma = result.body.get('ma') if type(result.body) is dict else None
            _can(isinstance(ma, str) and (result.status, ma) in route.ma_loi
                 and self._kiem.kiem({'$ref': 'urn:ktt:contract:loi_chuan.v1'}, result.body),
                 'PHAN_HOI_SAI_CONTRACT')
            raise _loi(SimpleNamespace(ma=ma, http_status=result.status), route=route)
        _can((result.status == 202) == route.viec_lau, 'PHAN_HOI_SAI_CONTRACT')
        body = result.body
        if result.status == 202:
            try:
                UUID(body['viec_id'])
            except (TypeError, KeyError, ValueError):
                raise k.LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
        if isinstance(body, dict) and 'request_id' in body:
            body = {**body, 'request_id': context.request_id}
        try:
            raw = _json(body)
        except (TypeError, ValueError, RecursionError):
            raise k.LoiKenh('PHAN_HOI_SAI_CONTRACT') from None
        _can(len(raw) <= k.GIOI_HAN_JSON, 'VUOT_GIOI_HAN_KICH_THUOC')
        return PhanHoi(result.status, body)

    def _thuc_hien(self, tx, route, ctx, context):
        """Quy tắc Dispatcher: replay trước CAS/handler, V2 cùng tx nghiệp vụ."""
        ts = dict(ma=ctx.ma, module=ctx.module, phap_nhan_id=ctx.phap_nhan_id,
            hanh_dong=ctx.hanh_dong, operation=route.operation, khoa=ctx.khoa,
            noi_dung=dict(body=context.body, path=context.path, query=context.query),
            doi_tuong=context.doi_tuong, phien_ban_contract=route.phien_ban_contract)
        if route.chong_trung:
            cu = tiep_nhan.tra_thao_tac(tx, **ts)
            if cu is not None:
                value = cu['ket_qua']
                return self._kiem_phan_hoi(route, PhanHoi(value['status'], value['body']), context)
        token = _NGU_CANH_CALLBACK.set((tx, context))
        try:
            result = route.handler(tx, context)
        finally:
            _NGU_CANH_CALLBACK.reset(token)
        if isinstance(result, ViecMoi):
            _can(route.viec_lau and route.chong_trung, 'PHAN_HOI_SAI_CONTRACT')
            key = 'http:' + hashlib.sha256(_json([
                str(ctx.nguoi_dung_id), route.operation, ctx.khoa])).hexdigest()
            id_ = viec.tao_viec(tx, result.loai, result.phien_ban, key, result.tham_chieu_id,
                bang_tham_chieu=result.bang_tham_chieu, phien_ban_contract=route.phien_ban_contract,
                **result.tuy_chon, ma=ctx.ma, module=ctx.module,
                phap_nhan_id=ctx.phap_nhan_id, hanh_dong=ctx.hanh_dong)
            result = PhanHoi(202, dict(viec_id=str(id_), trang_thai='queued', request_id=context.request_id))
        elif route.viec_lau:
            # Không tin handler tự khai 202/chứng thực đã tạo việc.
            _can(type(getattr(result, 'status', None)) is int and result.status >= 400,
                 'PHAN_HOI_SAI_CONTRACT')
        result = self._kiem_phan_hoi(route, result, context)
        tx._kiem()
        if route.chong_trung:
            _can(callable(route.quyen_doc), 'LOI_NOI_BO')
            tiep_nhan.ghi_thao_tac(tx, ket_qua=dict(status=result.status, body=result.body),
                quyen_doc=route.quyen_doc(context, result.body), **ts)
        return result

    def _xu_ly(self, sock, proof, ghi, frame, kenh=None):
        lock_key = None
        committed = False
        route = None
        request_kenh = None
        try:
            route, ctx, context = self._context(frame)
            request_kenh = _KenhRequest(kenh, ctx, frame.header, self._binding_core)
            context.kenh_core = request_kenh
            if route.chong_trung:
                candidate = (ctx.nguoi_dung_id, ctx.phap_nhan_id, route.operation, ctx.khoa)
                with self._dieu_kien:
                    _can(candidate not in self._khoa, 'YEU_CAU_DANG_XU_LY')
                    self._khoa.add(candidate)
                    lock_key = candidate
            if isinstance(route.handler, HandlerCoChuanBi):
                _can(route.ghi and route.chong_trung and bool(ctx.khoa), 'XUNG_DOT')
                context.dich_vu = DichVu(None, kenh_danh_tinh=request_kenh)
                context.ket_qua_chuan_bi = route.handler.chuan_bi(context)
            with request_kenh.giao_dich(self._cua) as tx:
                repo = self.du_lieu_rieng
                if repo is not None and route.chong_trung:
                    repo = repo._cho_runtime(tx)
                context.dich_vu = DichVu(None, du_lieu_rieng=repo,
                                        kenh_danh_tinh=request_kenh)
                self._tx_local.mo = True
                try:
                    result = self._thuc_hien(tx, route, ctx, context)
                finally:
                    self._tx_local.mo = False
            committed = True
            # CuaGiaoDich đã commit gốc và dọn connection; chỉ runtime xác nhận.
            receipt = (dict(chu=self._module, operation='module.thuc_thi', khoa=ctx.khoa)
                       if route.chong_trung else None)
            self._gui(sock, proof, ghi, frame, body=result.body, status=result.status,
                      bien_nhan=receipt, da_commit=True)
        except Exception as exc:
            loi = (k.LoiKenh('KENH_XAC_THUC_KHONG_HOP_LE') if isinstance(exc, LoiNguCanh)
                   else _loi(exc, route=route))
            _xoa_loi(exc)
            if committed:
                # Đứt socket sau commit là chưa rõ ở Core; không gửi lỗi giả
                # da_commit=false và không replay tự động.
                self._dong(sock)
            else:
                try:
                    self._gui(sock, proof, ghi, frame, loi=loi)
                except Exception as gui_exc:
                    _xoa_loi(gui_exc)
                    self._dong(sock)
        finally:
            if request_kenh is not None:
                request_kenh._song = False
            with self._dieu_kien:
                if lock_key is not None:
                    self._khoa.discard(lock_key)
                self._dang_chay -= 1
                self._dieu_kien.notify_all()
