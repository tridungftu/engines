"""Dịch vụ SDK: cửa T dùng GiaoDich caller, cửa tệp K qua kênh N2.

Không nhận danh tính từ payload, không commit hoặc giữ connection sau request.
Core sở hữu kho bytes; adapter đọc cục bộ cũ được giữ để tương thích.
"""

from __future__ import annotations

import time
from uuid import UUID

from ._core import su_kien as _bus, tai_lieu as _tl, tiep_nhan as _tn, viec as _viec
from .giao_dich import GiaoDich, LoiGiaoDich
from .ngu_canh import NguCanh, _DA_KIEM, _xoa_loi


class LoiDichVu(RuntimeError):
    def __init__(self, ma='SDK_DICH_VU', http_status=400):
        self.ma, self.http_status = ma, http_status
        super().__init__(ma)


class _DichVu:
    __slots__ = ()

    def __repr__(self):
        return 'DichVuSDK(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize dịch vụ SDK')


def _ctx(tx):
    if not isinstance(tx, GiaoDich):
        raise LoiGiaoDich('SDK_NGU_CANH', 401)
    tx._kiem()
    ctx = tx.ngu_canh
    if (not isinstance(ctx, NguCanh) or ctx._da_kiem is not _DA_KIEM
            or time.time() >= ctx.hieu_luc_den):
        raise LoiGiaoDich('SDK_NGU_CANH', 401)
    return ctx


def _danh_tinh(ctx):
    return dict(ma=ctx.ma, module=ctx.module, phap_nhan_id=ctx.phap_nhan_id,
                hanh_dong=ctx.hanh_dong)


def _kiem_phien_ban_contract(phien_ban):
    if (not isinstance(phien_ban, str) or not phien_ban.strip()
            or phien_ban != phien_ban.strip()):
        raise LoiDichVu('SDK_CONTRACT_PHIEN_BAN', 422)
    return phien_ban


def _phien_ban_contract(khai_bao, module, phien_ban=None):
    """Chỉ đọc binding/ham_core_goi do bootstrap cấp, không suy từ bản module.

    Khai báo là manifest (dict hoặc đối tượng có ma, ham_core_goi), hoặc
    đối tượng có ma và binding resolver_mtq đã được Core kiểm. Có nhiều bản
    resolver thì caller phải chọn rõ một bản đã khai báo.
    """
    def lay(ten):
        return khai_bao.get(ten) if isinstance(khai_bao, dict) else getattr(khai_bao, ten, None)

    if khai_bao is None:
        raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
    if lay('ma') != module:
        raise LoiDichVu('SDK_MODULE', 403)
    binding = lay('binding')
    if binding is not None:
        if not isinstance(binding, dict) or binding.get('module') != module:
            raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
        ds = [binding]
    else:
        ds = lay('ham_core_goi')
    if not isinstance(ds, (list, tuple)):
        raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
    if phien_ban is not None:
        _kiem_phien_ban_contract(phien_ban)
    cac_ban = []
    for entry in ds:
        if not isinstance(entry, dict):
            raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
        if entry.get('loai_ham') == 'resolver_mtq':
            if entry.get('module', module) != module:
                raise LoiDichVu('SDK_MODULE', 403)
            ban = _kiem_phien_ban_contract(entry.get('phien_ban_contract'))
            if phien_ban is None or phien_ban == ban:
                cac_ban.append(ban)
    if len(cac_ban) != 1:
        raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
    return cac_ban[0]


def _goi(tx, ham, **tham_so):
    ctx = _ctx(tx)
    if set(tham_so) & {'ma', 'module', 'phap_nhan_id', 'hanh_dong', 'nguoi_dung_id',
                        'actor', 'request_id', 'viec_id', 'the_he'}:
        raise LoiDichVu('SDK_DANH_TINH', 403)
    loi = None
    status = 400
    try:
        return ham(tx, **tham_so, **_danh_tinh(ctx))
    except Exception as exc:
        # GiaoDich đã lọc driver. Vẫn xóa lỗi từ callback/KhoTep và chain Core.
        ma = getattr(exc, 'ma', '')
        if ma in _tl._LOI or ma in _viec._LOI or ma in _tn._LOI or ma in _bus._LOI:
            loi = ma
            http_status = getattr(exc, 'http_status', None)
            if type(http_status) is int and 400 <= http_status <= 599:
                status = http_status
        _xoa_loi(exc)
    finally:
        tham_so = ham = ma = None
    raise LoiDichVu(loi or 'SDK_DICH_VU', status) from None


def _sql(tx, cau, ts):
    _ctx(tx)
    status = 500
    loi = 'SDK_DICH_VU'
    try:
        return tx.execute(cau, ts).fetchone()[0]
    except Exception as exc:
        chinh = getattr(getattr(exc, 'diag', None), 'message_primary', None)
        if isinstance(chinh, str) and (chinh in _tl._LOI or chinh in _viec._LOI):
            loi = chinh
        state = getattr(exc, 'sqlstate', None)
        status = 403 if state == '42501' else 409 if state in {'40001', '55000'} else 400 if (
            isinstance(state, str) and state.startswith(('22', '23'))) else 500
        _xoa_loi(exc)
    finally:
        cau = ts = state = chinh = None
    raise LoiDichVu(loi, status) from None


class _KetQua(_DichVu):
    __slots__ = ()

    def ghi(self, tx, *, tai_lieu_id, du_lieu, giu_viec=None):
        # Nợ §3.3: bổ sung khoa chống trùng ở lát tiếp nhận/Dispatcher sau.
        ctx = _ctx(tx)
        data = _tl._truong(du_lieu, {'tep_id', 'bien_the', 'ma_contract',
            'phien_ban_contract', 'trang_thai', 'ly_do', 'revision_truoc', 'nguon'}, {'goc_id'})
        _tl._bien_the(data['bien_the'])
        _tl._so(data['revision_truoc'])
        ts = (ctx.ma.lay_de_truyen(), ctx.module, ctx.phap_nhan_id, ctx.hanh_dong)
        job = (None, None)
        if giu_viec is not None:
            if (not isinstance(giu_viec, _viec.GiuViec) or giu_viec.module != ctx.module
                    or giu_viec.phap_nhan_id != ctx.phap_nhan_id
                    or giu_viec.hanh_dong != ctx.hanh_dong):
                raise LoiDichVu('SDK_DANH_TINH', 403)
            # Core kiểm lại phiên của lease/thế hệ và lấy bước/lần thử từ hàng việc.
            ts = (giu_viec.ma.lay_de_truyen(), ctx.module, ctx.phap_nhan_id, ctx.hanh_dong)
            job = (giu_viec.viec_id, giu_viec.the_he)
        # SQL kiểm lại schema, nguồn/hash/revision và gắn nguồn Core đã xác minh.
        try:
            return _sql(tx, 'SELECT loi_tai_lieu.ghi_ket_qua_v2(%s,%s,%s,%s,%s,%s::jsonb,%s,%s,%s)',
                (*ts, UUID(str(tai_lieu_id)), _tn._json(data), ctx.request_id, *job))
        finally:
            ts = job = None

    def tao_revision(self, tx, *, tai_lieu_id, ket_qua_id, revision_truoc, du_lieu):
        # Kết quả cũ bất biến; SQL đối chiếu gốc và revision hiện hành.
        if set(du_lieu) & {'goc_id', 'revision_truoc'}:
            raise LoiDichVu('SDK_DAU_VAO')
        return self.ghi(tx, tai_lieu_id=tai_lieu_id, du_lieu={**du_lieu,
            'goc_id': str(UUID(str(ket_qua_id))), 'revision_truoc': revision_truoc})

    def lay(self, tx, *, tai_lieu_id, ket_qua_id, bien_the):
        view = _goi(tx, _tl.lay, tai_lieu_id=tai_lieu_id, bien_the=bien_the)
        for row in view['ket_qua']:
            if row['id'] == str(UUID(str(ket_qua_id))):
                return row
        raise LoiDichVu('TAI_LIEU_KHONG_THAY', 404)


class _KetQuaKenh(_DichVu):
    """K1: binding N3; chỉ ACK sau commit, không truyền SQL/nguồn Core."""
    __slots__ = ('__kenh', '__ngu_canh')

    def __init__(self, kenh, ngu_canh):
        from . import kenh_khung as k
        from .kenh_core import KenhCore
        k._can(isinstance(kenh, KenhCore) and type(ngu_canh) is dict
               and set(ngu_canh) == {'ket_qua.ghi', 'ket_qua.tao_revision', 'ket_qua.lay'}
               and all(type(h) is dict for h in ngu_canh.values()))
        self.__kenh = kenh
        self.__ngu_canh = {op: dict(h) for op, h in ngu_canh.items()}

    def _goi(self, op, ctx, data, khoa=None, thu_tu_con=None):
        from . import kenh_khung as k
        got = self.__kenh.goi(op, data, ngu_canh=self.__ngu_canh[op],
            parent=ctx, khoa=khoa, thu_tu_con=thu_tu_con)
        k._can(got.header['stream'] is None, 'PHAN_HOI_SAI_CONTRACT')
        if op != 'ket_qua.lay':
            k._can(got.header['da_commit'] is True, 'PHAN_HOI_SAI_CONTRACT')
            result = got.json()
            k._dong(result, {'ket_qua_id'}, ma='PHAN_HOI_SAI_CONTRACT')
            k._can(k._uuid(result['ket_qua_id']), 'PHAN_HOI_SAI_CONTRACT')
            return result['ket_qua_id']
        result = got.json()
        ma = 'PHAN_HOI_SAI_CONTRACT'
        k._dong(result, {'id', 'goc_id', 'revision', 'tep_id', 'trang_thai',
                        'trang_thai_duyet', 'row_version', 'cong_bo'}, ma=ma)
        k._can(result['id'] == data['ket_qua_id'] and k._uuid(result['goc_id'])
               and type(result['revision']) is int and result['revision'] > 0
               and (result['tep_id'] is None or k._uuid(result['tep_id']))
               and result['trang_thai'] in ('cho', 'dang_xu_ly', 'thanh_cong', 'loi')
               and result['trang_thai_duyet'] in ('chua_duyet', 'da_duyet', 'tu_choi')
               and type(result['row_version']) is str and result['row_version'].isascii()
               and 1 <= len(result['row_version']) <= 19 and result['row_version'].isdigit()
               and 0 < int(result['row_version']) < 2**63
               and type(result['cong_bo']) is bool, ma)
        return result

    def ghi(self, ctx, *, tai_lieu_id, du_lieu, khoa, giu_viec=None, thu_tu_con=None):
        data = dict(tai_lieu_id=str(tai_lieu_id), du_lieu=du_lieu)
        if giu_viec is not None:
            data['giu_viec'] = giu_viec
        return self._goi('ket_qua.ghi', ctx, data, khoa, thu_tu_con)

    def tao_revision(self, ctx, *, tai_lieu_id, ket_qua_id, revision_truoc,
                     du_lieu, khoa, giu_viec=None, thu_tu_con=None):
        data = dict(tai_lieu_id=str(tai_lieu_id), ket_qua_id=str(ket_qua_id),
                    revision_truoc=revision_truoc, du_lieu=du_lieu)
        if giu_viec is not None:
            data['giu_viec'] = giu_viec
        return self._goi('ket_qua.tao_revision', ctx, data, khoa, thu_tu_con)

    def lay(self, ctx, *, tai_lieu_id, ket_qua_id, bien_the, thu_tu_con=None):
        return self._goi('ket_qua.lay', ctx, dict(tai_lieu_id=str(tai_lieu_id),
            ket_qua_id=str(ket_qua_id), bien_the=bien_the), thu_tu_con=thu_tu_con)


class _Tep(_DichVu):
    __slots__ = ('__kho',)

    def __init__(self, kho):
        self.__kho = kho

    def tham_chieu(self, tx, *, tai_lieu_id, tep_id, bien_the):
        return _goi(tx, self.__kho.tham_chieu, tai_lieu_id=tai_lieu_id,
                    tep_id=tep_id, bien_the=bien_the)

    def mo_doc(self, tx, *, tai_lieu_id, tep_id, bien_the):
        # KhoTep kiểm quyền hiện hành/hash trước khi trả luồng có thể đóng.
        return _goi(tx, self.__kho.mo_doc, tai_lieu_id=tai_lieu_id,
                    tep_id=tep_id, bien_the=bien_the)


class _Viec(_DichVu):
    __slots__ = ()

    def tao(self, tx, **tham_so):
        return _goi(tx, _viec.tao_viec, **tham_so)

    def lay(self, ctx, viec_id):
        from .viec import lay
        return lay(ctx, viec_id)

    def ket_qua(self, ctx, viec_id):
        from .viec import ket_qua
        return ket_qua(ctx, viec_id)

    def huy(self, ctx, viec_id, khoa):
        from .viec import huy
        return huy(ctx, viec_id, khoa)

    def bao_tien_do(self, tx, giu_viec, muc):
        from .viec import bao_tien_do
        return bao_tien_do(tx, giu_viec, muc)


class _Audit(_DichVu):
    __slots__ = ('__khai_bao',)

    def __init__(self, khai_bao=None):
        self.__khai_bao = khai_bao

    def ghi(self, tx, *, doi_tuong, doi_tuong_id, ket_luan, phien_ban_contract=None):
        # Nợ: doi_tuong hiện do caller chọn (Core chỉ kiểm regex và MTQ).
        ctx = _ctx(tx)
        phien_ban_contract = _phien_ban_contract(
            self.__khai_bao, ctx.module, phien_ban_contract)
        return _sql(tx, 'SELECT loi.ghi_kiem_toan_v2(%s,%s,%s,%s,%s,%s,%s,%s,%s)',
            (ctx.ma.lay_de_truyen(), ctx.module, ctx.phap_nhan_id, ctx.hanh_dong,
             doi_tuong, UUID(str(doi_tuong_id)), ket_luan, ctx.request_id, phien_ban_contract))


class _BienNhan(_DichVu):
    __slots__ = ('__khai_bao',)

    def __init__(self, khai_bao=None):
        self.__khai_bao = khai_bao

    def _phien_ban(self, ctx, phien_ban):
        if self.__khai_bao is not None:
            return _phien_ban_contract(self.__khai_bao, ctx.module, phien_ban)
        return _kiem_phien_ban_contract(phien_ban)

    def tra(self, tx, *, phien_ban_contract=None, **tham_so):
        ctx = _ctx(tx)
        ban = self._phien_ban(ctx, phien_ban_contract)
        return _goi(tx, _tn.tra_thao_tac, operation=ctx.operation, khoa=ctx.khoa,
                    phien_ban_contract=ban, **tham_so)

    def ghi(self, tx, *, phien_ban_contract=None, **tham_so):
        ctx = _ctx(tx)
        ban = self._phien_ban(ctx, phien_ban_contract)
        quyen = tham_so.get('quyen_doc')
        if isinstance(quyen, dict):
            if quyen.get('phien_ban_contract', ban) != ban:
                raise LoiDichVu('SDK_CONTRACT_BINDING', 422)
            tham_so['quyen_doc'] = quyen | dict(phien_ban_contract=ban)
        return _goi(tx, _tn.ghi_thao_tac, operation=ctx.operation, khoa=ctx.khoa,
                    phien_ban_contract=ban, **tham_so)


class _SuKien(_DichVu):
    __slots__ = ()

    def phat(self, tx, *, loai, phien_ban, tham_chieu, khoa):
        return _goi(tx, _bus.phat, loai=loai, phien_ban=phien_ban,
                    tham_chieu=tham_chieu, khoa=khoa)

    def nhan(self, tx, *, loai=None, gioi_han=100):
        return _goi(tx, _bus.nhan, loai=loai, gioi_han=gioi_han)

    def xac_nhan(self, tx, su_kien_id):
        return _goi(tx, _bus.ack, su_kien_id=su_kien_id)


ket_qua, viec, audit, bien_nhan, su_kien = _KetQua(), _Viec(), _Audit(), _BienNhan(), _SuKien()


class DichVu(_DichVu):
    """Bootstrap nối tệp qua N2; kho_tep chỉ dành cho caller cục bộ cũ."""

    __slots__ = ('tep', 'ket_qua', 'viec', 'audit', 'bien_nhan', 'su_kien', 'du_lieu_rieng', 'quy_trinh',
                 'cong_bo',
                 'danh_tinh', 'kiem_toan', 'ma_hoa', 'tai_lieu')

    __slots__ += ('engine',)

    def __init__(self, kho_tep=None, *, du_lieu_rieng=None, khai_bao=None,
                 cong_bo_doc=None, luoc_do_cong_bo=None,
                 kenh_core=None, ngu_canh_tep=None, tham_chieu_quy_trinh=None,
                 cua_giao_dich=None, truy_van=None, lenh=None,
                 doi_tuong=None, quyen_doc=None, kenh_danh_tinh=None,
                 binding_danh_tinh=None, parent_danh_tinh=None, ngu_canh_ket_qua=None,
                 ngu_canh_kenh=None, danh_muc_kiem_toan=None, kenh_kiem_toan=None,
                 kenh_ma_hoa=None, tham_chieu_ma_hoa=None,
                 kenh_engine=None, ngu_canh_engine=None, parent_engine=None,
                 kenh_tai_lieu=None, ngu_canh_tai_lieu=None, ngu_canh_viec=None,
                 ngu_canh_quy_trinh=None):
        from .du_lieu_rieng import DuLieuRieng
        from .quy_trinh import QuyTrinh
        from .tai_lieu import DichVuTaiLieu
        from .danh_tinh import DichVuDanhTinh
        from .kiem_toan import KiemToan
        from .tep import Tep
        if any(v is not None for v in (cua_giao_dich, truy_van, lenh, doi_tuong, quyen_doc)):
            if du_lieu_rieng is not None or cua_giao_dich is None or truy_van is None or lenh is None:
                raise LoiDichVu('SDK_MODULE', 403)
            du_lieu_rieng = DuLieuRieng(khai_bao, cua_giao_dich,
                truy_van=truy_van, lenh=lenh, doi_tuong=doi_tuong, quyen_doc=quyen_doc)
        if du_lieu_rieng is not None and not isinstance(du_lieu_rieng, DuLieuRieng):
            raise LoiDichVu('SDK_MODULE', 403)
        if kenh_core is not None and kho_tep is not None:
            raise LoiDichVu('SDK_MODULE', 403)
        if ngu_canh_tep is not None:
            if kenh_core is None:
                raise LoiDichVu('SDK_MODULE', 403)
            self.tep = Tep(kenh_core, ngu_canh=ngu_canh_tep)
        else:
            # Kênh có thể chỉ phục vụ façade khác; chưa có binding tệp thì
            # giữ adapter cục bộ cũ, kể cả kho None như trước khi ghép F3.
            self.tep = _Tep(kho_tep)
        if khai_bao is None and du_lieu_rieng is not None:
            khai_bao = du_lieu_rieng.khai_bao
        self.ket_qua, self.viec, self.audit = ket_qua, viec, _Audit(khai_bao)
        if ngu_canh_ket_qua is not None:
            if kenh_core is None:
                raise LoiDichVu('SDK_MODULE', 403)
            self.ket_qua = _KetQuaKenh(kenh_core, ngu_canh_ket_qua)
        self.bien_nhan, self.su_kien = _BienNhan(khai_bao), su_kien
        self.du_lieu_rieng = du_lieu_rieng
        # Chọn kênh N2 cho việc; quy trình tự giữ adapter cũ khi cần.
        from .kenh_core import KenhCore as KenhModuleCore
        kenh_viec = kenh_core if isinstance(kenh_core, KenhModuleCore) else None
        self.quy_trinh = QuyTrinh(kenh_core, tham_chieu=tham_chieu_quy_trinh,
                                 ngu_canh=ngu_canh_quy_trinh)

        from .viec import Viec
        self.viec = Viec(kenh_viec, ngu_canh=ngu_canh_viec)
        self.kiem_toan = KiemToan(kenh_kiem_toan if kenh_kiem_toan is not None else kenh_core,
            khai_bao=khai_bao,
            ngu_canh_kenh=ngu_canh_kenh, danh_muc=danh_muc_kiem_toan)
        from .ma_hoa import MaHoa
        self.ma_hoa = MaHoa(kenh_ma_hoa, tham_chieu=tham_chieu_ma_hoa)
        # Kênh N2 riêng với adapter quy trình cũ; bootstrap cấp binding đã ghim.
        self.tai_lieu = DichVuTaiLieu(kenh_tai_lieu, ngu_canh_kenh=ngu_canh_tai_lieu)
        self.danh_tinh = DichVuDanhTinh(
            kenh_core if kenh_danh_tinh is None else kenh_danh_tinh,
            binding=binding_danh_tinh, parent=parent_danh_tinh)
        from .cong_bo import CongBo
        self.cong_bo = CongBo(khai_bao, cong_bo_doc=cong_bo_doc, schemas=luoc_do_cong_bo)

        from .engine_module import EngineModule
        self.engine = EngineModule(kenh_viec if kenh_engine is None else kenh_engine,
            ngu_canh_kenh=ngu_canh_engine, parent=parent_engine)
