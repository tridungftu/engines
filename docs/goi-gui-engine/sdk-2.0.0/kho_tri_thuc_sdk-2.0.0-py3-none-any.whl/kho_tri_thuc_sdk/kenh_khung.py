"""Khung ktt.kenh.sdk/1.0 thuần bộ nhớ, không mở socket hay dispatch.

Request dùng schema §3.1; số thứ tự frame nằm duy nhất trong proof trailer.
Core gọi cap_the bằng khóa riêng; con chỉ tạo BoKiemThe bằng khóa công khai
đã ghim. BoProof phải sống suốt một kết nối, không tạo lại cho mỗi frame.
Caller tuần tự hóa ghi socket theo thứ tự frame trả về, kiểm instance sống,
quyền/ủy nhiệm/cha/deadline và call_id đã thực thi tại runtime N1/N2.
Stream chỉ xác nhận bytes/hash; không đại diện quyền, staging hay commit.
"""

from __future__ import annotations

import base64
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import hmac
import json
import math
import re
import struct
import threading
import time
from types import MappingProxyType
from uuid import UUID

from ._core.phien import MaBiMat


PROTOCOL = 'ktt.kenh.sdk'
PHIEN_BAN = '1.0'
GIOI_HAN_HEADER = 65_536
GIOI_HAN_JSON = 1_048_576
GIOI_HAN_TEP = 20_971_520
GIOI_HAN_CHUNK = 65_536
GIOI_HAN_PROOF = 1_024
GIOI_HAN_THE = 16_384
GIOI_HAN_CON_TRO = 4_096
UINT64_MAX = (1 << 64) - 1
CHIEU = frozenset({'core_den_con', 'con_den_core'})
MIEN_KY = b'ktt.kenh.sdk.v1\0'
MIEN_PROOF = b'ktt.kenh.proof.v1\0'

# Chỉ K được đưa lên wire. Các T/L dưới đây là danh mục cục bộ, không RPC.
OPERATION_CORE = frozenset({
    'danh_tinh.hien_tai', 'danh_tinh.kiem_quyen',
    'tai_lieu.liet_ke', 'tai_lieu.lay', 'tai_lieu.tao',
    'tep.tai_len', 'tep.tham_chieu', 'tep.mo_doc', 'ket_qua.lay',
    'ket_qua.ghi', 'ket_qua.tao_revision',
    'cong_bo.liet_ke', 'engine.liet_ke', 'engine.kha_nang', 'engine.gui_viec',
    'quy_trinh.liet_ke', 'quy_trinh.bat_dau', 'quy_trinh.tiep_tuc',
    'viec.lay', 'viec.ket_qua', 'viec.huy',
    'viec.bao_tien_do',
    'kiem_toan.tra_cuu', 'kiem_toan.ghi_so_do',
    'ma_hoa.ma_hoa', 'ma_hoa.tra_hmac', 'ma_hoa.hien_thi_rut_gon',
    'ma_hoa.giai_ma', 'bien_nhan.doi_chieu',
})
OPERATION_CUC_BO = frozenset({
    'danh_tinh.nhan_request',
    'du_lieu_rieng.giao_dich', 'du_lieu_rieng.doc', 'du_lieu_rieng.ghi',
    'cong_bo.doc', 'cong_bo.kiem_phien_ban',
    'su_kien.phat', 'su_kien.nhan', 'su_kien.xac_nhan',
    'kiem_toan.ghi',
})
OPERATION_ENGINE = frozenset({
    'engine.nhan_viec', 'engine.doc_dau_vao', 'engine.mo_doc',
    'engine.ghi_ket_qua', 'engine.heartbeat', 'engine.ket_thuc',
})
# engine.giao_viec/yeu_cau_dung chưa chốt cơ chế đẩy, không kích hoạt ở v1.
OPERATION_CHO_PHEP = OPERATION_CORE | OPERATION_ENGINE | {'module.thuc_thi'}
FRAME_DIEU_KHIEN = frozenset({
    'challenge', 'xac_thuc', 'chuan_bi', 'cap_the',
    'chunk', 'ack_chunk', 'end', 'dong_stream',
})

MA_LOI_HTTP = MappingProxyType({
    'YEU_CAU_KHONG_HOP_LE': 400,
    'KENH_XAC_THUC_KHONG_HOP_LE': 401,
    'KENH_KHONG_DU_QUYEN': 403,
    'KHONG_TIM_THAY': 404,
    'XUNG_DOT': 409,
    'MAT_LEASE': 409,
    'KHOA_CHONG_TRUNG_KHAC_NOI_DUNG': 409,
    'YEU_CAU_DANG_XU_LY': 409,
    'KET_QUA_HET_HAN': 410,
    'VUOT_GIOI_HAN_KICH_THUOC': 413,
    'MIME_KHONG_HO_TRO': 415,
    'KENH_DU_LIEU_KHONG_HOP_LE': 422,
    'VUOT_HAN_MUC': 429,
    'LOI_NOI_BO': 500,
    'CHUA_SAN_SANG': 503,
    'TIEN_TRINH_DANG_DUNG': 503,
    'MODULE_DANG_KHOI_DONG': 503,
    'PHAN_HOI_QUA_HAN': 504,
    'PHAN_HOI_SAI_CONTRACT': 502,
})
_SAI = 'KENH_DU_LIEU_KHONG_HOP_LE'
_XAC_THUC = 'KENH_XAC_THUC_KHONG_HOP_LE'
_LON = 'VUOT_GIOI_HAN_KICH_THUOC'


def _chi_tiet_loi(ma, http_status, chi_tiet):
    """Chỉ chép hai lý do dự án đã công bố, không chuyển metadata thô."""
    if ma == _SAI and http_status == 422 and type(chi_tiet) is dict:
        for code in ('DU_AN_KHONG_HOP_LE', 'DU_AN_DA_DOI'):
            detail = dict(truong='du_an_id', ma=code)
            if chi_tiet == detail:
                return detail
    return None


class LoiKenh(RuntimeError):
    """Lỗi hữu hạn, không chứa đầu vào thô; timeout không ngầm cho retry."""

    def __init__(self, ma=_SAI, *, retry_after=None, chi_tiet=None, thu_lai_duoc=None):
        if ma not in MA_LOI_HTTP:
            ma, chi_tiet = _SAI, None
        if retry_after is not None and not _so_nguyen(retry_after, 1, 300):
            ma, retry_after = _SAI, None
        self.ma = ma
        self.http_status = MA_LOI_HTTP[ma]
        cho_lai = self.http_status == 429 or ma == 'YEU_CAU_DANG_XU_LY'
        self.retry_after = 2 if cho_lai and retry_after is None else retry_after
        # 503 chỉ retry khi runtime xác nhận có thể chờ trước dispatch.
        self.thu_lai_duoc = (cho_lai or (self.http_status == 503 and retry_after is not None)
                            or (ma == 'XUNG_DOT' and thu_lai_duoc is True))
        detail = _chi_tiet_loi(ma, self.http_status, chi_tiet)
        if detail is not None:
            self.chi_tiet = detail
        super().__init__(ma)


def _so_nguyen(v, nho=0, lon=UINT64_MAX):
    return type(v) is int and nho <= v <= lon


def _can(dung, ma=_SAI):
    if not dung:
        raise LoiKenh(ma)


def _chuoi(v):
    return type(v) is str and bool(v)


def _uuid(v):
    if not _chuoi(v):
        return False
    try:
        return str(UUID(v)) == v
    except ValueError:
        return False


def _hash(v):
    return type(v) is str and re.fullmatch('[0-9a-f]{64}', v) is not None


def _cay(v, sau=0, *, nhieu_dong=frozenset(), duong=()):
    _can(sau <= 32)
    if type(v) is str:
        allowed = '\n\t' if duong in nhieu_dong else ''
        if allowed:
            v = v.replace('\r\n', '\n')
        _can(not any((ord(c) < 32 and c not in allowed) or 127 <= ord(c) <= 159
                     or 0xD800 <= ord(c) <= 0xDFFF for c in v))
    elif type(v) is dict:
        result = {}
        for k, x in v.items():
            _can(type(k) is str)
            _cay(k, sau + 1)
            result[k] = _cay(x, sau + 1, nhieu_dong=nhieu_dong, duong=duong + (k,))
        return result
    elif type(v) is list:
        return [_cay(x, sau + 1, nhieu_dong=nhieu_dong, duong=duong + (i,))
                for i, x in enumerate(v)]
    else:
        _can(v is None or type(v) in (bool, int)
             or (type(v) is float and math.isfinite(v)))
    return v


def _json(v):
    v = _cay(v)
    return json.dumps(v, ensure_ascii=False, separators=(',', ':'), sort_keys=True,
                      allow_nan=False).encode('utf-8')


def _cap_khoa(cac_cap):
    v = {}
    for k, x in cac_cap:
        if k in v:
            raise ValueError()
        v[k] = x
    return v


def _doc_json(raw):
    # Không giữ exception parser (có thể chứa credential) trong chaining.
    try:
        if any(b < 32 or b == 127 for b in raw):
            raise ValueError()
        v = json.loads(raw.decode('utf-8'), object_pairs_hook=_cap_khoa,
                       parse_constant=_khong_hang)
    except (ValueError, UnicodeError, RecursionError):
        pass
    else:
        _can(type(v) is dict)
        return _cay(v)
    raise LoiKenh()


def _khong_hang(_):
    raise ValueError()


def _b64(raw):
    return base64.urlsafe_b64encode(raw).rstrip(b'=').decode('ascii')


def _giai_b64(s):
    if type(s) is str and re.fullmatch('[A-Za-z0-9_-]+', s):
        try:
            raw = base64.b64decode(s + '=' * (-len(s) % 4), altchars=b'-_', validate=True)
        except ValueError:
            pass
        else:
            if _b64(raw) == s:
                return raw
    raise LoiKenh(_XAC_THUC)


def _dong(truong, bat_buoc, tuy_chon=frozenset(), *, ma=_SAI):
    _can(type(truong) is dict and bat_buoc <= truong.keys()
         and truong.keys() <= bat_buoc | tuy_chon, ma)


def _deadline(v):
    if _chuoi(v):
        try:
            dt = datetime.fromisoformat(v.replace('Z', '+00:00'))
        except ValueError:
            pass
        else:
            return dt.tzinfo is not None and dt.utcoffset() == timezone.utc.utcoffset(dt)
    return False


def _operation(v):
    _can(_chuoi(v) and len(v) <= 200)
    _can(v in OPERATION_CHO_PHEP, 'KHONG_TIM_THAY')


def _descriptor(v):
    if v is None:
        return
    _dong(v, {'stream_id', 'kich_thuoc_byte', 'sha256', 'mime', 'ten'})
    _can(_chuoi(v['stream_id']) and _hash(v['sha256'])
         and _chuoi(v['mime']) and _chuoi(v['ten']))
    _can(_so_nguyen(v['kich_thuoc_byte']))
    _can(v['kich_thuoc_byte'] <= GIOI_HAN_TEP, _LON)


_CO_BAN = frozenset({'protocol', 'phien_ban', 'kieu', 'chieu',
                     'request_id', 'call_id', 'hash_than'})
_REQUEST = _CO_BAN | {
    'operation', 'parent_call_id', 'thu_tu_con', 'issuer', 'core_epoch',
    'module', 'module_nguon', 'instance_id', 'the_he', 'nonce_khoi_dong',
    'pham_vi', 'phap_nhan_id', 'nguoi_dung_id', 'hanh_dong', 'uy_nhiem',
    'contract_id', 'phien_ban_contract', 'ma_bam_schema', 'khoa', 'deadline',
    'stream', 'the_ky', 'http',
}
_RESPONSE = _CO_BAN | {'operation', 'status', 'da_commit', 'bien_nhan', 'stream', 'loi'}
_DIEU_KHIEN = {
    k: _CO_BAN | them for k, them in {
        'challenge': set(), 'xac_thuc': set(), 'chuan_bi': set(), 'cap_the': set(),
        'chunk': {'stream_id', 'thu_tu_chunk', 'kich_thuoc_byte'},
        'ack_chunk': {'stream_id', 'thu_tu_chunk'},
        'end': {'stream_id', 'kich_thuoc_byte'}, 'dong_stream': {'stream_id'},
    }.items()
}


def kiem_header(h, *, can_the=True):
    """Kiểm cấu trúc; quyền/contract registry và deadline dispatch do runtime kiểm."""
    _can(type(h) is dict)
    _cay(h)
    kieu = h.get('kieu')
    _can(type(kieu) is str)
    if kieu == 'request':
        _dong(h, _REQUEST if can_the else _REQUEST - {'the_ky'}, {'con_tro'})
    elif kieu == 'response':
        _dong(h, _RESPONSE, {'retry_after'})
    else:
        _can(kieu in _DIEU_KHIEN)
        _dong(h, _DIEU_KHIEN[kieu])
    _can(h['protocol'] == PROTOCOL and h['phien_ban'] == PHIEN_BAN)
    _can(type(h['chieu']) is str and h['chieu'] in CHIEU)
    _can(_uuid(h['request_id']) and _uuid(h['call_id']) and _hash(h['hash_than']))
    if kieu in ('request', 'response'):
        _operation(h['operation'])
        _descriptor(h['stream'])
        if h['operation'] == 'module.thuc_thi':
            _can(h['stream'] is None)
    if kieu == 'request':
        if 'con_tro' in h:
            _can(h['operation'] == 'module.thuc_thi')
            ct = h['con_tro']
            _dong(ct, {'phien_ban', 'kich_thuoc', 'khoa_sau'})
            _can(ct['phien_ban'] == '1.0' and _so_nguyen(ct['kich_thuoc'], 1, 100)
                 and (ct['khoa_sau'] is None or type(ct['khoa_sau']) is list))
            _can(len(_json(ct)) <= GIOI_HAN_CON_TRO, _LON)
        _can(h['chieu'] == ('core_den_con' if h['operation'] == 'module.thuc_thi'
                            else 'con_den_core'), _XAC_THUC)
        _can((h['parent_call_id'] is None and h['thu_tu_con'] is None)
             or (_uuid(h['parent_call_id']) and _so_nguyen(h['thu_tu_con'], 1)))
        _can(_uuid(h['instance_id']) and _so_nguyen(h['the_he'], 1))
        for ten in ('issuer', 'core_epoch', 'module', 'module_nguon', 'hanh_dong',
                    'contract_id', 'phien_ban_contract'):
            _can(_chuoi(h[ten]))
        _can(type(h['nonce_khoi_dong']) is str
             and re.fullmatch('[A-Za-z0-9_-]{43,128}', h['nonce_khoi_dong']) is not None)
        _can(_hash(h['ma_bam_schema']) and _deadline(h['deadline']))
        _can(h['khoa'] is None or (type(h['khoa']) is str
             and re.fullmatch('[A-Za-z0-9._:-]{16,128}', h['khoa']) is not None))
        _can(type(h['pham_vi']) is str
             and h['pham_vi'] in ('phap_nhan', 'he_thong', 'tien_trinh'))
        _can(h['phap_nhan_id'] is None or _uuid(h['phap_nhan_id']))
        _can(h['nguoi_dung_id'] is None or _uuid(h['nguoi_dung_id']))
        if h['pham_vi'] == 'phap_nhan':
            _can(_uuid(h['phap_nhan_id']) and _uuid(h['nguoi_dung_id']))
        if h['pham_vi'] == 'tien_trinh':
            _can(h['phap_nhan_id'] is None and h['nguoi_dung_id'] is None
                 and h['operation'] == 'kiem_toan.ghi_so_do')
        u = h['uy_nhiem']
        _dong(u, {'loai', 'ma', 'viec_id', 'the_he_lease'})
        _can(_chuoi(u['loai']) and _chuoi(u['ma']))
        _can((u['viec_id'] is None and u['the_he_lease'] is None)
             or (_uuid(u['viec_id']) and _so_nguyen(u['the_he_lease'], 1)))
        if h['operation'] == 'module.thuc_thi':
            _dong(h['http'], {'method', 'path_query', 'the_ngu_canh'})
            http = h['http']
            _can(type(http['method']) is str and re.fullmatch('[A-Z]+', http['method'])
                 and _chuoi(http['path_query']) and http['path_query'].startswith('/')
                 and _chuoi(http['the_ngu_canh']))
        else:
            _can(h['http'] is None)
        if can_the:
            _can(_chuoi(h['the_ky']), _XAC_THUC)
            _can(len(h['the_ky'].encode('utf-8')) <= GIOI_HAN_THE, _LON)
    elif kieu == 'response':
        _can(_so_nguyen(h['status'], 200, 599) and type(h['da_commit']) is bool)
        if h['bien_nhan'] is not None:
            _dong(h['bien_nhan'], {'chu', 'operation', 'khoa'})
            _can(all(_chuoi(v) for v in h['bien_nhan'].values()))
            _operation(h['bien_nhan']['operation'])
        if h['status'] < 400:
            _can(h['loi'] is None and 'retry_after' not in h)
        else:
            loi = h['loi']
            _dong(loi, {'ma', 'thong_diep', 'request_id', 'thu_lai_duoc', 'http_status'},
                  {'chi_tiet'})
            # Mã nghiệp vụ module được runtime/Dispatcher đối chiếu route;
            # 401/429/503 và các chiều khác chỉ nhận mã kênh trong bảng.
            _can(_chuoi(loi['ma']) and re.fullmatch('[A-Z][A-Z0-9_]{0,79}', loi['ma'])
                 and (loi['ma'] in MA_LOI_HTTP
                      or (h['operation'] == 'module.thuc_thi' and h['chieu'] == 'con_den_core'
                          and h['status'] not in {401, 429, 503}))
                 and type(loi['http_status']) is int
                 and loi['http_status'] == h['status'] == MA_LOI_HTTP.get(loi['ma'], h['status'])
                 and loi['request_id'] == h['request_id']
                 and type(loi['thu_lai_duoc']) is bool and _chuoi(loi['thong_diep']))
            if 'chi_tiet' in loi:
                _dong(loi['chi_tiet'], {'truong', 'ma'})
                _can(all(_chuoi(v) for v in loi['chi_tiet'].values()))
            if h['status'] == 429 or loi['ma'] == 'YEU_CAU_DANG_XU_LY':
                _can('retry_after' in h and loi['thu_lai_duoc'])
            if loi['ma'] == 'YEU_CAU_DANG_XU_LY':
                _can(h['retry_after'] == 2)
            if h['status'] == 503:
                _can(loi['thu_lai_duoc'] == ('retry_after' in h))
            if 'retry_after' in h:
                _can(_so_nguyen(h['retry_after'], 1, 300))
    else:
        if 'stream_id' in h:
            _can(_chuoi(h['stream_id']))
        if 'thu_tu_chunk' in h:
            _can(_so_nguyen(h['thu_tu_chunk']))
        if 'kich_thuoc_byte' in h:
            _can(_so_nguyen(h['kich_thuoc_byte']))
            _can(h['kich_thuoc_byte'] <= (GIOI_HAN_CHUNK if kieu == 'chunk'
                                         else GIOI_HAN_TEP), _LON)


def _thoi_diem(v):
    if type(v) in (int, float):
        try:
            return math.isfinite(v)
        except OverflowError:
            pass
    return False


def cap_the(header, khoa_rieng, *, phat_luc=None, ttl=30):
    """Chỉ phía Core gọi; trả MaBiMat, không giữ khóa riêng trong bộ kiểm."""
    from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PrivateKey

    kiem_header(header, can_the=False)
    _can(header['kieu'] == 'request' and isinstance(khoa_rieng, Ed25519PrivateKey))
    phat_luc = time.time() if phat_luc is None else phat_luc
    _can(_thoi_diem(phat_luc) and _thoi_diem(ttl) and 0 < ttl <= 30)
    # Ngữ cảnh phân trang là extension của frame, được proof MAC bảo vệ;
    # không thêm claim vào schema thẻ v1 đã đóng.
    claims = {k: v for k, v in header.items() if k != 'con_tro'}
    payload = _json(dict(claims, phat_luc=phat_luc, het_han=phat_luc + ttl))
    the = _b64(payload) + '.' + _b64(khoa_rieng.sign(MIEN_KY + payload))
    _can(len(the) <= GIOI_HAN_THE, _LON)
    return MaBiMat(the)


class BoKiemThe:
    """Chỉ giữ public key và binding từ bootstrap/registry tin cậy."""

    def __init__(self, khoa_cong_khai, *, issuer, core_epoch, instance_id,
                 the_he, nonce_khoi_dong, module, dong_ho=time.time):
        from cryptography.hazmat.primitives.asymmetric.ed25519 import Ed25519PublicKey

        _can(isinstance(khoa_cong_khai, Ed25519PublicKey))
        _can(_uuid(instance_id) and _so_nguyen(the_he, 1) and callable(dong_ho))
        self._khoa = khoa_cong_khai
        self._rang_buoc = dict(issuer=issuer, core_epoch=core_epoch,
            instance_id=instance_id, the_he=the_he, nonce_khoi_dong=nonce_khoi_dong,
            module=module)
        self._dong_ho = dong_ho

    def __repr__(self):
        return 'BoKiemThe(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize bộ kiểm thẻ')

    def kiem(self, header):
        from cryptography.exceptions import InvalidSignature

        kiem_header(header)
        _can(header['kieu'] == 'request', _XAC_THUC)
        the = header['the_ky']
        _can(the.count('.') == 1, _XAC_THUC)
        payload, chu_ky = map(_giai_b64, the.split('.'))
        try:
            self._khoa.verify(chu_ky, MIEN_KY + payload)
        except (InvalidSignature, ValueError):
            pass
        else:
            try:
                claims = _doc_json(payload)
            except LoiKenh:
                claims = None
            _can(claims is not None, _XAC_THUC)
            du_kien = {k: v for k, v in header.items() if k not in {'the_ky', 'con_tro'}}
            _can(claims.keys() == du_kien.keys() | {'phat_luc', 'het_han'}, _XAC_THUC)
            phat, het, now = claims.pop('phat_luc'), claims.pop('het_han'), self._dong_ho()
            _can(all(_thoi_diem(v) for v in (phat, het, now)), _XAC_THUC)
            _can(0 < het - phat <= 30 and phat <= now < het, _XAC_THUC)
            # So bytes JSON chuẩn để không nhận bool == int hay float == int.
            _can(_json(claims) == _json(du_kien), _XAC_THUC)
            _can(all(type(header[k]) is type(v) and header[k] == v
                     for k, v in self._rang_buoc.items()), _XAC_THUC)
            return
        raise LoiKenh(_XAC_THUC)


def _cac_phan(*cac_phan):
    return b''.join(struct.pack('!Q', len(p)) + p for p in cac_phan)


def dan_khoa_con(khoa_cha, operation, thu_tu_con):
    """HMAC tất định; thứ tự bước do nghiệp vụ giữ ổn định khi replay.

    Khóa cha là bytes UTF-8 của nguyên chuỗi khóa chống trùng, không decode
    hex/base64, không chuẩn hóa/cắt khoảng trắng. Kết quả hex ASCII được dùng
    làm cha tiếp bằng .encode('utf-8'), không dùng bytes.fromhex().
    """
    _can(type(khoa_cha) is bytes and bool(khoa_cha))
    _can(_chuoi(operation) and operation in OPERATION_CHO_PHEP | OPERATION_CUC_BO,
         'KHONG_TIM_THAY')
    _can(_so_nguyen(thu_tu_con, 1))
    return hmac.new(khoa_cha, _cac_phan(operation.encode('utf-8'),
        struct.pack('!Q', thu_tu_con)), hashlib.sha256).hexdigest()


class BoProof:
    """Một bộ mỗi đầu kết nối; vai và loại con lấy từ bootstrap tin cậy.

    Core và con có chiều gửi/nhận đối nhau, không suy từ header phía gửi.
    loai_con='module' chỉ dùng dịch vụ module; 'engine' chỉ dùng SDKEngine.
    """

    def __init__(self, credential, ket_noi_id, *, vai, loai_con='module'):
        _can(type(credential) is bytes and len(credential) >= 32, _XAC_THUC)
        _can(_chuoi(ket_noi_id), _XAC_THUC)
        _can(type(vai) is str and vai in ('core', 'con'), _XAC_THUC)
        _can(type(loai_con) is str and loai_con in ('module', 'engine'), _XAC_THUC)
        _cay(ket_noi_id)
        self._credential, self._ket_noi_id = credential, ket_noi_id
        self._chieu_gui = 'core_den_con' if vai == 'core' else 'con_den_core'
        self._chieu_nhan = 'con_den_core' if vai == 'core' else 'core_den_con'
        self._operations = (OPERATION_CORE | {'module.thuc_thi'}
                            if loai_con == 'module' else OPERATION_ENGINE)
        self._gui = dict.fromkeys(CHIEU, 0)
        self._nhan = dict.fromkeys(CHIEU, 0)
        self._khoa = threading.Lock()
        # Chặn metadata quá lớn ngay khi dựng, chưa tiêu thụ số thứ tự.
        _can(len(_json({'ket_noi_id': ket_noi_id, 'so_thu_tu': UINT64_MAX,
                        'mac': '0' * 64})) <= GIOI_HAN_PROOF, _LON)

    def __repr__(self):
        return 'BoProof(<an>)'

    def __reduce__(self):
        raise TypeError('Không serialize credential')

    def _mac(self, chieu, so, header_raw, than):
        return hmac.new(self._credential, MIEN_PROOF + _cac_phan(
            self._ket_noi_id.encode('utf-8'), chieu.encode('ascii'),
            struct.pack('!Q', so), header_raw, hashlib.sha256(than).digest()),
            hashlib.sha256).hexdigest()

    def tao(self, chieu, header_raw, than):
        _can(type(chieu) is str and chieu == self._chieu_gui, _XAC_THUC)
        _can(type(header_raw) is bytes and type(than) is bytes)
        with self._khoa:
            so = self._gui[chieu] + 1
            _can(so <= UINT64_MAX, _XAC_THUC)
            raw = _json(dict(ket_noi_id=self._ket_noi_id, so_thu_tu=so,
                            mac=self._mac(chieu, so, header_raw, than)))
            _can(len(raw) <= GIOI_HAN_PROOF, _LON)
            self._gui[chieu] = so
            return raw

    def kiem(self, chieu, header_raw, than, proof_raw):
        _can(type(chieu) is str and chieu == self._chieu_nhan, _XAC_THUC)
        _can(type(header_raw) is bytes and type(than) is bytes
             and type(proof_raw) is bytes, _XAC_THUC)
        _can(len(proof_raw) <= GIOI_HAN_PROOF, _LON)
        try:
            p = _doc_json(proof_raw)
        except LoiKenh:
            p = None
        _dong(p, {'ket_noi_id', 'so_thu_tu', 'mac'}, ma=_XAC_THUC)
        _can(p['ket_noi_id'] == self._ket_noi_id
             and _so_nguyen(p['so_thu_tu'], 1) and _hash(p['mac']), _XAC_THUC)
        with self._khoa:
            so = p['so_thu_tu']
            _can(so == self._nhan[chieu] + 1, _XAC_THUC)
            _can(hmac.compare_digest(p['mac'], self._mac(chieu, so, header_raw, than)),
                 _XAC_THUC)
            # Chỉ parse header sau MAC, không lộ schema/allowlist cho bên lạ.
            h = _doc_json(header_raw)
            _can(h.get('chieu') == self._chieu_nhan, _XAC_THUC)
            self._nhan[chieu] = so
            return h

    def kiem_operation(self, header):
        if header['kieu'] in ('request', 'response'):
            _can(header['operation'] in self._operations, 'KENH_KHONG_DU_QUYEN')
            if header.get('bien_nhan') is not None:
                _can(header['bien_nhan']['operation'] in self._operations,
                     'KENH_KHONG_DU_QUYEN')


def _gioi_han_than(header):
    return GIOI_HAN_CHUNK if header['kieu'] == 'chunk' else GIOI_HAN_JSON


def _kiem_than(header, than):
    _can(type(than) is bytes)
    _can(len(than) <= _gioi_han_than(header), _LON)
    _can(hashlib.sha256(than).hexdigest() == header['hash_than'],
         _XAC_THUC if header['kieu'] == 'request' else _SAI)
    if header['kieu'] == 'chunk':
        _can(len(than) == header['kich_thuoc_byte'])


@dataclass(frozen=True, repr=False)
class Frame:
    header: dict
    than: bytes
    header_raw: bytes

    def __repr__(self):
        return 'Frame(<an>)'

    def __reduce__(self):
        raise TypeError('Chỉ serialize frame qua ma_hoa_frame')


def ma_hoa_frame(header, than, proof):
    """Mã hóa framing (không encryption); body giữ nguyên bytes."""
    kiem_header(header)
    proof.kiem_operation(header)
    raw = _json(header)
    _can(len(raw) <= GIOI_HAN_HEADER, _LON)
    _kiem_than(header, than)
    trailer = proof.tao(header['chieu'], raw, than)
    return (struct.pack('!I', len(raw)) + raw + struct.pack('!I', len(than))
            + than + struct.pack('!I', len(trailer)) + trailer)


def giai_ma_frame(wire, proof, *, kiem_the=None):
    """Nhận đúng một frame đầy đủ; N1/N2 đọc length/giới hạn trước khi đọc socket.

    Không giữ buffer ghép luồng. Trả frame sau kiểm proof và (request) chữ ký.
    Length được kiểm trước slice/cấp phát; không chấp nhận bytes dư.
    """
    _can(type(wire) is bytes)
    pos = 0

    def lay(gioi_han):
        nonlocal pos
        _can(pos + 4 <= len(wire))
        n = struct.unpack_from('!I', wire, pos)[0]
        pos += 4
        _can(n <= gioi_han, _LON)
        _can(pos + n <= len(wire))
        raw = wire[pos:pos + n]
        pos += n
        return raw

    raw = lay(GIOI_HAN_HEADER)
    # Giới hạn bytes chung trước xác thực; giới hạn theo loại sau MAC/schema.
    than = lay(GIOI_HAN_JSON)
    trailer = lay(GIOI_HAN_PROOF)
    _can(pos == len(wire))
    h = proof.kiem(proof._chieu_nhan, raw, than, trailer)
    try:
        kiem_header(h)
        _kiem_than(h, than)
    except LoiKenh as exc:
        ma_loi = ('PHAN_HOI_SAI_CONTRACT'
                  if h.get('kieu') == 'response' and exc.http_status != 413 else exc.ma)
    else:
        ma_loi = None
    if ma_loi is not None:
        raise LoiKenh(ma_loi)
    proof.kiem_operation(h)
    if h['kieu'] == 'request':
        _can(isinstance(kiem_the, BoKiemThe), _XAC_THUC)
        kiem_the.kiem(h)
    return Frame(h, than, raw)


class BoDemStream:
    """Đếm bytes/chunk và SHA-256 tích lũy, không buffer nội dung tệp.

    Mỗi bộ gắn một descriptor/call đã được runtime kiểm quyền. Chỉ cấp chunk
    đã giai_ma_frame; runtime đối chiếu call/instance/chiều và quản lý ACK/I/O.
    Lỗi là kết thúc stream, không tiếp tục hay công bố metadata hoàn tất.
    """

    def __init__(self, descriptor, *, gioi_han=GIOI_HAN_TEP):
        _descriptor(descriptor)
        _can(descriptor is not None and _so_nguyen(gioi_han, 0, GIOI_HAN_TEP))
        _can(descriptor['kich_thuoc_byte'] <= gioi_han, _LON)
        self._id = descriptor['stream_id']
        self._kich_thuoc = descriptor['kich_thuoc_byte']
        self._hash_du_kien = descriptor['sha256']
        self._gioi_han = gioi_han
        self._tong = self._thu_tu = 0
        self._bam = hashlib.sha256()
        self._dong = False

    def __repr__(self):
        return 'BoDemStream(<an>)'

    @property
    def tong_byte(self):
        return self._tong

    def nhan_chunk(self, stream_id, thu_tu_chunk, than):
        try:
            _can(not self._dong and stream_id == self._id
                 and _so_nguyen(thu_tu_chunk) and thu_tu_chunk == self._thu_tu)
            _can(type(than) is bytes)
            _can(len(than) <= GIOI_HAN_CHUNK, _LON)
            tong = self._tong + len(than)
            _can(tong <= self._gioi_han, _LON)
            _can(tong <= self._kich_thuoc)
        except LoiKenh:
            self._dong = True
            raise
        self._bam.update(than)
        self._tong = tong
        self._thu_tu += 1

    def ket_thuc(self):
        _can(not self._dong)
        self._dong = True
        _can(self._tong == self._kich_thuoc
             and self._bam.hexdigest() == self._hash_du_kien)
